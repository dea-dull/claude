"""
Strategy V1 backtest experiment.

Runs the full mechanical pipeline (features -> decision -> validation ->
risk -> execution -> holding-period enforcement -> persistence) against
historical 4h BTC candles, using the strategy config in
trading_system.strategy.v1_config.

Default decision engine: RuleBasedReferenceDecisionEngine -- a
deterministic code implementation of the Strategy V1 rules, NOT real
Claude. See docs/strategy_v1.md Section 14 and the module docstring in
strategy/reference_engine.py for exactly what that does and doesn't
tell you.

Usage:
    PYTHONPATH=src python3 experiments/backtest_strategy_v1.py
    PYTHONPATH=src python3 experiments/backtest_strategy_v1.py --data path/to/real_data.csv

To run against real Claude instead (requires network + ANTHROPIC_API_KEY,
neither of which is available in this sandboxed environment):
    PYTHONPATH=src python3 experiments/backtest_strategy_v1.py --engine claude
"""

from __future__ import annotations

import argparse
import json
import os

from trading_system.backtesting.data_loader import load_ohlcv_csv
from trading_system.backtesting.funding_loader import load_funding_csv
from trading_system.backtesting.engine import BacktestEngine
from trading_system.decision.claude_interface import ClaudeDecisionEngine
from trading_system.exchange.mock_exchange import ReplayExchangeAdapter
from trading_system.persistence.db import EventStore
from trading_system.pipeline import TradingPipeline
from trading_system.risk.engine import RiskEngine
from trading_system.strategy import v1_config
from trading_system.strategy.holding_period import HoldingPeriodPolicy
from trading_system.strategy.reference_engine import RuleBasedReferenceDecisionEngine

DEFAULT_DATA_PATH = "data/btc_4h_synthetic.csv"
STARTING_BALANCE = 10_000.0
SYMBOL = "BTCUSDT"


def build_claude_engine() -> ClaudeDecisionEngine:
    """Wires a real Anthropic API call into ClaudeDecisionEngine.

    Only imports anthropic and constructs a client here, inside the
    function actually called when --engine claude is chosen -- keeps
    the sandboxed default path (--engine rules) completely free of any
    dependency on the SDK being installed or network being reachable.
    """
    try:
        import anthropic
    except ImportError as exc:
        raise SystemExit(
            "The 'anthropic' package is required for --engine claude. "
            "Install it with: pip install anthropic"
        ) from exc

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise SystemExit("ANTHROPIC_API_KEY is not set in the environment.")

    client = anthropic.Anthropic(api_key=api_key)

    def call_claude(prompt: str) -> str:
        response = client.messages.create(
            model="claude-sonnet-5",
            max_tokens=1000,
            temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text

    return ClaudeDecisionEngine(
        llm_call_fn=call_claude,
        model_name="claude-sonnet-5",
        system_prompt_extra=v1_config.PROMPT_ADDENDUM,
    )


def run(data_path: str, engine_name: str, funding_path: str = None) -> None:
    if not os.path.exists(data_path):
        raise SystemExit(
            f"Data file not found: {data_path!r}. Run "
            f"'PYTHONPATH=src python3 experiments/generate_synthetic_data.py' first, "
            f"or point --data at a real historical CSV."
        )

    candles = load_ohlcv_csv(data_path, timeframe_seconds=v1_config.CANDLE_TIMEFRAME_SECONDS)
    print(f"Loaded {len(candles)} candles from {data_path}")
    print(f"Price range: {min(c.low for c in candles):.0f} - {max(c.high for c in candles):.0f}")

    is_synthetic = os.path.abspath(data_path) == os.path.abspath(DEFAULT_DATA_PATH)
    if is_synthetic:
        print(
            "\n*** WARNING: this is SYNTHETIC data, not real BTC history. ***\n"
            "*** Results below are a mechanical-system sanity check only. ***\n"
        )

    funding_series = None
    if funding_path:
        if not os.path.exists(funding_path):
            raise SystemExit(f"Funding file not found: {funding_path!r}")
        funding_series = load_funding_csv(funding_path)
        print(f"Loaded {len(funding_series)} real funding rate rows from {funding_path} "
              f"(overrides the constant-rate assumption in CostModel)")
    else:
        print(
            f"No --funding CSV given -- using the constant-rate assumption "
            f"({v1_config.COST_MODEL.funding_rate_per_interval} per "
            f"{v1_config.COST_MODEL.funding_interval_seconds/3600:.0f}h), see docs/strategy_v1.md Section 12."
        )

    exchange = ReplayExchangeAdapter(
        symbol=SYMBOL,
        candles=candles,
        starting_balance=STARTING_BALANCE,
        spread_bps=v1_config.SPREAD_BPS,
        cost_model=v1_config.COST_MODEL,
        funding_series=funding_series,
    )
    event_store = EventStore(":memory:")
    risk_engine = RiskEngine(v1_config.build_risk_limits(STARTING_BALANCE), clock=exchange.clock)

    if engine_name == "claude":
        decision_engine = build_claude_engine()
    else:
        decision_engine = RuleBasedReferenceDecisionEngine()

    pipeline = TradingPipeline(
        exchange=exchange,
        decision_engine=decision_engine,
        event_store=event_store,
        risk_engine=risk_engine,
        feature_engine=v1_config.FEATURE_ENGINE,
        validator=v1_config.VALIDATOR,
    )
    holding_period_policy = HoldingPeriodPolicy(max_holding_seconds=v1_config.MAX_HOLDING_SECONDS)
    backtest = BacktestEngine(
        pipeline, symbol=SYMBOL, starting_balance=STARTING_BALANCE, holding_period_policy=holding_period_policy
    )

    print(f"\nRunning backtest with engine={engine_name!r} ...")
    summary = backtest.run(keep_results=False)

    from trading_system.evaluation.report import build_report_dict, format_report_text

    report = build_report_dict(summary, engine_name=engine_name, data_file=data_path, is_synthetic=is_synthetic)
    print()
    print(format_report_text(report))

    net_pnl = report["equity"]["net_pnl"]
    net_pnl_pct = report["equity"]["net_pnl_pct"]

    if summary.trades_executed == 0:
        print(
            "\nVERDICT: no trades were executed. Either the setup criteria never "
            "coincided with the risk/validation gates on this data, or the data "
            "itself doesn't contain conditions this strategy is looking for. This "
            "is a valid outcome, not a bug -- a strategy that refuses to force "
            "trades is doing what docs/strategy_v1.md Section 4 asks for."
        )
    elif net_pnl > 0:
        print(
            f"\nVERDICT: positive net expectancy ({net_pnl_pct:+.2f}%) for the "
            f"{engine_name} engine on this dataset, after modeled fees/spread/"
            f"slippage/funding. This is necessary-but-not-sufficient evidence -- "
            f"see docs/strategy_v1.md Section 14 for what this run does and does "
            f"not establish, especially if engine=rules."
        )
    else:
        print(
            f"\nVERDICT: negative net expectancy ({net_pnl_pct:+.2f}%) for the "
            f"{engine_name} engine on this dataset, after costs. Per the brief: "
            f"this is useful information, not a reason to force the strategy to "
            f"work. Revise the spec (Sections 4-9) or discard before spending "
            f"real API calls or capital on it."
        )

    os.makedirs("experiments/results", exist_ok=True)
    out_path = f"experiments/results/strategy_v1_{engine_name}.json"
    with open(out_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\nMachine-readable report written to {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default=DEFAULT_DATA_PATH, help="Path to historical OHLCV CSV")
    parser.add_argument("--funding", default=None, help="Optional path to real historical funding-rate CSV")
    parser.add_argument(
        "--engine", choices=["rules", "claude"], default="rules",
        help="'rules' = deterministic reference engine (works offline); "
             "'claude' = real Claude API (requires network + ANTHROPIC_API_KEY)",
    )
    args = parser.parse_args()
    run(args.data, args.engine, funding_path=args.funding)
