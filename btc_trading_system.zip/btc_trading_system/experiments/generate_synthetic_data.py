"""
Generates data/btc_4h_synthetic.csv -- a regime-switching random-walk
series standing in for real BTC 4h OHLCV data.

THIS IS NOT REAL MARKET DATA. Repeated attempts to pull real BTC OHLCV
data from CoinGecko, Binance, and Yahoo Finance during this session were
all blocked by robots.txt for the fetching tool available in this
environment (see conversation notes). This generator exists so
Strategy V1's mechanical system (cost model, holding period, risk
sizing, validation) can be backtested against *something* with
realistic-ish regime structure (alternating trend/chop/volatility
regimes) rather than a single smooth sine wave, while being completely
honest that it is not real history.

**Replace data/btc_4h_synthetic.csv with a real historical export before
treating any backtest result as evidence about real BTC.** The loader
(`backtesting/data_loader.py::load_ohlcv_csv`) reads any CSV with
timestamp,open,high,low,close,volume columns, so swapping in real data
requires no code changes.

Run: PYTHONPATH=src python3 experiments/generate_synthetic_data.py
"""

import csv
import math
import random

OUTPUT_PATH = "data/btc_4h_synthetic.csv"
NUM_CANDLES = 1500  # ~250 days / ~8.3 months of 4h bars
TIMEFRAME_SECONDS = 4 * 3600
START_TIMESTAMP = 1_700_000_000.0  # arbitrary fixed epoch anchor, reproducible
START_PRICE = 60_000.0
SEED = 20260904  # fixed for reproducibility


def generate(seed: int = SEED, n: int = NUM_CANDLES) -> list:
    rng = random.Random(seed)
    rows = []
    price = START_PRICE
    ts = START_TIMESTAMP

    # Regime schedule: alternating trend/chop/volatility blocks so the
    # reference engine sees a mix of setups instead of one smooth curve.
    regime_length = 60  # candles per regime (~10 days at 4h)
    regimes = ["uptrend", "downtrend", "chop", "high_vol", "low_vol"]

    for i in range(n):
        regime = regimes[(i // regime_length) % len(regimes)]
        if regime == "uptrend":
            drift, vol = 0.0018, 0.010
        elif regime == "downtrend":
            drift, vol = -0.0018, 0.010
        elif regime == "chop":
            drift, vol = 0.0, 0.006
        elif regime == "high_vol":
            drift, vol = rng.choice([0.001, -0.001]), 0.022
        else:  # low_vol
            drift, vol = 0.0002, 0.003

        ret = rng.gauss(drift, vol)
        open_price = price
        close_price = max(1.0, price * (1 + ret))
        high_price = max(open_price, close_price) * (1 + abs(rng.gauss(0, vol * 0.3)))
        low_price = min(open_price, close_price) * (1 - abs(rng.gauss(0, vol * 0.3)))
        volume = rng.uniform(500, 5000)

        rows.append(
            {
                "timestamp": ts,
                "open": round(open_price, 2),
                "high": round(high_price, 2),
                "low": round(low_price, 2),
                "close": round(close_price, 2),
                "volume": round(volume, 2),
            }
        )
        price = close_price
        ts += TIMEFRAME_SECONDS

    return rows


def main():
    rows = generate()
    with open(OUTPUT_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["timestamp", "open", "high", "low", "close", "volume"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} synthetic 4h candles to {OUTPUT_PATH}")
    print(f"Price range: {min(r['low'] for r in rows):.0f} - {max(r['high'] for r in rows):.0f}")


if __name__ == "__main__":
    main()
