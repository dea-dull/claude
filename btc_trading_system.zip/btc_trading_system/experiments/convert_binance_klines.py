"""
Converts a raw Binance klines CSV export (columns: open_time, open, high,
low, close, volume, close_time, quote_volume, count,
taker_buy_volume, taker_buy_quote_volume, ignore -- open_time/close_time
in milliseconds) into the standard timestamp,open,high,low,close,volume
format `backtesting/data_loader.py::load_ohlcv_csv` expects.

This is a deliberately separate, explicit conversion step rather than
teaching the core loader every possible exchange export format -- the
core loader stays simple and auditable, and format quirks live here
where they're easy to see and check.

Usage:
    PYTHONPATH=src python3 experiments/convert_binance_klines.py \
        data/real/BTCUSDT-4h-2024-01.csv data/real/btc_4h_real.csv

Multiple monthly files can be concatenated (in chronological order) by
passing several input paths before the output path; this script
verifies strict ascending order across the whole concatenation and
fails loudly on any gap or overlap, rather than silently producing a
corrupt series.
"""

import csv
import sys

EXPECTED_HEADER_PREFIX = ["open_time", "open", "high", "low", "close", "volume"]


def convert(input_paths, output_path, expected_interval_ms=None):
    all_rows = []
    for path in input_paths:
        with open(path, newline="") as f:
            reader = csv.reader(f)
            header = next(reader)
            if header[:6] != EXPECTED_HEADER_PREFIX:
                raise ValueError(
                    f"{path}: unexpected header {header[:6]}, expected {EXPECTED_HEADER_PREFIX}"
                )
            for row in reader:
                open_time_ms = int(row[0])
                all_rows.append(
                    {
                        "timestamp": open_time_ms // 1000,  # ms -> seconds
                        "open": row[1], "high": row[2], "low": row[3],
                        "close": row[4], "volume": row[5],
                    }
                )

    # Verify strict ascending order and, if an expected interval was
    # given, that there are no gaps or duplicate/overlapping timestamps
    # across file boundaries (a common risk when concatenating monthly
    # exports).
    for i in range(1, len(all_rows)):
        prev_ts = all_rows[i - 1]["timestamp"]
        cur_ts = all_rows[i]["timestamp"]
        if cur_ts <= prev_ts:
            raise ValueError(
                f"Non-ascending timestamp at row {i}: {cur_ts} <= {prev_ts}. "
                "Check input file order / for overlapping months."
            )
        if expected_interval_ms is not None:
            gap = (cur_ts - prev_ts) * 1000
            if gap != expected_interval_ms:
                raise ValueError(
                    f"Gap of {gap}ms between row {i-1} and {i} "
                    f"(expected {expected_interval_ms}ms) -- missing candle(s)."
                )

    with open(output_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["timestamp", "open", "high", "low", "close", "volume"])
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"Converted {len(all_rows)} candles from {len(input_paths)} file(s) -> {output_path}")
    print(f"Range: {all_rows[0]['timestamp']} to {all_rows[-1]['timestamp']} "
          f"({(all_rows[-1]['timestamp'] - all_rows[0]['timestamp']) / 86400:.1f} days)")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    *inputs, output = sys.argv[1:]
    convert(inputs, output, expected_interval_ms=4 * 3600 * 1000)
