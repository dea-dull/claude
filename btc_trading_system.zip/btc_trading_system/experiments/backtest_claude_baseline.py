"""
Claude Baseline backtest experiment.

This is the ONLY script that should be used to run the Claude Baseline
Strategy (see docs/strategy_v1.md Section 14 and
strategy/baseline_config.py). It is deliberately a separate file from
experiments/backtest_strategy_v1.py rather than a shared --engine flag
on that script, specifically so the Baseline's prompt can never
accidentally be sourced from v1_config.PROMPT_ADDENDUM.

Prompt provenance, stated explicitly so it's auditable at a glance:
    system_prompt_extra = trading_system.strategy.baseline_config.BASELINE_PROMPT
This is the ONLY strategy-specific text injected into the Claude
prompt. Everything else this script wires in (FEATURE_ENGINE,
VALIDATOR, COST_MODEL, build_risk_limits, MAX_HOLDING_SECONDS,
SPREAD_BPS) is re-exported by baseline_config.py from v1_config
specifically because those are infrastructure -- see that module's
docstring for the full justification of what's shared and why.

This experiment requires network access and an ANTHROPIC_API_KEY,
neither of which is available in the sandboxed environment this system
was built in -- run this from an environment that has both.

Usage:
    export ANTHROPIC_API_KEY=...
    pip install anthropic
    PYTHONPATH=src python3 experiments/backtest_claude_baseline.py \\
        --data data/real/btc_4h_real.csv \\
        --funding data/real/BTCUSDT_funding.csv
"""

from __future__ import annotations

import argparse
import json
import os

from trading_system.backtesting.data_loader import load_ohlcv_csv
from trading_system.backtesting.funding_loader import load_funding_csv
from trading_system.backtesting.engine import BacktestEngine
from trading_system.decision.claude_interface import ClaudeDecisionEngine
from trading_system.exchange.mock_exchange import ReplayExchangeAdapter
from trading_system.persistence.db import EventStore
from trading_system.pipeline import TradingPipeline
from trading_system.risk.engine import RiskEngine
from trading_system.strategy import baseline_config
from trading_system.strategy.holding_period import HoldingPeriodPolicy

STARTING_BALANCE = 10_000.0
SYMBOL = "BTCUSDT"


def build_claude_engine(model_name: str = "claude-sonnet-5") -> ClaudeDecisionEngine:
    try:
        import anthropic
    except ImportError as exc:
        raise SystemExit(
            "The 'anthropic' package is required. Install it with: pip install anthropic"
        ) from exc

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise SystemExit("ANTHROPIC_API_KEY is not set in the environment.")

    client = anthropic.Anthropic(api_key=api_key)

    def call_claude(prompt: str) -> str:
        response = client.messages.create(
            model=model_name,
            max_tokens=1000,
            temperature=0,  # determinism for backtest reproducibility
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text

    # THE prompt provenance line -- baseline_config.BASELINE_PROMPT and
    # nothing else. See tests/test_claude_baseline_audit.py for the
    # automated check that this stays true.
    return ClaudeDecisionEngine(
        llm_call_fn=call_claude,
        model_name=model_name,
        system_prompt_extra=baseline_config.BASELINE_PROMPT,
    )


def run(data_path: str, funding_path: str, model_name: str) -> None:
    if not os.path.exists(data_path):
        raise SystemExit(f"Data file not found: {data_path!r}")

    candles = load_ohlcv_csv(data_path, timeframe_seconds=baseline_config.CANDLE_TIMEFRAME_SECONDS)
    print(f"Loaded {len(candles)} candles from {data_path}")
    print(f"Price range: {min(c.low for c in candles):.0f} - {max(c.high for c in candles):.0f}")

    funding_series = None
    if funding_path:
        if not os.path.exists(funding_path):
            raise SystemExit(f"Funding file not found: {funding_path!r}")
        funding_series = load_funding_csv(funding_path)
        print(f"Loaded {len(funding_series)} real funding rate rows from {funding_path}")

    exchange = ReplayExchangeAdapter(
        symbol=SYMBOL,
        candles=candles,
        starting_balance=STARTING_BALANCE,
        spread_bps=baseline_config.SPREAD_BPS,
        cost_model=baseline_config.COST_MODEL,
        funding_series=funding_series,
    )
    event_store = EventStore("experiments/results/claude_baseline_audit.sqlite3")
    risk_engine = RiskEngine(baseline_config.build_risk_limits(STARTING_BALANCE), clock=exchange.clock)
    decision_engine = build_claude_engine(model_name=model_name)

    pipeline = TradingPipeline(
        exchange=exchange,
        decision_engine=decision_engine,
        event_store=event_store,
        risk_engine=risk_engine,
        feature_engine=baseline_config.FEATURE_ENGINE,
        validator=baseline_config.VALIDATOR,
    )
    holding_period_policy = HoldingPeriodPolicy(max_holding_seconds=baseline_config.MAX_HOLDING_SECONDS)
    backtest = BacktestEngine(
        pipeline, symbol=SYMBOL, starting_balance=STARTING_BALANCE, holding_period_policy=holding_period_policy
    )

    print(f"\nRunning Claude Baseline backtest (model={model_name}) ...")
    print("Every decision's exact prompt and raw response are persisted to "
          "experiments/results/claude_baseline_audit.sqlite3 (EventStore 'DECISION' events).")
    summary = backtest.run(keep_results=False)

    from trading_system.evaluation.report import build_report_dict, format_report_text

    report = build_report_dict(summary, engine_name="claude_baseline", data_file=data_path, is_synthetic=False)
    print()
    print(format_report_text(report))

    os.makedirs("experiments/results", exist_ok=True)
    out_path = "experiments/results/claude_baseline.json"
    with open(out_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\nMachine-readable report written to {out_path}")
    print("Full per-decision audit trail (prompt + raw response + parsed decision + "
          "validation + risk decision) is in experiments/results/claude_baseline_audit.sqlite3")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, help="Path to historical OHLCV CSV")
    parser.add_argument("--funding", default=None, help="Optional path to real historical funding-rate CSV")
    parser.add_argument("--model", default="claude-sonnet-5", help="Claude model name")
    args = parser.parse_args()
    run(args.data, args.funding, args.model)
