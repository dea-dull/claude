"""
FundingRateSeries: loads a historical funding-rate CSV and provides a
strictly non-lookahead lookup by timestamp.

Expected CSV columns: timestamp,funding_rate
- `timestamp` uses the same flexible parsing as the OHLCV loader
  (epoch seconds/milliseconds or ISO-8601).
- `funding_rate` is the rate for that interval (e.g. 0.0001 = 0.01%),
  in whatever units/interval convention the source uses -- Margex's own
  funding interval (once verified) may not be 8h; if it differs,
  `CostModel.funding_interval_seconds` should be set to match, and the
  raw rate value is used as-is per accrual, not rescaled here.

`rate_at(timestamp)` returns the rate from the most recent row with a
timestamp <= the query timestamp, or None if no such row exists (e.g.
querying before the series starts). It NEVER returns a rate from a row
timestamped after the query -- this is the specific guarantee
tests/test_no_lookahead_guarantees.py checks directly.
"""

from __future__ import annotations

import bisect
import csv
from typing import List, Optional, Tuple

from trading_system.backtesting.data_loader import _parse_timestamp

REQUIRED_COLUMNS = {"timestamp", "funding_rate"}


class FundingRateSeries:
    def __init__(self, rows: List[Tuple[float, float]]):
        self._rows = sorted(rows, key=lambda r: r[0])
        self._timestamps = [r[0] for r in self._rows]

    def rate_at(self, timestamp: float) -> Optional[float]:
        """Most recent rate at or before `timestamp`. None if the query
        is earlier than the first row in the series."""
        idx = bisect.bisect_right(self._timestamps, timestamp) - 1
        if idx < 0:
            return None
        return self._rows[idx][1]

    def __len__(self) -> int:
        return len(self._rows)


def load_funding_csv(path: str) -> FundingRateSeries:
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None or not REQUIRED_COLUMNS.issubset(set(reader.fieldnames)):
            raise ValueError(
                f"Funding CSV at {path!r} is missing required columns. "
                f"Found {reader.fieldnames}, need {sorted(REQUIRED_COLUMNS)}."
            )
        rows: List[Tuple[float, float]] = []
        for row in reader:
            ts = _parse_timestamp(row["timestamp"])
            rate = float(row["funding_rate"])
            rows.append((ts, rate))
    if not rows:
        raise ValueError(f"Funding CSV at {path!r} contained a header but no data rows")
    return FundingRateSeries(rows)
