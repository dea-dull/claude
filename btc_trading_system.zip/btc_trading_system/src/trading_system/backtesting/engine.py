"""
BacktestEngine: replays a fixed list of historical Candle objects
through the exact same TradingPipeline used by paper trading and (once
it exists) live trading. The only difference from PaperTradingEngine is
where the data comes from (a fixed historical series via
ReplayExchangeAdapter, advanced with no lookahead) instead of a live
random-walk feed.

Trade outcome attribution here assumes at most one open position at a
time (the default `max_concurrent_positions=1` risk limit). With that
assumption, "the next realized-P/L change belongs to the most recently
opened trade" is unambiguous. If you configure the risk engine to allow
multiple concurrent positions, this simple FIFO attribution will no
longer be exactly correct -- that's flagged in the summary's docstring
rather than silently producing misleading per-trade stats.

Cost accounting note: the matching engine's `Position.realized_pnl`
includes price-movement P/L and funding, but NOT fees, spread, or
slippage (those only ever hit the account balance directly, since they
are due at fill time regardless of what happens to the position
afterward). This engine reconstructs the fully-costed per-trade P/L by
combining the realized-pnl delta with the fee/spread/slippage cumulative
deltas over the same window -- see `_close_trade()` below. Getting this
right matters here specifically because per-trade win rate, average
win/loss, expectancy, and profit factor are all downstream of it.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Tuple

from trading_system.core.enums import TradeAction
from trading_system.pipeline import PipelineStepResult, TradingPipeline
from trading_system.risk.engine import RiskApprovedOrder
from trading_system.strategy.holding_period import HoldingPeriodPolicy
from trading_system.strategy.regime import calendar_quarter, classify_regime


@dataclass
class OpenTradeContext:
    approved_order: RiskApprovedOrder
    entry_timestamp: float
    regime_at_entry: str
    quarter_at_entry: str
    cum_fees_at_entry: float
    cum_spread_at_entry: float
    cum_slippage_at_entry: float
    cum_funding_at_entry: float


@dataclass
class TradeOutcome:
    decision_id: str
    side: str
    entry_timestamp: float
    exit_timestamp: float
    regime_at_entry: str
    quarter_at_entry: str
    risk_amount_usd: float
    pnl_after_costs: float
    pnl_before_costs: float
    fees: float
    spread_cost: float
    slippage_cost: float
    funding_cost: float          # signed: negative = paid, positive = received
    r_multiple: float
    is_win: bool


@dataclass
class BacktestSummary:
    """NOTE: per-trade attribution (`trades`) assumes at most one open
    position at a time. See module docstring."""

    candles_processed: int
    decisions_made: int
    trades_executed: int
    trades_rejected_by_validation: int
    trades_rejected_by_risk: int
    action_counts: Dict[str, int]   # {"LONG": n, "SHORT": n, "NO_TRADE": n}
    total_realized_pnl: float       # net, after all costs (matches ending-starting equity)
    total_fees: float
    total_spread_cost: float
    total_slippage_cost: float
    total_funding: float
    num_wins: int
    num_losses: int
    win_rate: Optional[float]
    avg_win: Optional[float]
    avg_loss: Optional[float]
    avg_r_multiple: Optional[float]
    expectancy_per_trade: Optional[float]
    profit_factor: Optional[float]
    max_drawdown: float
    starting_equity: float
    ending_equity: float
    pnl_before_costs_total: float
    pnl_after_costs_total: float
    equity_curve: List[Tuple[float, float]] = field(default_factory=list)
    trades: List[TradeOutcome] = field(default_factory=list)
    step_results: List[PipelineStepResult] = field(default_factory=list)


class BacktestEngine:
    def __init__(
        self,
        pipeline: TradingPipeline,
        symbol: str,
        starting_balance: float = 10_000.0,
        holding_period_policy: Optional[HoldingPeriodPolicy] = None,
    ):
        from trading_system.exchange.mock_exchange import ReplayExchangeAdapter

        if not isinstance(pipeline.exchange, ReplayExchangeAdapter):
            raise TypeError(
                "BacktestEngine requires pipeline.exchange to be a ReplayExchangeAdapter "
                "constructed from historical candles."
            )
        self.pipeline = pipeline
        self.exchange = pipeline.exchange
        self.symbol = symbol
        self.starting_balance = starting_balance
        self.holding_period_policy = holding_period_policy

    def _current_regime_and_quarter(self, timestamp: float) -> Tuple[str, str]:
        history = self.exchange.get_recent_candles(self.symbol, timeframe_seconds=0, limit=10_000_000)
        regime = classify_regime(history, len(history) - 1)
        quarter = calendar_quarter(timestamp)
        return regime, quarter

    def run(self, keep_results: bool = False) -> BacktestSummary:
        results: List[PipelineStepResult] = []
        decisions_made = 0
        trades_executed = 0
        rejected_validation = 0
        rejected_risk = 0
        action_counts = {"LONG": 0, "SHORT": 0, "NO_TRADE": 0}

        last_cum_realized_pnl = 0.0
        pending_trades: Deque[OpenTradeContext] = deque()
        trades: List[TradeOutcome] = []

        equity_curve: List[Tuple[float, float]] = []
        starting_equity = sum(b.total for b in self.exchange.get_account())
        peak_equity = starting_equity
        max_drawdown = 0.0

        candles_processed = 0
        while not self.exchange.finished:
            self.exchange.advance()

            if self.holding_period_policy is not None:
                current_snapshot = self.exchange.get_market_snapshot(self.symbol)
                self.holding_period_policy.enforce(
                    self.exchange,
                    self.pipeline.execution_engine,
                    self.pipeline.event_store,
                    self.symbol,
                    now=current_snapshot.timestamp,
                )

            # Every close this system can produce (SL/TP fill inside
            # advance()'s check_pending_orders, or a holding-period
            # forced close just above) happens BEFORE process_tick() runs
            # -- process_tick() only ever opens NEW positions, it never
            # closes one. So close-detection and the cost snapshot for a
            # brand-new trade's baseline both belong HERE, at this exact
            # boundary -- before process_tick() can add a new trade's own
            # entry costs into the readings. Checking after process_tick()
            # (as an earlier version of this method did) silently folded
            # a same-tick new entry's cost into the trade that just closed.
            close_check_ts = self.exchange.get_market_snapshot(self.symbol).timestamp
            current_cum = self.exchange.get_cumulative_realized_pnl(self.symbol)
            delta = current_cum - last_cum_realized_pnl
            if delta != 0:
                if pending_trades:
                    ctx = pending_trades.popleft()
                    trades.append(self._close_trade(ctx, delta, close_check_ts))
                    self.pipeline.risk_engine.record_realized_pnl(trades[-1].pnl_after_costs)
                    self.pipeline.event_store.log_pnl_event(
                        trades[-1].pnl_after_costs, context={"symbol": self.symbol}
                    )
                else:
                    # A realized-pnl delta with no pending trade context
                    # (shouldn't happen under max_concurrent_positions=1,
                    # but don't silently drop the pnl feedback loop if it
                    # somehow does).
                    self.pipeline.risk_engine.record_realized_pnl(delta)
                    self.pipeline.event_store.log_pnl_event(delta, context={"symbol": self.symbol})
            last_cum_realized_pnl = current_cum

            # Cost baseline for a new trade, if process_tick() opens one
            # this tick -- taken at this same clean checkpoint, after any
            # close above and before any new open below.
            pre_entry_fees = self.exchange.get_cumulative_fees(self.symbol)
            pre_entry_spread = self.exchange.get_cumulative_spread_cost(self.symbol)
            pre_entry_slippage = self.exchange.get_cumulative_slippage_cost(self.symbol)
            pre_entry_funding = self.exchange.get_cumulative_funding(self.symbol)

            result = self.pipeline.process_tick(self.symbol)
            candles_processed += 1
            decisions_made += 1

            action = result.decision.action if result.decision.action in action_counts else None
            if action is not None:
                action_counts[action] += 1

            if not result.validation.is_valid:
                rejected_validation += 1
            elif result.risk_evaluation is not None and not result.risk_evaluation.approved:
                rejected_risk += 1
            elif (
                result.execution_result is not None
                and result.risk_evaluation
                and result.risk_evaluation.approved_order
            ):
                trades_executed += 1
                approved_order = result.risk_evaluation.approved_order
                regime, quarter = self._current_regime_and_quarter(result.snapshot.timestamp)
                pending_trades.append(
                    OpenTradeContext(
                        approved_order=approved_order,
                        entry_timestamp=result.snapshot.timestamp,
                        regime_at_entry=regime,
                        quarter_at_entry=quarter,
                        cum_fees_at_entry=pre_entry_fees,
                        cum_spread_at_entry=pre_entry_spread,
                        cum_slippage_at_entry=pre_entry_slippage,
                        cum_funding_at_entry=pre_entry_funding,
                    )
                )
                # Opening a position never itself changes realized_pnl,
                # but keep last_cum_realized_pnl authoritative regardless.
                last_cum_realized_pnl = self.exchange.get_cumulative_realized_pnl(self.symbol)

            equity = sum(b.total for b in self.exchange.get_account())
            equity_curve.append((result.snapshot.timestamp, equity))
            peak_equity = max(peak_equity, equity)
            max_drawdown = max(max_drawdown, peak_equity - equity)

            if keep_results:
                results.append(result)

        return self._build_summary(
            candles_processed, decisions_made, trades_executed, rejected_validation,
            rejected_risk, action_counts, trades, equity_curve, starting_equity,
            max_drawdown, results,
        )

    def _close_trade(self, ctx: OpenTradeContext, realized_pnl_delta: float, exit_ts: float) -> TradeOutcome:
        fees_delta = self.exchange.get_cumulative_fees(self.symbol) - ctx.cum_fees_at_entry
        spread_delta = self.exchange.get_cumulative_spread_cost(self.symbol) - ctx.cum_spread_at_entry
        slippage_delta = self.exchange.get_cumulative_slippage_cost(self.symbol) - ctx.cum_slippage_at_entry
        funding_delta = self.exchange.get_cumulative_funding(self.symbol) - ctx.cum_funding_at_entry

        # IMPORTANT: spread_delta and slippage_delta are NOT separate
        # balance deductions -- they are the (already-realized) cost of
        # a worse fill price, which is baked into realized_pnl_delta by
        # construction (a taker buy fills at the ask, a taker sell at
        # the bid; see simulated_matching.py). Subtracting them again
        # here would double-count the same dollars. Only fees and
        # funding are genuine separate account debits/credits on top of
        # price action -- see the reconciliation check in
        # tests/test_backtest_reconciliation.py, which asserts
        # sum(pnl_after_costs) matches ending-minus-starting equity
        # exactly (modulo any position still open at the end of the run).
        pnl_after_costs = realized_pnl_delta - fees_delta + funding_delta
        # "Before costs" = what this trade's price P/L would have been
        # with a perfect, spreadless, slippage-free fill and no fees/
        # funding at all -- i.e. add back the spread/slippage drag that
        # IS embedded in realized_pnl_delta, and exclude fees/funding
        # entirely (there's nothing to add back for them; they're just
        # absent in a costless world).
        pnl_before_costs = realized_pnl_delta + spread_delta + slippage_delta

        risk_amount = ctx.approved_order.risk_amount_usd
        r_multiple = pnl_after_costs / risk_amount if risk_amount else 0.0

        return TradeOutcome(
            decision_id=ctx.approved_order.decision_id,
            side=ctx.approved_order.side.value,
            entry_timestamp=ctx.entry_timestamp,
            exit_timestamp=exit_ts,
            regime_at_entry=ctx.regime_at_entry,
            quarter_at_entry=ctx.quarter_at_entry,
            risk_amount_usd=risk_amount,
            pnl_after_costs=pnl_after_costs,
            pnl_before_costs=pnl_before_costs,
            fees=fees_delta,
            spread_cost=spread_delta,
            slippage_cost=slippage_delta,
            funding_cost=funding_delta,
            r_multiple=r_multiple,
            is_win=pnl_after_costs > 0,
        )

    def _build_summary(
        self, candles_processed, decisions_made, trades_executed, rejected_validation,
        rejected_risk, action_counts, trades, equity_curve, starting_equity,
        max_drawdown, results,
    ) -> BacktestSummary:
        wins = [t for t in trades if t.is_win]
        losses = [t for t in trades if not t.is_win]
        win_rate = len(wins) / len(trades) if trades else None
        avg_win = sum(t.pnl_after_costs for t in wins) / len(wins) if wins else None
        avg_loss = sum(t.pnl_after_costs for t in losses) / len(losses) if losses else None
        avg_r = sum(t.r_multiple for t in trades) / len(trades) if trades else None
        expectancy = sum(t.pnl_after_costs for t in trades) / len(trades) if trades else None

        gross_profit = sum(t.pnl_after_costs for t in wins)
        gross_loss = abs(sum(t.pnl_after_costs for t in losses))
        profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else (None if not wins else float("inf"))

        ending_equity = equity_curve[-1][1] if equity_curve else starting_equity
        total_fees = sum(t.fees for t in trades)
        total_spread = sum(t.spread_cost for t in trades)
        total_slippage = sum(t.slippage_cost for t in trades)
        total_funding = sum(t.funding_cost for t in trades)
        pnl_before_total = sum(t.pnl_before_costs for t in trades)
        pnl_after_total = sum(t.pnl_after_costs for t in trades)

        return BacktestSummary(
            candles_processed=candles_processed,
            decisions_made=decisions_made,
            trades_executed=trades_executed,
            trades_rejected_by_validation=rejected_validation,
            trades_rejected_by_risk=rejected_risk,
            action_counts=action_counts,
            total_realized_pnl=ending_equity - starting_equity,
            total_fees=total_fees,
            total_spread_cost=total_spread,
            total_slippage_cost=total_slippage,
            total_funding=total_funding,
            num_wins=len(wins),
            num_losses=len(losses),
            win_rate=win_rate,
            avg_win=avg_win,
            avg_loss=avg_loss,
            avg_r_multiple=avg_r,
            expectancy_per_trade=expectancy,
            profit_factor=profit_factor,
            max_drawdown=max_drawdown,
            starting_equity=starting_equity,
            ending_equity=ending_equity,
            pnl_before_costs_total=pnl_before_total,
            pnl_after_costs_total=pnl_after_total,
            equity_curve=equity_curve,
            trades=trades,
            step_results=results,
        )
