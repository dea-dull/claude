"""
CSV historical data loader for BacktestEngine.

Expected CSV columns (header row required): timestamp,open,high,low,close,volume
- `timestamp` may be either UNIX epoch seconds/milliseconds (numeric) or
  an ISO-8601 datetime string (e.g. "2024-01-01T00:00:00Z").
- Rows must be in ascending time order; this loader does not sort for
  you (silently sorting could hide a data-quality bug in the source).

This is intentionally the only thing this module does: read a CSV into
a list[Candle]. It does not fetch data from anywhere. Once you have a
real historical BTC (or, eventually, real Margex) OHLCV export, point
this at that file.
"""

from __future__ import annotations

import csv
import datetime
from typing import List

from trading_system.core.models import Candle

REQUIRED_COLUMNS = {"timestamp", "open", "high", "low", "close", "volume"}


def _parse_timestamp(raw: str) -> float:
    raw = raw.strip()
    try:
        value = float(raw)
        # Heuristic: anything above ~year-5138 in seconds is almost
        # certainly milliseconds, not seconds.
        if value > 1e12:
            value /= 1000.0
        return value
    except ValueError:
        pass
    dt = datetime.datetime.fromisoformat(raw.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.timezone.utc)
    return dt.timestamp()


def load_ohlcv_csv(path: str, timeframe_seconds: int) -> List[Candle]:
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None or not REQUIRED_COLUMNS.issubset(set(reader.fieldnames)):
            raise ValueError(
                f"CSV at {path!r} is missing required columns. "
                f"Found {reader.fieldnames}, need at least {sorted(REQUIRED_COLUMNS)}."
            )
        candles: List[Candle] = []
        last_ts = None
        for row_num, row in enumerate(reader, start=2):  # header is row 1
            ts = _parse_timestamp(row["timestamp"])
            if last_ts is not None and ts <= last_ts:
                raise ValueError(
                    f"CSV at {path!r} is not in strictly ascending time order "
                    f"at row {row_num} (timestamp {ts} <= previous {last_ts}). "
                    "Fix the source data rather than have the loader silently sort it."
                )
            last_ts = ts
            candles.append(
                Candle(
                    timestamp=ts,
                    open=float(row["open"]),
                    high=float(row["high"]),
                    low=float(row["low"]),
                    close=float(row["close"]),
                    volume=float(row["volume"]),
                    timeframe_seconds=timeframe_seconds,
                )
            )
    if not candles:
        raise ValueError(f"CSV at {path!r} contained a header but no data rows")
    return candles
