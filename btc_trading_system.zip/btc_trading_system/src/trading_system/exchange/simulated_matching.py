"""
SimulatedMatchingEngine: shared order-fill and position-tracking logic
used by both MockExchangeAdapter (live-like random walk) and
ReplayExchangeAdapter (historical replay for backtesting).

This is intentionally simplistic -- it is NOT a claim about how Margex's
real matching/margin engine behaves. It exists purely so the rest of the
system (execution engine, position manager, risk engine, paper trading,
backtesting) has something realistic-shaped to run against while the
real adapter is pending.

Simplifications made explicit here so nobody mistakes them for verified
exchange behavior:
  - Market orders fill fully and immediately (no partial fills, no queue
    position). If bid/ask prices are supplied, fills cross the book
    (buy at ask, sell at bid) plus configurable slippage; if not
    supplied, fills happen at the given reference price with no spread
    cost (legacy/simple mode, used when a caller doesn't have a book).
  - Limit orders fill fully once the reference price crosses the limit
    price (no partial fills, no price-time priority against other
    traders).
  - Stop orders trigger once the reference price crosses stop_price,
    then behave like a market (STOP_MARKET) or limit (STOP_LIMIT) order.
  - Fees are configurable flat bps rates on notional (maker vs taker),
    charged on every fill. MARKET and STOP_MARKET fills are taker;
    LIMIT and STOP_LIMIT fills are maker -- this ignores the real
    possibility of a limit order being marketable (crossing the book
    immediately), which would actually be taker on most exchanges.
  - Funding is applied periodically via an explicit `accrue_funding()`
    call (not automatic), at a constant configured rate -- not derived
    from any real historical or live funding series unless the caller
    supplies one snapshot-by-snapshot.
  - Liquidation price is a simple isolated-margin approximation, not a
    verified Margex formula.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Dict, List, Optional

from trading_system.core.enums import OrderSide, OrderType, OrderStatus, PositionSide
from trading_system.core.exceptions import DuplicateOrderError, OrderRejectedError
from trading_system.core.models import (
    AccountBalance,
    Order,
    OrderRequest,
    Position,
    Fill,
    new_id,
    now_ts,
)


@dataclass(frozen=True)
class CostModel:
    """Every number here is an explicit, named assumption -- see the
    module docstring and docs/strategy_v1.md Section 12 for what each is
    based on (Margex's own advertised fee schedule where available,
    otherwise a conservative placeholder pending verified data)."""

    taker_fee_bps: float = 6.0        # MARKET / STOP_MARKET fills
    maker_fee_bps: float = 6.0        # LIMIT / STOP_LIMIT fills
    slippage_bps: float = 0.0         # additional cost on top of spread, market fills only
    funding_rate_per_interval: float = 0.0
    funding_interval_seconds: float = 28_800.0  # 8 hours


class SimulatedMatchingEngine:
    def __init__(
        self,
        starting_balance: float = 10_000.0,
        currency: str = "USDT",
        cost_model: Optional[CostModel] = None,
        clock=now_ts,
    ):
        self._clock = clock
        self.currency = currency
        self._balance_total = starting_balance
        self._balance_used = 0.0
        self.cost_model = cost_model or CostModel()

        self._orders: Dict[str, Order] = {}
        self._client_order_ids: Dict[str, str] = {}  # client_id -> order_id
        self._pending: List[str] = []  # order_ids not yet filled (limit/stop)
        self._positions: Dict[str, Position] = {}
        self._fills: List[Fill] = []
        self._last_funding_ts: Dict[str, float] = {}

        # Cumulative cost breakdown, tracked separately from realized_pnl
        # (which already nets everything out) purely so a report generator
        # can show "fees: $X, spread: $Y, slippage: $Z, funding: $W" as
        # distinct line items rather than one opaque net number.
        self._cumulative_fees: Dict[str, float] = {}
        self._cumulative_spread_cost: Dict[str, float] = {}
        self._cumulative_slippage_cost: Dict[str, float] = {}
        self._cumulative_funding: Dict[str, float] = {}
        # True all-time cumulative realized (price-movement) P/L per
        # symbol, NEVER reset -- unlike Position.realized_pnl, which
        # intentionally starts fresh at 0 every time a new position opens
        # from flat (that's correct for "P/L of the current lot" but
        # wrong for "P/L realized so far, all trades combined", which is
        # what callers doing cross-trade delta attribution need. Do not
        # read Position.realized_pnl for that purpose -- use
        # get_cumulative_realized_pnl() below instead.
        self._cumulative_price_pnl: Dict[str, float] = {}

    # -- account / positions -------------------------------------------

    def get_account(self) -> List[AccountBalance]:
        return [
            AccountBalance(
                currency=self.currency,
                total=self._balance_total,
                available=self._balance_total - self._balance_used,
                used=self._balance_used,
                timestamp=self._clock(),
            )
        ]

    def get_positions(self) -> List[Position]:
        return [p for p in self._positions.values() if p.size > 0]

    def get_open_orders(self) -> List[Order]:
        return [
            o
            for oid, o in self._orders.items()
            if o.status in (OrderStatus.OPEN, OrderStatus.PARTIALLY_FILLED)
        ]

    def get_order_status(self, order_id: str) -> Order:
        if order_id not in self._orders:
            raise OrderRejectedError(f"unknown order_id {order_id!r}")
        return self._orders[order_id]

    @property
    def fills(self) -> List[Fill]:
        return list(self._fills)

    # -- placing orders ---------------------------------------------------

    def place_order(
        self,
        request: OrderRequest,
        reference_price: float,
        best_bid: Optional[float] = None,
        best_ask: Optional[float] = None,
    ) -> Order:
        if request.client_order_id in self._client_order_ids:
            existing_id = self._client_order_ids[request.client_order_id]
            raise DuplicateOrderError(
                f"client_order_id {request.client_order_id!r} already submitted "
                f"as order_id {existing_id!r}"
            )

        order_id = new_id("ord")
        order = Order(
            order_id=order_id,
            client_order_id=request.client_order_id,
            symbol=request.symbol,
            side=request.side,
            order_type=request.order_type,
            status=OrderStatus.PENDING,
            size=request.size,
            price=request.price,
            stop_price=request.stop_price,
            created_at=self._clock(),
            updated_at=self._clock(),
            reduce_only=request.reduce_only,
        )
        self._orders[order_id] = order
        self._client_order_ids[request.client_order_id] = order_id

        if request.order_type == OrderType.MARKET:
            fill_price = self._crossed_fill_price(request.side, reference_price, best_bid, best_ask)
            base_price = best_ask if request.side == OrderSide.BUY else best_bid
            self._fill(order, fill_price, request, is_taker=True, mid_price=reference_price, crossed_base_price=base_price)
        elif request.order_type in (OrderType.STOP_MARKET, OrderType.STOP_LIMIT):
            # Only fires once reference price crosses stop_price; check now
            # in case it's already past it.
            if self._stop_triggered(request, reference_price):
                if request.order_type == OrderType.STOP_MARKET:
                    fill_price = self._crossed_fill_price(request.side, reference_price, best_bid, best_ask)
                    base_price = best_ask if request.side == OrderSide.BUY else best_bid
                    self._fill(order, fill_price, request, is_taker=True, mid_price=reference_price, crossed_base_price=base_price)
                else:
                    self._fill(order, request.price, request, is_taker=False)
            else:
                self._mark_open(order)
                self._pending.append(order_id)
        else:  # LIMIT
            if self._limit_crossed(request, reference_price):
                self._fill(order, request.price, request, is_taker=False)
            else:
                self._mark_open(order)
                self._pending.append(order_id)

        return self._orders[order_id]

    def cancel_order(self, order_id: str) -> bool:
        order = self._orders.get(order_id)
        if order is None:
            return False
        if order.status not in (OrderStatus.OPEN, OrderStatus.PARTIALLY_FILLED, OrderStatus.PENDING):
            return False
        self._orders[order_id] = replace(
            order, status=OrderStatus.CANCELLED, updated_at=self._clock()
        )
        if order_id in self._pending:
            self._pending.remove(order_id)
        return True

    # -- called every tick to check resting orders ------------------------

    def check_pending_orders(
        self,
        symbol: str,
        reference_price: float,
        best_bid: Optional[float] = None,
        best_ask: Optional[float] = None,
    ) -> List[Order]:
        """Advance simulated time: check every resting limit/stop order for
        `symbol` against the latest reference price and fill any that
        should now trigger. Returns the list of orders that were filled
        on this call.

        Iterates over a snapshot of `self._pending` (not the live list)
        because filling one order can cancel its OCO sibling mid-loop
        (see `_cancel_oco_sibling`), which would otherwise mutate
        `self._pending` while this method is iterating over it. The
        final `self._pending` is rebuilt from each order's authoritative
        status rather than incrementally, so an OCO cancellation that
        happens to an order later in this same snapshot is respected
        even though that order hasn't been visited by this loop yet.
        """
        filled: List[Order] = []
        for order_id in list(self._pending):
            order = self._orders[order_id]
            if order.status not in (OrderStatus.OPEN, OrderStatus.PENDING):
                continue  # already filled/cancelled earlier in this same pass (e.g. OCO)
            if order.symbol != symbol:
                continue
            request = OrderRequest(
                symbol=order.symbol,
                side=order.side,
                order_type=order.order_type,
                size=order.size,
                price=order.price,
                stop_price=order.stop_price,
                reduce_only=order.reduce_only,
                client_order_id=order.client_order_id,
            )
            triggered = (
                self._limit_crossed(request, reference_price)
                if order.order_type == OrderType.LIMIT
                else self._stop_triggered(request, reference_price)
            )
            if triggered:
                if order.order_type in (OrderType.LIMIT, OrderType.STOP_LIMIT):
                    self._fill(order, order.price, request, is_taker=False)
                else:
                    fill_price = self._crossed_fill_price(order.side, reference_price, best_bid, best_ask)
                    base_price = best_ask if order.side == OrderSide.BUY else best_bid
                    self._fill(order, fill_price, request, is_taker=True, mid_price=reference_price, crossed_base_price=base_price)
                filled.append(self._orders[order_id])

        self._pending = [
            oid for oid in self._pending if self._orders[oid].status in (OrderStatus.OPEN, OrderStatus.PENDING)
        ]
        return filled

    # -- funding ------------------------------------------------------------

    def accrue_funding(
        self, symbol: str, mark_price: float, timestamp: float, rate_override: Optional[float] = None
    ) -> float:
        """Apply funding for every whole interval elapsed since the last
        accrual for `symbol`. Returns the total funding payment applied
        (negative = paid out, positive = received) -- 0.0 if no position,
        no rate available, or no full interval has elapsed yet.

        `rate_override`, when given, is used instead of
        `cost_model.funding_rate_per_interval` -- this is how a real
        historical funding-rate series (see
        backtesting/funding_loader.py) takes precedence over the
        constant-rate assumption when one is available."""
        pos = self._positions.get(symbol)
        rate = rate_override if rate_override is not None else self.cost_model.funding_rate_per_interval
        interval = self.cost_model.funding_interval_seconds
        if pos is None or pos.size == 0 or rate == 0.0 or interval <= 0:
            self._last_funding_ts[symbol] = timestamp
            return 0.0

        last = self._last_funding_ts.get(symbol, timestamp)
        elapsed = timestamp - last
        num_intervals = int(elapsed // interval)
        if num_intervals <= 0:
            return 0.0

        direction = 1 if pos.side == PositionSide.LONG else -1
        # Long pays when rate > 0 (long is the "paying" side in a
        # standard perpetual funding convention); short receives.
        payment = -direction * rate * num_intervals * pos.size * mark_price
        self._balance_total += payment
        # Deliberately NOT added to pos.realized_pnl: realized_pnl must
        # stay a pure "did a close/reduce fill happen" signal (see
        # BacktestEngine's per-trade attribution, which treats any
        # realized_pnl change as a trade closing). Folding funding in
        # here would make an open position's realized_pnl change every
        # funding interval with no close having happened, corrupting
        # that attribution. Funding still correctly reduces the account
        # balance above, and is tracked separately below for reporting.
        self._positions[symbol] = replace(pos, updated_at=timestamp)
        self._cumulative_funding[symbol] = self._cumulative_funding.get(symbol, 0.0) + payment
        self._last_funding_ts[symbol] = last + num_intervals * interval
        return payment

    # -- internals ----------------------------------------------------------

    def _crossed_fill_price(
        self,
        side: OrderSide,
        reference_price: float,
        best_bid: Optional[float],
        best_ask: Optional[float],
    ) -> float:
        """Fill price for a taker (market-crossing) order. Falls back to
        the bare reference price (no spread cost) if no book was
        supplied -- kept for callers/tests that don't model a book."""
        slip = self.cost_model.slippage_bps / 10_000.0
        if side == OrderSide.BUY:
            base = best_ask if best_ask is not None else reference_price
            return base * (1 + slip)
        else:
            base = best_bid if best_bid is not None else reference_price
            return base * (1 - slip)

    def _mark_open(self, order: Order) -> None:
        self._orders[order.order_id] = replace(
            order, status=OrderStatus.OPEN, updated_at=self._clock()
        )

    @staticmethod
    def _limit_crossed(request: OrderRequest, reference_price: float) -> bool:
        if request.price is None:
            return False
        if request.side == OrderSide.BUY:
            return reference_price <= request.price
        return reference_price >= request.price

    @staticmethod
    def _stop_triggered(request: OrderRequest, reference_price: float) -> bool:
        if request.stop_price is None:
            return False
        if request.side == OrderSide.BUY:
            return reference_price >= request.stop_price
        return reference_price <= request.stop_price

    def _fill(
        self,
        order: Order,
        fill_price: float,
        request: OrderRequest,
        is_taker: bool,
        mid_price: Optional[float] = None,
        crossed_base_price: Optional[float] = None,
    ) -> None:
        fee_rate = (
            self.cost_model.taker_fee_bps if is_taker else self.cost_model.maker_fee_bps
        ) / 10_000.0
        fee = abs(fill_price * order.size) * fee_rate

        spread_cost = 0.0
        slippage_cost = 0.0
        if mid_price is not None and crossed_base_price is not None:
            spread_cost = abs(crossed_base_price - mid_price) * order.size
            slippage_cost = abs(fill_price - crossed_base_price) * order.size

        fill = Fill(
            fill_id=new_id("fill"),
            order_id=order.order_id,
            symbol=order.symbol,
            side=order.side,
            price=fill_price,
            size=order.size,
            fee=fee,
            fee_currency=self.currency,
            timestamp=self._clock(),
        )
        self._fills.append(fill)
        self._orders[order.order_id] = replace(
            order,
            status=OrderStatus.FILLED,
            filled_size=order.size,
            avg_fill_price=fill_price,
            updated_at=self._clock(),
        )
        self._balance_total -= fee
        self._cumulative_fees[order.symbol] = self._cumulative_fees.get(order.symbol, 0.0) + fee
        self._cumulative_spread_cost[order.symbol] = self._cumulative_spread_cost.get(order.symbol, 0.0) + spread_cost
        self._cumulative_slippage_cost[order.symbol] = self._cumulative_slippage_cost.get(order.symbol, 0.0) + slippage_cost
        self._apply_fill_to_position(order.symbol, order.side, fill_price, order.size, request)
        self._cancel_oco_sibling(order)

    def _cancel_oco_sibling(self, order: Order) -> None:
        """SL and TP orders for the same decision are a one-cancels-other
        (OCO) pair by convention (client_order_id `sl_<decision_id>` /
        `tp_<decision_id>`, set by ExecutionEngine). Without this, a
        filled SL leaves its TP sibling resting forever, where it can
        later fire against an unrelated future position -- a stale-order
        bug, not a cost-modeling nuance, so it's handled unconditionally
        here rather than left to callers to remember."""
        cid = order.client_order_id
        sibling_cid = None
        if cid.startswith("sl_"):
            sibling_cid = "tp_" + cid[len("sl_"):]
        elif cid.startswith("tp_"):
            sibling_cid = "sl_" + cid[len("tp_"):]
        if sibling_cid is None:
            return
        sibling_order_id = self._client_order_ids.get(sibling_cid)
        if sibling_order_id is not None:
            self.cancel_order(sibling_order_id)

    def _apply_fill_to_position(
        self,
        symbol: str,
        side: OrderSide,
        price: float,
        size: float,
        request: OrderRequest,
    ) -> None:
        existing = self._positions.get(symbol)
        direction = 1 if side == OrderSide.BUY else -1

        if existing is None or existing.size == 0:
            new_side = PositionSide.LONG if direction > 0 else PositionSide.SHORT
            leverage = max(request.leverage, 1.0)
            self._positions[symbol] = Position(
                symbol=symbol,
                side=new_side,
                size=size,
                entry_price=price,
                mark_price=price,
                leverage=leverage,
                liquidation_price=self._estimate_liquidation(price, leverage, new_side),
                unrealized_pnl=0.0,
                realized_pnl=0.0,
                opened_at=self._clock(),
                updated_at=self._clock(),
            )
            self._balance_used += (size * price) / leverage
            self._last_funding_ts.setdefault(symbol, self._clock())
            return

        existing_direction = 1 if existing.side == PositionSide.LONG else -1
        if direction == existing_direction:
            # adding to position -> weighted average entry
            total_size = existing.size + size
            new_entry = (existing.entry_price * existing.size + price * size) / total_size
            self._positions[symbol] = replace(
                existing,
                size=total_size,
                entry_price=new_entry,
                mark_price=price,
                liquidation_price=self._estimate_liquidation(
                    new_entry, existing.leverage, existing.side
                ),
                updated_at=self._clock(),
            )
        else:
            # reducing or flipping the position
            closing_size = min(size, existing.size)
            pnl_per_unit = (
                (price - existing.entry_price)
                if existing.side == PositionSide.LONG
                else (existing.entry_price - price)
            )
            realized = pnl_per_unit * closing_size
            remaining = existing.size - closing_size
            self._balance_total += realized
            self._cumulative_price_pnl[symbol] = self._cumulative_price_pnl.get(symbol, 0.0) + realized
            if remaining > 0:
                self._positions[symbol] = replace(
                    existing,
                    size=remaining,
                    mark_price=price,
                    realized_pnl=existing.realized_pnl + realized,
                    updated_at=self._clock(),
                )
            else:
                leftover = size - closing_size
                self._balance_used = max(
                    0.0, self._balance_used - (existing.size * existing.entry_price) / existing.leverage
                )
                if leftover > 0:
                    # flipped through flat into the opposite side
                    new_side = PositionSide.LONG if direction > 0 else PositionSide.SHORT
                    leverage = max(request.leverage, 1.0)
                    self._positions[symbol] = Position(
                        symbol=symbol,
                        side=new_side,
                        size=leftover,
                        entry_price=price,
                        mark_price=price,
                        leverage=leverage,
                        liquidation_price=self._estimate_liquidation(price, leverage, new_side),
                        realized_pnl=existing.realized_pnl + realized,
                        opened_at=self._clock(),
                        updated_at=self._clock(),
                    )
                    self._balance_used += (leftover * price) / leverage
                else:
                    self._positions[symbol] = replace(
                        existing,
                        size=0.0,
                        realized_pnl=existing.realized_pnl + realized,
                        updated_at=self._clock(),
                    )

    @staticmethod
    def _estimate_liquidation(
        entry_price: float, leverage: float, side: PositionSide
    ) -> float:
        """Rough isolated-margin liquidation estimate: distance is
        ~1/leverage from entry, ignoring fees/funding. This is a
        placeholder for testing position-risk logic, not a verified
        Margex formula."""
        maintenance_margin_buffer = 0.005  # 0.5%
        move = entry_price * (1.0 / leverage - maintenance_margin_buffer)
        if side == PositionSide.LONG:
            return max(0.0, entry_price - move)
        return entry_price + move

    def get_cumulative_realized_pnl(self, symbol: str) -> float:
        return self._cumulative_price_pnl.get(symbol, 0.0)

    def get_cumulative_fees(self, symbol: str) -> float:
        return self._cumulative_fees.get(symbol, 0.0)

    def get_cumulative_spread_cost(self, symbol: str) -> float:
        return self._cumulative_spread_cost.get(symbol, 0.0)

    def get_cumulative_slippage_cost(self, symbol: str) -> float:
        return self._cumulative_slippage_cost.get(symbol, 0.0)

    def get_cumulative_funding(self, symbol: str) -> float:
        return self._cumulative_funding.get(symbol, 0.0)

    def mark_positions(self, symbol: str, mark_price: float) -> None:
        pos = self._positions.get(symbol)
        if pos is None or pos.size == 0:
            return
        pnl_per_unit = (
            (mark_price - pos.entry_price)
            if pos.side == PositionSide.LONG
            else (pos.entry_price - mark_price)
        )
        self._positions[symbol] = replace(
            pos,
            mark_price=mark_price,
            unrealized_pnl=pnl_per_unit * pos.size,
            updated_at=self._clock(),
        )
