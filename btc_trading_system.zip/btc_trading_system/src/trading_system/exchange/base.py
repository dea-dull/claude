"""
ExchangeAdapter: the ONLY boundary through which this system talks to an
exchange.

No other module may import an exchange SDK, hit an exchange REST/WS URL,
or hardcode an exchange's field names. Everything above this layer
(features, decision engine, risk engine, execution engine, position
manager) works exclusively in terms of the normalized models in
`trading_system.core.models`.

Two concrete implementations exist today:
  - MockExchangeAdapter    (exchange/mock_exchange.py)   - simulated live market
  - ReplayExchangeAdapter  (exchange/mock_exchange.py)   - replays historical data

A `MargexExchangeAdapter` will be added later, once Margex's API is
verified against real documentation. It does not exist yet, and nothing
in this codebase should assume any particular Margex endpoint shape.

`LiveExchangeAdapter` is a marker base class: a real, money-moving
adapter (e.g. the future Margex adapter) must subclass it rather than
`ExchangeAdapter` directly. The system bootstrap in
`trading_system.pipeline` refuses to start in LIVE mode unless it is
handed an instance of `LiveExchangeAdapter` AND live trading has been
explicitly enabled -- see `pipeline.TradingSystem`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List, Optional

from trading_system.core.models import (
    MarketSnapshot,
    AccountBalance,
    Position,
    Order,
    OrderRequest,
    Candle,
)


class ExchangeAdapter(ABC):
    """Abstract interface every exchange connector must implement."""

    # -- Market data ---------------------------------------------------

    @abstractmethod
    def get_market_snapshot(self, symbol: str) -> MarketSnapshot:
        """Return a single, internally-consistent snapshot of current
        market state for `symbol` (last price, order book, recent trades,
        funding, open interest -- whatever is actually available)."""
        raise NotImplementedError

    @abstractmethod
    def get_recent_candles(
        self, symbol: str, timeframe_seconds: int, limit: int
    ) -> List[Candle]:
        """Return up to `limit` most-recent closed candles, oldest first."""
        raise NotImplementedError

    # -- Account / positions --------------------------------------------

    @abstractmethod
    def get_account(self) -> List[AccountBalance]:
        """Return balances for every currency/collateral asset held."""
        raise NotImplementedError

    @abstractmethod
    def get_positions(self) -> List[Position]:
        """Return all currently open positions."""
        raise NotImplementedError

    @abstractmethod
    def get_open_orders(self) -> List[Order]:
        """Return all currently open (unfilled/partially-filled) orders."""
        raise NotImplementedError

    # -- Trading ----------------------------------------------------------

    @abstractmethod
    def place_order(self, request: OrderRequest) -> Order:
        """Submit an order. Must be idempotent with respect to
        `request.client_order_id`: submitting the same client_order_id
        twice must not result in two orders on the exchange side."""
        raise NotImplementedError

    @abstractmethod
    def cancel_order(self, order_id: str) -> bool:
        """Cancel an open order. Returns True if cancellation was
        accepted (order may still fill in a race -- callers must check
        get_order_status afterward)."""
        raise NotImplementedError

    @abstractmethod
    def get_order_status(self, order_id: str) -> Order:
        """Return the current normalized state of a previously-placed
        order."""
        raise NotImplementedError

    # -- Health -----------------------------------------------------------

    def ping(self) -> bool:
        """Cheap connectivity/liveness check. Adapters may override; the
        default assumes reachability if get_account() doesn't raise."""
        try:
            self.get_account()
            return True
        except Exception:
            return False


class LiveExchangeAdapter(ExchangeAdapter):
    """
    Marker base class for adapters that place REAL orders with REAL
    money on a REAL exchange.

    Nothing in this codebase currently subclasses this. That is
    deliberate: it means SystemMode.LIVE is structurally unreachable
    until a verified Margex adapter is written and explicitly wired in.
    See `trading_system.pipeline.TradingSystem`.
    """


class SimulatedExchangeAdapter(ExchangeAdapter):
    """Marker base class for adapters that never touch a real exchange
    (mock / replay / paper). Safe to use in any SystemMode except LIVE."""

    def get_cumulative_realized_pnl(self, symbol: str) -> float:
        """Convenience for paper trading / backtesting: cumulative
        realized P/L for `symbol` across the adapter's whole lifetime,
        including from positions that have since been fully closed.

        This only exists on simulated adapters. A real exchange adapter
        would derive this from trade/fill history instead -- that
        design is deferred until Margex's actual trade-history endpoint
        (if any) is verified."""
        return 0.0
