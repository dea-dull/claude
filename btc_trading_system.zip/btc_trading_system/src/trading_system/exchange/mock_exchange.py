"""
Two SimulatedExchangeAdapter implementations:

  MockExchangeAdapter
      Generates a synthetic BTC-like price series (random walk) and a
      synthesized order book around it. Used for unit tests, pipeline
      integration tests, and interactive paper-trading demos when no
      historical dataset is being replayed.

  ReplayExchangeAdapter
      Steps deterministically through a pre-supplied list of Candle
      objects (e.g. loaded from a CSV of historical BTC prices). Used by
      the backtesting engine. No lookahead: get_market_snapshot() only
      ever exposes candles up to and including the current cursor.

Neither of these knows anything about Margex. They exist purely to let
every other layer of the system be built and tested end-to-end before a
real exchange connection exists.

Both adapters pass the synthesized best bid/ask into the matching engine
so that market-order fills cross the spread (see
exchange/simulated_matching.py), and both call `accrue_funding()` once
per tick/candle so a configured CostModel funding rate is actually
applied over time.
"""

from __future__ import annotations

import random
from typing import List, Optional

from trading_system.core.enums import OrderSide
from trading_system.core.exceptions import StaleDataError
from trading_system.core.models import (
    AccountBalance,
    Candle,
    FundingInfo,
    MarketSnapshot,
    Order,
    OrderBook,
    OrderBookLevel,
    OrderRequest,
    Position,
    PublicTrade,
    now_ts,
)
from trading_system.exchange.base import SimulatedExchangeAdapter
from trading_system.exchange.simulated_matching import CostModel, SimulatedMatchingEngine


def _synthesize_order_book(
    mid: float, spread_bps: float = 2.0, levels: int = 10, depth_unit: float = 0.5, timestamp: Optional[float] = None
) -> OrderBook:
    half_spread = mid * (spread_bps / 10_000.0) / 2.0
    bids = [
        OrderBookLevel(price=round(mid - half_spread - i * mid * 0.0002, 2), size=depth_unit * (levels - i))
        for i in range(levels)
    ]
    asks = [
        OrderBookLevel(price=round(mid + half_spread + i * mid * 0.0002, 2), size=depth_unit * (levels - i))
        for i in range(levels)
    ]
    return OrderBook(timestamp=timestamp if timestamp is not None else now_ts(), bids=bids, asks=asks)


class MockExchangeAdapter(SimulatedExchangeAdapter):
    """Simulated 'live' exchange: random-walk price, synthesized book."""

    def __init__(
        self,
        symbol: str = "BTCUSDT",
        starting_price: float = 60_000.0,
        starting_balance: float = 10_000.0,
        volatility_bps_per_tick: float = 15.0,
        spread_bps: float = 2.0,
        seed: Optional[int] = 1234,
        candle_timeframe_seconds: int = 60,
        max_candle_history: int = 500,
        cost_model: Optional[CostModel] = None,
        clock=now_ts,
    ):
        self.symbol = symbol
        self._price = starting_price
        self._volatility = volatility_bps_per_tick / 10_000.0
        self._spread_bps = spread_bps
        self._rng = random.Random(seed)
        self._clock = clock
        self._candle_timeframe = candle_timeframe_seconds
        self._max_history = max_candle_history
        self._candles: List[Candle] = []
        self._matching = SimulatedMatchingEngine(
            starting_balance=starting_balance, cost_model=cost_model, clock=clock
        )
        self._last_update_ts = clock()
        self._seed_history()

    @property
    def clock(self):
        """Public accessor for the callable this adapter uses for
        `now()`. Anything whose behavior must stay time-consistent with
        this adapter -- notably RiskEngine's daily-loss-limit day
        rollover -- should be constructed with `clock=exchange.clock`,
        not left on the default `now_ts` (real wall-clock time), or its
        notion of "today" will never match the simulated/historical
        time the backtest is actually running in.
        """
        return self._clock

    def _seed_history(self, n: int = 60) -> None:
        price = self._price
        t = self._clock() - n * self._candle_timeframe
        for _ in range(n):
            o = price
            price = self._next_price(price)
            c = price
            hi = max(o, c) * (1 + self._rng.uniform(0, 0.0005))
            lo = min(o, c) * (1 - self._rng.uniform(0, 0.0005))
            self._candles.append(
                Candle(
                    timestamp=t,
                    open=o,
                    high=hi,
                    low=lo,
                    close=c,
                    volume=self._rng.uniform(5, 50),
                    timeframe_seconds=self._candle_timeframe,
                )
            )
            t += self._candle_timeframe
        self._price = price

    def _next_price(self, price: float) -> float:
        shock = self._rng.gauss(0, self._volatility)
        return max(0.01, price * (1 + shock))

    def _book(self) -> OrderBook:
        return _synthesize_order_book(self._price, spread_bps=self._spread_bps, timestamp=self._clock())

    def tick(self) -> MarketSnapshot:
        """Advance the simulated market by one step and return the new
        snapshot. Also checks resting limit/stop orders against the new
        price and accrues funding. Call this once per loop iteration in
        paper trading."""
        self._price = self._next_price(self._price)
        self._last_update_ts = self._clock()
        last_candle = self._candles[-1]
        if self._last_update_ts - last_candle.timestamp >= self._candle_timeframe:
            self._candles.append(
                Candle(
                    timestamp=self._last_update_ts,
                    open=self._price,
                    high=self._price,
                    low=self._price,
                    close=self._price,
                    volume=self._rng.uniform(5, 50),
                    timeframe_seconds=self._candle_timeframe,
                )
            )
            if len(self._candles) > self._max_history:
                self._candles = self._candles[-self._max_history:]
        book = self._book()
        self._matching.check_pending_orders(self.symbol, self._price, book.best_bid, book.best_ask)
        self._matching.mark_positions(self.symbol, self._price)
        self._matching.accrue_funding(self.symbol, self._price, self._last_update_ts)
        return self.get_market_snapshot(self.symbol)

    # -- ExchangeAdapter interface ---------------------------------------

    def get_market_snapshot(self, symbol: str) -> MarketSnapshot:
        book = self._book()
        trades = [
            PublicTrade(
                timestamp=self._clock(),
                price=self._price * (1 + self._rng.uniform(-0.0002, 0.0002)),
                size=self._rng.uniform(0.01, 2.0),
                side=self._rng.choice([OrderSide.BUY, OrderSide.SELL]),
            )
            for _ in range(5)
        ]
        return MarketSnapshot(
            symbol=symbol,
            timestamp=self._clock(),
            last_price=self._price,
            order_book=book,
            recent_trades=trades,
            recent_candles=list(self._candles[-100:]),
            funding=None,
            open_interest=None,
        )

    def get_recent_candles(self, symbol: str, timeframe_seconds: int, limit: int) -> List[Candle]:
        return list(self._candles[-limit:])

    def get_account(self) -> List[AccountBalance]:
        return self._matching.get_account()

    def get_positions(self) -> List[Position]:
        return self._matching.get_positions()

    def get_open_orders(self) -> List[Order]:
        return self._matching.get_open_orders()

    def place_order(self, request: OrderRequest) -> Order:
        book = self._book()
        return self._matching.place_order(
            request, reference_price=self._price, best_bid=book.best_bid, best_ask=book.best_ask
        )

    def cancel_order(self, order_id: str) -> bool:
        return self._matching.cancel_order(order_id)

    def get_order_status(self, order_id: str) -> Order:
        return self._matching.get_order_status(order_id)

    def get_cumulative_realized_pnl(self, symbol: str) -> float:
        return self._matching.get_cumulative_realized_pnl(symbol)

    def get_cumulative_fees(self, symbol: str) -> float:
        return self._matching.get_cumulative_fees(symbol)

    def get_cumulative_spread_cost(self, symbol: str) -> float:
        return self._matching.get_cumulative_spread_cost(symbol)

    def get_cumulative_slippage_cost(self, symbol: str) -> float:
        return self._matching.get_cumulative_slippage_cost(symbol)

    def get_cumulative_funding(self, symbol: str) -> float:
        return self._matching.get_cumulative_funding(symbol)


class ReplayExchangeAdapter(SimulatedExchangeAdapter):
    """Steps through a fixed, pre-loaded candle series. Used for
    backtesting. `advance()` moves the cursor forward by one candle;
    get_market_snapshot() only ever sees data up to the current cursor
    (no lookahead)."""

    def __init__(
        self,
        symbol: str,
        candles: List[Candle],
        starting_balance: float = 10_000.0,
        spread_bps: float = 2.0,
        max_staleness_seconds: Optional[float] = None,
        cost_model: Optional[CostModel] = None,
        funding_series=None,
        clock=None,
    ):
        if not candles:
            raise ValueError("ReplayExchangeAdapter requires at least one candle")
        self.symbol = symbol
        self._candles = list(candles)
        self._cursor = 0
        self._spread_bps = spread_bps
        self._max_staleness = max_staleness_seconds
        # Optional real historical funding-rate series -- duck-typed
        # (only needs a `.rate_at(timestamp) -> Optional[float]` method)
        # rather than a hard import, to avoid a backtesting<->exchange
        # circular import. See backtesting/funding_loader.py.
        # `.rate_at(ts)` MUST NOT return a rate from after `ts` -- that
        # guarantee lives in the loader, not here; see
        # tests/test_no_lookahead_guarantees.py.
        self._funding_series = funding_series
        # Simulated clock: reports the timestamp of the current candle
        # rather than wall-clock time, so backtests are reproducible.
        self._clock = clock or (lambda: self._candles[self._cursor].timestamp)
        self._matching = SimulatedMatchingEngine(
            starting_balance=starting_balance, cost_model=cost_model, clock=self._clock
        )

    @property
    def clock(self):
        """Public accessor for the callable this adapter uses for
        `now()`. Anything whose behavior must stay time-consistent with
        this adapter -- notably RiskEngine's daily-loss-limit day
        rollover -- should be constructed with `clock=exchange.clock`,
        not left on the default `now_ts` (real wall-clock time). In a
        backtest, real wall-clock time barely moves during the whole
        run, so "today" from RiskEngine's perspective would never
        change and any daily-loss circuit breaker that trips once would
        never reset for the rest of the backtest. See
        tests/test_risk_engine_clock_wiring.py.
        """
        return self._clock

    @property
    def finished(self) -> bool:
        return self._cursor >= len(self._candles) - 1

    def _book(self) -> OrderBook:
        current = self._candles[self._cursor]
        return _synthesize_order_book(current.close, spread_bps=self._spread_bps, timestamp=current.timestamp)

    def _funding_rate_at(self, timestamp: float) -> Optional[float]:
        if self._funding_series is None:
            return None
        return self._funding_series.rate_at(timestamp)

    def advance(self) -> MarketSnapshot:
        if self.finished:
            raise StopIteration("ReplayExchangeAdapter has reached the end of its data")
        self._cursor += 1
        price = self._candles[self._cursor].close
        ts = self._candles[self._cursor].timestamp
        book = self._book()
        self._matching.check_pending_orders(self.symbol, price, book.best_bid, book.best_ask)
        self._matching.mark_positions(self.symbol, price)
        self._matching.accrue_funding(self.symbol, price, ts, rate_override=self._funding_rate_at(ts))
        return self.get_market_snapshot(self.symbol)

    def get_market_snapshot(self, symbol: str) -> MarketSnapshot:
        current = self._candles[self._cursor]
        history = self._candles[: self._cursor + 1]
        book = self._book()
        funding = None
        rate = self._funding_rate_at(current.timestamp)
        if rate is not None:
            funding = FundingInfo(timestamp=current.timestamp, rate=rate)
        return MarketSnapshot(
            symbol=symbol,
            timestamp=current.timestamp,
            last_price=current.close,
            order_book=book,
            recent_trades=[],
            recent_candles=list(history[-100:]),
            funding=funding,
        )

    def get_recent_candles(self, symbol: str, timeframe_seconds: int, limit: int) -> List[Candle]:
        history = self._candles[: self._cursor + 1]
        return list(history[-limit:])

    def get_account(self) -> List[AccountBalance]:
        return self._matching.get_account()

    def get_positions(self) -> List[Position]:
        return self._matching.get_positions()

    def get_open_orders(self) -> List[Order]:
        return self._matching.get_open_orders()

    def place_order(self, request: OrderRequest) -> Order:
        current_price = self._candles[self._cursor].close
        book = self._book()
        return self._matching.place_order(
            request, reference_price=current_price, best_bid=book.best_bid, best_ask=book.best_ask
        )

    def cancel_order(self, order_id: str) -> bool:
        return self._matching.cancel_order(order_id)

    def get_order_status(self, order_id: str) -> Order:
        return self._matching.get_order_status(order_id)

    def get_cumulative_realized_pnl(self, symbol: str) -> float:
        return self._matching.get_cumulative_realized_pnl(symbol)

    def get_cumulative_fees(self, symbol: str) -> float:
        return self._matching.get_cumulative_fees(symbol)

    def get_cumulative_spread_cost(self, symbol: str) -> float:
        return self._matching.get_cumulative_spread_cost(symbol)

    def get_cumulative_slippage_cost(self, symbol: str) -> float:
        return self._matching.get_cumulative_slippage_cost(symbol)

    def get_cumulative_funding(self, symbol: str) -> float:
        return self._matching.get_cumulative_funding(symbol)
