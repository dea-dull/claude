"""
Shared backtest report generation: text summary + a JSON-serializable
dict, used identically by the Strategy V1 experiment and the Claude
Baseline experiment so the two are directly comparable.

Regime and calendar-quarter breakdowns use the FROZEN definitions in
strategy/regime.py, applied to each trade's `regime_at_entry` /
`quarter_at_entry` (already computed at entry time by BacktestEngine,
using only data available at that timestamp -- see
tests/test_no_lookahead_guarantees.py and tests/test_regime.py).
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List

from trading_system.backtesting.engine import BacktestSummary, TradeOutcome


def _bucket_stats(trades: List[TradeOutcome]) -> Dict[str, Any]:
    if not trades:
        return {
            "num_trades": 0, "win_rate": None, "avg_win": None, "avg_loss": None,
            "expectancy": None, "profit_factor": None, "total_pnl": 0.0,
        }
    wins = [t for t in trades if t.is_win]
    losses = [t for t in trades if not t.is_win]
    gross_profit = sum(t.pnl_after_costs for t in wins)
    gross_loss = abs(sum(t.pnl_after_costs for t in losses))
    return {
        "num_trades": len(trades),
        "win_rate": len(wins) / len(trades),
        "avg_win": (sum(t.pnl_after_costs for t in wins) / len(wins)) if wins else None,
        "avg_loss": (sum(t.pnl_after_costs for t in losses) / len(losses)) if losses else None,
        "expectancy": sum(t.pnl_after_costs for t in trades) / len(trades),
        "profit_factor": (gross_profit / gross_loss) if gross_loss > 0 else (float("inf") if wins else None),
        "total_pnl": sum(t.pnl_after_costs for t in trades),
    }


def build_report_dict(
    summary: BacktestSummary,
    *,
    engine_name: str,
    data_file: str,
    is_synthetic: bool,
) -> Dict[str, Any]:
    net_pnl = summary.ending_equity - summary.starting_equity
    net_pnl_pct = (net_pnl / summary.starting_equity) * 100 if summary.starting_equity else None

    by_regime: Dict[str, List[TradeOutcome]] = defaultdict(list)
    by_quarter: Dict[str, List[TradeOutcome]] = defaultdict(list)
    for t in summary.trades:
        by_regime[t.regime_at_entry].append(t)
        by_quarter[t.quarter_at_entry].append(t)

    return {
        "engine": engine_name,
        "data_file": data_file,
        "is_synthetic": is_synthetic,
        "decisions": {
            "total": summary.decisions_made,
            "candles_processed": summary.candles_processed,
            "action_counts": dict(summary.action_counts),
            "trades_executed": summary.trades_executed,
            "rejected_by_validation": summary.trades_rejected_by_validation,
            "rejected_by_risk": summary.trades_rejected_by_risk,
        },
        "overall": _bucket_stats(summary.trades),
        "avg_r_multiple": summary.avg_r_multiple,
        "max_drawdown": summary.max_drawdown,
        "equity": {
            "starting": summary.starting_equity,
            "ending": summary.ending_equity,
            "net_pnl": net_pnl,
            "net_pnl_pct": net_pnl_pct,
        },
        "costs": {
            "total_fees": summary.total_fees,
            "total_spread_cost": summary.total_spread_cost,
            "total_slippage_cost": summary.total_slippage_cost,
            "total_funding": summary.total_funding,
        },
        "performance_before_costs": {
            "total_pnl": summary.pnl_before_costs_total,
        },
        "performance_after_costs": {
            "total_pnl": summary.pnl_after_costs_total,
        },
        "by_regime": {regime: _bucket_stats(trades) for regime, trades in by_regime.items()},
        "by_quarter": {quarter: _bucket_stats(trades) for quarter, trades in sorted(by_quarter.items())},
    }


def format_report_text(report: Dict[str, Any]) -> str:
    lines = []
    a = lines.append
    a("=" * 72)
    a("BACKTEST REPORT")
    a("=" * 72)
    a(f"engine:                        {report['engine']}")
    a(f"data file:                     {report['data_file']}" + (" (SYNTHETIC)" if report["is_synthetic"] else ""))
    d = report["decisions"]
    a(f"candles processed:             {d['candles_processed']}")
    a(f"decisions made:                {d['total']}")
    ac = d["action_counts"]
    a(f"  LONG / SHORT / NO_TRADE:     {ac.get('LONG', 0)} / {ac.get('SHORT', 0)} / {ac.get('NO_TRADE', 0)}")
    a(f"trades executed (opens):       {d['trades_executed']}")
    a(f"rejected by validation:        {d['rejected_by_validation']}")
    a(f"rejected by risk engine:       {d['rejected_by_risk']}")
    a("-" * 72)
    o = report["overall"]
    a(f"closed trades:                 {o['num_trades']}")
    a(f"win rate:                      {o['win_rate']}")
    a(f"avg win / avg loss:            {o['avg_win']} / {o['avg_loss']}")
    a(f"expectancy per trade:          {o['expectancy']}")
    a(f"profit factor:                 {o['profit_factor']}")
    a(f"avg R multiple:                {report['avg_r_multiple']}")
    a(f"max drawdown:                  {report['max_drawdown']:.2f}")
    a("-" * 72)
    c = report["costs"]
    a(f"total fees:                    {c['total_fees']:.2f}")
    a(f"total spread cost:             {c['total_spread_cost']:.2f}")
    a(f"total slippage cost:           {c['total_slippage_cost']:.2f}")
    a(f"total funding (signed):        {c['total_funding']:.2f}")
    a(f"performance BEFORE costs:      {report['performance_before_costs']['total_pnl']:.2f}")
    a(f"performance AFTER costs:       {report['performance_after_costs']['total_pnl']:.2f}")
    e = report["equity"]
    a(f"starting -> ending equity:     {e['starting']:.2f} -> {e['ending']:.2f}")
    a(f"net P/L (equity-based):        {e['net_pnl']:.2f} ({e['net_pnl_pct']:+.2f}%)")
    a("-" * 72)
    a("BY REGIME (frozen definition -- see strategy/regime.py):")
    for regime, stats in report["by_regime"].items():
        a(
            f"  {regime:8s} n={stats['num_trades']:<4d} win_rate={stats['win_rate']} "
            f"expectancy={stats['expectancy']} total_pnl={stats['total_pnl']}"
        )
    a("BY CALENDAR QUARTER:")
    for quarter, stats in report["by_quarter"].items():
        a(
            f"  {quarter:8s} n={stats['num_trades']:<4d} win_rate={stats['win_rate']} "
            f"expectancy={stats['expectancy']} total_pnl={stats['total_pnl']}"
        )
    a("=" * 72)
    return "\n".join(lines)
