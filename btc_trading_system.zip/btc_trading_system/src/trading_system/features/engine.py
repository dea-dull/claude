"""
FeatureEngine: turns a raw MarketSnapshot into a FeatureSet of derived
indicators.

Design constraints:
  - Pure, deterministic functions -- no I/O, no randomness, no calls to
    Claude or any exchange. Fully unit-testable in isolation.
  - Only ever looks at `snapshot.recent_candles` / `snapshot.order_book`
    as they exist AT `snapshot.timestamp`. No lookahead is possible
    because the caller controls what candles are in the snapshot.
  - Implemented with the standard library only (no numpy/pandas
    dependency) so this module has zero third-party dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import List, Optional

from trading_system.core.models import Candle, MarketSnapshot


@dataclass(frozen=True)
class FeatureSet:
    symbol: str
    timestamp: float
    last_price: float

    sma_fast: Optional[float] = None
    sma_slow: Optional[float] = None
    ema_fast: Optional[float] = None
    ema_slow: Optional[float] = None
    rsi: Optional[float] = None
    atr: Optional[float] = None
    realized_vol: Optional[float] = None       # stdev of log returns
    momentum: Optional[float] = None           # % change over lookback
    spread: Optional[float] = None
    spread_bps: Optional[float] = None
    order_book_imbalance: Optional[float] = None
    funding_rate: Optional[float] = None
    open_interest: Optional[float] = None
    candles_available: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


def _sma(values: List[float], period: int) -> Optional[float]:
    if len(values) < period:
        return None
    window = values[-period:]
    return sum(window) / period


def _ema_series(values: List[float], period: int) -> List[float]:
    if not values:
        return []
    k = 2.0 / (period + 1)
    ema = [values[0]]
    for v in values[1:]:
        ema.append(v * k + ema[-1] * (1 - k))
    return ema


def _ema(values: List[float], period: int) -> Optional[float]:
    if len(values) < period:
        return None
    return _ema_series(values, period)[-1]


def _rsi(closes: List[float], period: int = 14) -> Optional[float]:
    if len(closes) < period + 1:
        return None
    gains, losses = [], []
    window = closes[-(period + 1):]
    for i in range(1, len(window)):
        delta = window[i] - window[i - 1]
        gains.append(max(delta, 0.0))
        losses.append(max(-delta, 0.0))
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))


def _atr(candles: List[Candle], period: int = 14) -> Optional[float]:
    if len(candles) < period + 1:
        return None
    trs = []
    window = candles[-(period + 1):]
    for i in range(1, len(window)):
        prev_close = window[i - 1].close
        c = window[i]
        tr = max(
            c.high - c.low,
            abs(c.high - prev_close),
            abs(c.low - prev_close),
        )
        trs.append(tr)
    return sum(trs) / period


def _realized_vol(closes: List[float], period: int = 20) -> Optional[float]:
    if len(closes) < period + 1:
        return None
    window = closes[-(period + 1):]
    returns = []
    for i in range(1, len(window)):
        if window[i - 1] <= 0:
            return None
        returns.append((window[i] / window[i - 1]) - 1.0)
    mean = sum(returns) / len(returns)
    variance = sum((r - mean) ** 2 for r in returns) / len(returns)
    return variance ** 0.5


def _momentum(closes: List[float], lookback: int = 10) -> Optional[float]:
    if len(closes) < lookback + 1:
        return None
    past = closes[-(lookback + 1)]
    if past == 0:
        return None
    return (closes[-1] / past) - 1.0


class FeatureEngine:
    """Stateless; all configuration is passed in at construction so
    behavior is explicit and testable."""

    def __init__(
        self,
        sma_fast_period: int = 20,
        sma_slow_period: int = 50,
        ema_fast_period: int = 12,
        ema_slow_period: int = 26,
        rsi_period: int = 14,
        atr_period: int = 14,
        vol_period: int = 20,
        momentum_lookback: int = 10,
        order_book_depth: int = 5,
    ):
        self.sma_fast_period = sma_fast_period
        self.sma_slow_period = sma_slow_period
        self.ema_fast_period = ema_fast_period
        self.ema_slow_period = ema_slow_period
        self.rsi_period = rsi_period
        self.atr_period = atr_period
        self.vol_period = vol_period
        self.momentum_lookback = momentum_lookback
        self.order_book_depth = order_book_depth

    def compute(self, snapshot: MarketSnapshot) -> FeatureSet:
        candles = snapshot.recent_candles
        closes = [c.close for c in candles]

        spread = snapshot.order_book.spread if snapshot.order_book else None
        spread_bps = (
            (spread / snapshot.last_price) * 10_000.0
            if spread is not None and snapshot.last_price
            else None
        )
        imbalance = (
            snapshot.order_book.imbalance(depth=self.order_book_depth)
            if snapshot.order_book
            else None
        )

        return FeatureSet(
            symbol=snapshot.symbol,
            timestamp=snapshot.timestamp,
            last_price=snapshot.last_price,
            sma_fast=_sma(closes, self.sma_fast_period),
            sma_slow=_sma(closes, self.sma_slow_period),
            ema_fast=_ema(closes, self.ema_fast_period),
            ema_slow=_ema(closes, self.ema_slow_period),
            rsi=_rsi(closes, self.rsi_period),
            atr=_atr(candles, self.atr_period),
            realized_vol=_realized_vol(closes, self.vol_period),
            momentum=_momentum(closes, self.momentum_lookback),
            spread=spread,
            spread_bps=spread_bps,
            order_book_imbalance=imbalance,
            funding_rate=snapshot.funding.rate if snapshot.funding else None,
            open_interest=snapshot.open_interest.value if snapshot.open_interest else None,
            candles_available=len(candles),
        )
