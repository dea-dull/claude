"""
ExecutionEngine: the ONLY component in the system permitted to call
`exchange.place_order()` / `cancel_order()`.

It receives a `RiskApprovedOrder` -- never a raw TradeDecision, and
never anything straight from Claude. If risk_engine hasn't approved
something, execution_engine structurally cannot see it.

Responsibilities:
  - Translate a RiskApprovedOrder into one or more OrderRequests
    (entry, plus separate reduce-only stop-loss and take-profit orders,
    since we cannot assume any exchange supports native bracket orders
    until Margex's API is verified).
  - Enforce duplicate-order protection: a given decision_id can only
    ever be executed once, via deterministic client_order_ids AND a
    local "already executed" set, independent of whatever idempotency
    the exchange itself may or may not provide.
  - Do NOT decide whether to trade, how much, or at what risk -- that
    already happened upstream. This class is mechanical.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from trading_system.core.enums import OrderSide, OrderType, TimeInForce
from trading_system.core.exceptions import DuplicateOrderError
from trading_system.core.models import Order, OrderRequest, now_ts
from trading_system.exchange.base import ExchangeAdapter
from trading_system.risk.engine import RiskApprovedOrder


@dataclass(frozen=True)
class ExecutionResult:
    decision_id: str
    entry_order: Order
    stop_loss_order: Optional[Order]
    take_profit_order: Optional[Order]
    timestamp: float


def _opposite(side: OrderSide) -> OrderSide:
    return OrderSide.SELL if side == OrderSide.BUY else OrderSide.BUY


class ExecutionEngine:
    def __init__(self, exchange: ExchangeAdapter):
        self._exchange = exchange
        self._executed_decision_ids: set[str] = set()

    @property
    def executed_decision_ids(self) -> frozenset[str]:
        return frozenset(self._executed_decision_ids)

    def execute(self, approved_order: RiskApprovedOrder) -> ExecutionResult:
        if approved_order.decision_id in self._executed_decision_ids:
            raise DuplicateOrderError(
                f"decision_id {approved_order.decision_id!r} was already executed -- "
                "refusing to submit a second time"
            )

        entry_request = OrderRequest(
            symbol=approved_order.symbol,
            side=approved_order.side,
            order_type=approved_order.order_type,
            size=approved_order.size,
            price=approved_order.limit_price,
            time_in_force=TimeInForce.GTC,
            reduce_only=False,
            leverage=approved_order.leverage,
            client_order_id=f"entry_{approved_order.decision_id}",
        )
        entry_order = self._exchange.place_order(entry_request)

        exit_side = _opposite(approved_order.side)

        sl_request = OrderRequest(
            symbol=approved_order.symbol,
            side=exit_side,
            order_type=OrderType.STOP_MARKET,
            size=approved_order.size,
            stop_price=approved_order.stop_loss,
            reduce_only=True,
            leverage=approved_order.leverage,
            client_order_id=f"sl_{approved_order.decision_id}",
        )
        stop_loss_order = self._exchange.place_order(sl_request)

        tp_request = OrderRequest(
            symbol=approved_order.symbol,
            side=exit_side,
            order_type=OrderType.LIMIT,
            size=approved_order.size,
            price=approved_order.take_profit,
            reduce_only=True,
            leverage=approved_order.leverage,
            client_order_id=f"tp_{approved_order.decision_id}",
        )
        take_profit_order = self._exchange.place_order(tp_request)

        self._executed_decision_ids.add(approved_order.decision_id)

        return ExecutionResult(
            decision_id=approved_order.decision_id,
            entry_order=entry_order,
            stop_loss_order=stop_loss_order,
            take_profit_order=take_profit_order,
            timestamp=now_ts(),
        )

    def close_position_at_market(
        self, symbol: str, side: OrderSide, size: float, reason_id: str
    ) -> Order:
        """Submit a single reduce-only MARKET order to close (or reduce)
        a position, outside the decision/risk-approved-order flow.

        This exists for hard, code-enforced exits that are NOT Claude
        decisions -- currently only `strategy.holding_period.HoldingPeriodPolicy`
        calls this. `reason_id` must be a caller-supplied, deterministic
        identifier (not a decision_id) so repeated calls for the same
        real-world event collide on `client_order_id` and raise
        DuplicateOrderError rather than closing twice.
        """
        request = OrderRequest(
            symbol=symbol,
            side=side,
            order_type=OrderType.MARKET,
            size=size,
            reduce_only=True,
            client_order_id=f"forceclose_{reason_id}",
        )
        return self._exchange.place_order(request)
