"""
Claude Baseline Strategy configuration.

Purpose: establish what genuine Claude judgment can actually do on real
historical BTC data, using a deliberately minimal prompt -- NOT the
Strategy V1 condition-counting rules (trend/RSI-band/momentum/vol,
2-of-4). V1 was rejected (negative expectancy even at zero cost); this
experiment does not carry any of its decision logic forward. Reusing
V1's *system-level* configuration (feature engine periods, risk limits,
cost model, decision validator's safety floors) is a deliberate choice,
explained below -- it is infrastructure, not trading logic.

What IS shared with Strategy V1, and why that's not "carrying over the
rules":
  - FEATURE_ENGINE: the same indicators are *computed and shown* to
    Claude, but nothing tells Claude how to use them or which
    combinations to look for. Withholding indicators entirely would
    make this a different (and probably worse) test of "can Claude
    read a chart", not a fair test of judgment.
  - VALIDATOR / risk limits / cost model / holding period: these are
    safety rails and cost realism, identical to V1 so the two
    experiments are comparable on equal footing. They constrain what a
    decision must look like structurally (stop-loss present, on the
    correct side, minimum R:R, ATR-bounded stop distance) -- they do
    not tell Claude when to trade or in which direction.

What is NOT shared: the prompt. BASELINE_PROMPT below contains no
condition-counting logic, no RSI/momentum/volatility thresholds, and no
"combine at least two of the following" scaffolding. It states the
schema and the one substantive instruction (decide based only on what's
given; NO_TRADE is a legitimate and expected answer) and nothing else.
"""

from __future__ import annotations

# Re-exported from v1_config because these are system infrastructure,
# not strategy logic -- see module docstring.
from trading_system.strategy.v1_config import (  # noqa: F401
    CANDLE_TIMEFRAME_SECONDS,
    COST_MODEL,
    DECISION_INTERVAL_SECONDS,
    FEATURE_ENGINE,
    MAX_HOLDING_SECONDS,
    SPREAD_BPS,
    VALIDATOR,
    build_risk_limits,
)

BASELINE_PROMPT = """\
You are the decision-making component of a BTC perpetual futures \
trading system. You will be shown a market snapshot (price, order \
book, recent candles, computed technical features, and funding rate \
if available) for one point in time. Base your decision only on this \
information -- you do not have access to anything else (no news, no \
on-chain data, no information from before or after what is shown).

Decide whether to go LONG, SHORT, or NO_TRADE. NO_TRADE is a normal \
and expected answer -- most snapshots will not present a clear \
opportunity, and there is no requirement or expectation to trade on \
every decision.

If you choose LONG or SHORT, you must also specify:
- your confidence (0.0 to 1.0)
- an entry (market order, at the current price)
- a stop-loss level
- a take-profit level
- your intended holding horizon (how long you'd expect to hold this \
position before it should be closed if neither stop nor target is hit)
- your reasoning

You do not decide position size -- that is handled separately based \
on account risk parameters, independent of your confidence level.
"""
