"""
HoldingPeriodPolicy: enforces a maximum position age as a hard, code-only
rule -- independent of anything Claude would say if asked "should I
still hold this."

This is deliberately NOT part of RiskEngine (which only ever evaluates
NEW decisions) or DecisionValidator (which only ever evaluates Claude's
output). It runs once per tick, before the decision cycle, and can
directly force-close a position through `ExecutionEngine.close_position_at_market`
-- the one other sanctioned path into `exchange.place_order()` besides
risk-approved entries.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from trading_system.core.enums import OrderSide, PositionSide
from trading_system.core.exceptions import DuplicateOrderError
from trading_system.core.models import Order
from trading_system.exchange.base import ExchangeAdapter
from trading_system.execution.engine import ExecutionEngine
from trading_system.persistence.db import EventStore


def _opposite(side: PositionSide) -> OrderSide:
    return OrderSide.SELL if side == PositionSide.LONG else OrderSide.BUY


@dataclass(frozen=True)
class HoldingPeriodPolicy:
    max_holding_seconds: float

    def enforce(
        self,
        exchange: ExchangeAdapter,
        execution_engine: ExecutionEngine,
        event_store: EventStore,
        symbol: str,
        now: float,
    ) -> Optional[Order]:
        """Check every open position for `symbol` against the age limit
        and force-close (reduce-only market order) any that have expired.
        Returns the close Order if one was submitted, else None."""
        for position in exchange.get_positions():
            if position.symbol != symbol or position.size <= 0:
                continue
            age = now - position.opened_at
            if age < self.max_holding_seconds:
                continue

            reason_id = f"{symbol}_{int(position.opened_at)}"
            try:
                order = execution_engine.close_position_at_market(
                    symbol=symbol,
                    side=_opposite(position.side),
                    size=position.size,
                    reason_id=reason_id,
                )
            except DuplicateOrderError:
                # Already force-closed for this position's open timestamp
                # (e.g. called twice in the same tick) -- not an error.
                return None

            # The SL/TP bracket orders for whatever decision opened this
            # position are now stale (the position they were meant to
            # protect no longer exists at that size). Cancel any
            # remaining open orders for this symbol so they can't fire
            # against a later, unrelated position -- this only works
            # correctly under max_concurrent_positions=1, which is the
            # only setting this project currently exercises.
            for open_order in exchange.get_open_orders():
                if open_order.symbol == symbol:
                    exchange.cancel_order(open_order.order_id)

            event_store.log_event(
                "HOLDING_PERIOD_FORCE_CLOSE",
                {
                    "symbol": symbol,
                    "position_side": position.side.value,
                    "size": position.size,
                    "opened_at": position.opened_at,
                    "age_seconds": age,
                    "max_holding_seconds": self.max_holding_seconds,
                },
                correlation_id=reason_id,
            )
            return order
        return None
