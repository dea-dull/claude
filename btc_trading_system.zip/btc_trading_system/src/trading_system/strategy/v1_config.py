"""
Strategy V1 configuration -- the numbers in this file ARE the spec in
docs/strategy_v1.md, translated into the objects the rest of the system
already understands. If you change a number here, update the doc (and
vice versa) so the two never drift apart.
"""

from __future__ import annotations

from trading_system.decision.validator import DecisionValidator
from trading_system.exchange.simulated_matching import CostModel
from trading_system.features.engine import FeatureEngine
from trading_system.risk.config import RiskLimits

# -- decision cadence -----------------------------------------------------

DECISION_INTERVAL_SECONDS = 4 * 3600  # 4 hours, matches candle timeframe
CANDLE_TIMEFRAME_SECONDS = 4 * 3600

# -- holding period ---------------------------------------------------------

MAX_HOLDING_SECONDS = 48 * 3600  # 48 hours = 12 bars of 4h

# -- feature engine (period counts are in candles, i.e. 4h bars) -----------

FEATURE_ENGINE = FeatureEngine(
    sma_fast_period=12,   # 2 days
    sma_slow_period=48,   # 8 days
    ema_fast_period=12,
    ema_slow_period=26,
    rsi_period=14,
    atr_period=14,
    vol_period=20,
    momentum_lookback=12,
    order_book_depth=5,
)

# -- decision validation (structural + strategy-specific) ------------------

VALIDATOR = DecisionValidator(
    min_confidence=0.0,
    max_confidence=1.0,
    max_entry_deviation_pct=0.02,   # tighter than scaffold default (0.03) -- MARKET-only entries
    allowed_time_horizons=None,      # any non-empty string accepted
    min_risk_reward=1.2,
    stop_atr_multiple_range=(0.5, 4.0),
)

# -- risk limits (equity-relative; instantiate with actual starting equity) --


def build_risk_limits(starting_equity_usd: float) -> RiskLimits:
    return RiskLimits(
        max_position_size_usd=starting_equity_usd * 0.30,
        max_leverage=2.0,
        risk_per_trade_pct=0.005,           # 0.5%
        max_loss_per_trade_usd=starting_equity_usd * 0.005,
        max_daily_loss_usd=starting_equity_usd * 0.02,
        max_concurrent_positions=1,
        max_position_pct_of_equity=0.30,
        min_confidence_to_trade=0.60,
        require_stop_loss=True,
        trading_enabled=True,
    )


# -- cost model (see docs/strategy_v1.md Section 12 for the reasoning
# behind each number) --------------------------------------------------------

COST_MODEL = CostModel(
    taker_fee_bps=6.0,     # 0.06% -- Margex's advertised taker fee
    maker_fee_bps=1.9,     # 0.019% -- Margex's advertised maker fee
    slippage_bps=2.0,      # additional assumed impact beyond quoted spread
    funding_rate_per_interval=0.0001,   # UNVERIFIED assumption, see doc Section 12
    funding_interval_seconds=8 * 3600,
)

SPREAD_BPS = 2.0  # synthesized book spread used by Mock/ReplayExchangeAdapter

# -- prompt addendum for ClaudeDecisionEngine -------------------------------

PROMPT_ADDENDUM = """\
STRATEGY CONTEXT (BTC perpetual, 4-hour decision cycle):

You are evaluating whether to take a LONG, SHORT, or NO_TRADE position
based only on the market_snapshot and features provided below. This
decision will not be revisited until the next 4-hour candle closes,
except for a stop-loss/take-profit that may fill mechanically in the
meantime, or a 48-hour maximum holding period that force-closes the
position regardless of your reasoning.

Trade only when there is a coherent case combining at least two of:
trend structure (price vs. SMA fast/slow, fast/slow relationship), RSI
positioning (recovering from oversold for LONG, falling from overbought
for SHORT -- not already at the opposite extreme), and momentum
direction. Realized volatility should be high enough that a stop/target
can be sized sensibly, not so high that noise likely dominates.

NO_TRADE is the default. If the setup is ambiguous, mixed, or you would
only take it to produce an answer rather than because you see a real
edge, return NO_TRADE. A strategy that trades on every cycle is not
being evaluated for skill, only for activity -- do not do that.

Required for LONG/SHORT:
- entry.type must be "MARKET" (no limit entries in this strategy version)
- stop_loss and take_profit must both be set, on the correct side of
  the current price
- the reward:risk ratio (take_profit distance / stop_loss distance)
  must be at least 1.2
- the stop distance should be a reasonable multiple of ATR (roughly
  0.5x-4x) -- tighter gets noise-stopped, wider makes position sizing
  produce an unreasonably small size for the configured risk budget
"""
