"""
Regime classification -- FROZEN before the Claude Baseline experiment is
run against real data.

These definitions must not be adjusted after seeing Claude Baseline
results. If they turn out to look wrong or unhelpful in hindsight, that
is a reason to note it and design a *new, separately-named* regime
scheme for the *next* experiment -- not to edit these thresholds
retroactively, which would let the regime definition quietly become a
story fitted to the outcome rather than an independent yardstick.

Both functions are pure and look-ahead-safe by construction: each only
ever consumes `candles[: index + 1]`, i.e. the current candle and
everything strictly before it. See
tests/test_no_lookahead_guarantees.py for the enforcement tests.

Definitions (as specified, verbatim):
  - Bull/trending: price above the 30-day SMA, and the SMA itself
    sloping upward.
  - Bear/trending: price below the 30-day SMA, and the SMA itself
    sloping downward.
  - Chop/transition: everything else (price/SMA disagree on direction,
    or the SMA slope is flat/ambiguous).

30 days, expressed in bars, depends on the candle timeframe -- computed
from `timeframe_seconds` so this module works whether the backtest ends
up using 4h, 1h, or daily candles, without hardcoding a bar count.
"""

from __future__ import annotations

import datetime
from typing import List, Optional

from trading_system.core.models import Candle

SMA_WINDOW_DAYS = 30
SLOPE_LOOKBACK_DAYS = 1  # compare current SMA to SMA this many days ago


def _bars_per_day(timeframe_seconds: int) -> int:
    return max(1, int(round(86_400 / timeframe_seconds)))


def _sma(closes: List[float], period: int) -> Optional[float]:
    if len(closes) < period:
        return None
    return sum(closes[-period:]) / period


def classify_regime(candles: List[Candle], index: int) -> str:
    """Classify the regime AT `index`, using only `candles[: index + 1]`.
    Returns one of "bull", "bear", "chop".

    Returns "chop" (not an error) when there isn't yet enough history
    to compute a 30-day SMA and its slope -- an under-determined regime
    is treated as the "everything else" bucket by design, not as a
    missing-data condition callers need to special-case.
    """
    if index < 0 or index >= len(candles):
        raise IndexError(f"index {index} out of range for {len(candles)} candles")

    window = candles[: index + 1]
    timeframe = window[-1].timeframe_seconds
    sma_period = SMA_WINDOW_DAYS * _bars_per_day(timeframe)
    slope_lookback = SLOPE_LOOKBACK_DAYS * _bars_per_day(timeframe)

    closes = [c.close for c in window]
    current_price = closes[-1]

    sma_now = _sma(closes, sma_period)
    if sma_now is None:
        return "chop"

    if len(closes) < sma_period + slope_lookback:
        return "chop"

    sma_before = _sma(closes[: -slope_lookback], sma_period)
    if sma_before is None:
        return "chop"

    slope_up = sma_now > sma_before
    slope_down = sma_now < sma_before

    if current_price > sma_now and slope_up:
        return "bull"
    if current_price < sma_now and slope_down:
        return "bear"
    return "chop"


def calendar_quarter(timestamp: float) -> str:
    """e.g. 1704067200 (2024-01-01 UTC) -> '2024-Q1'. Pure function of
    the timestamp alone -- no lookahead concern applies here since a
    timestamp's own calendar quarter is always knowable at that
    timestamp."""
    dt = datetime.datetime.fromtimestamp(timestamp, tz=datetime.timezone.utc)
    quarter = (dt.month - 1) // 3 + 1
    return f"{dt.year}-Q{quarter}"
