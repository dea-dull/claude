"""
RuleBasedReferenceDecisionEngine: a literal, deterministic code
implementation of the LONG/SHORT/NO_TRADE rules described in
docs/strategy_v1.md Section 4.

THIS IS NOT CLAUDE. It exists for one reason: this sandboxed environment
cannot make outbound network calls, so the real `ClaudeDecisionEngine`
cannot be exercised here (see docs/strategy_v1.md Section 14 for the
full explanation and how to actually run the Claude-in-the-loop version
once you have network + an API key).

What running a backtest against this engine DOES tell you: whether the
mechanical system around the strategy -- cost model, holding-period
enforcement, R:R/ATR validation, risk-based sizing, execution -- has
positive expectancy when the entry/exit rules are applied exactly as
specified, with no judgment, no hesitation, and no missed edge cases.

What it does NOT tell you: whether genuine Claude reasoning (reading the
same data with actual judgment about ambiguous cases, conflicting
signals, or context this rule set doesn't capture) does better, worse,
or the same. That question requires the real engine.

The specific numeric thresholds below (RSI bands, volatility bounds,
condition-count logic) are one reasonable literal reading of the prose
spec, not a claim of optimality -- if you want to compare a different
literal reading, that's a legitimate reason to write a second reference
engine and backtest both.
"""

from __future__ import annotations

from trading_system.core.models import MarketSnapshot
from trading_system.decision.claude_interface import DecisionEngine
from trading_system.decision.schema import TradeDecision, parse_decision
from trading_system.features.engine import FeatureSet

# Reference thresholds -- see module docstring re: these being one
# literal reading of docs/strategy_v1.md Section 4, not a tuned optimum.
RSI_LONG_BAND = (30.0, 55.0)     # "recovering from oversold, not yet overbought"
RSI_SHORT_BAND = (45.0, 70.0)    # "falling from overbought, not yet oversold"
MIN_REALIZED_VOL = 0.003         # per-4h-bar stdev of returns, ~0.3%
MAX_REALIZED_VOL = 0.06          # ~6% per-4h-bar -- above this, noise likely dominates
MIN_CONDITIONS_REQUIRED = 2      # out of 4: trend, RSI band, momentum, vol-in-range
MOMENTUM_THRESHOLD = 0.005        # minimum |momentum| (~0.5%) to count as a real signal
STOP_ATR_MULTIPLE = 2.0          # within the validator's allowed [0.5, 4.0]x range
TAKE_PROFIT_R_MULTIPLE = 1.5     # comfortably above the 1.2 minimum R:R
TIME_HORIZON = "4h"


class RuleBasedReferenceDecisionEngine(DecisionEngine):
    def decide(self, snapshot: MarketSnapshot, features: FeatureSet) -> TradeDecision:
        raw = self._decide_raw(features)
        return parse_decision(
            raw,
            snapshot_timestamp=snapshot.timestamp,
            model_name="rule-based-reference-v1",
            raw_response=str(raw),
        )

    def _decide_raw(self, f: FeatureSet) -> dict:
        if f.candles_available < 48 or f.atr is None or f.sma_slow is None:
            return self._no_trade("insufficient history for a reliable read")

        trend_long = f.sma_fast is not None and f.sma_slow is not None and f.last_price > f.sma_fast > f.sma_slow
        trend_short = f.sma_fast is not None and f.sma_slow is not None and f.last_price < f.sma_fast < f.sma_slow

        rsi_long_ok = f.rsi is not None and RSI_LONG_BAND[0] <= f.rsi <= RSI_LONG_BAND[1]
        rsi_short_ok = f.rsi is not None and RSI_SHORT_BAND[0] <= f.rsi <= RSI_SHORT_BAND[1]

        momentum_long = f.momentum is not None and f.momentum > MOMENTUM_THRESHOLD
        momentum_short = f.momentum is not None and f.momentum < -MOMENTUM_THRESHOLD

        vol_ok = f.realized_vol is not None and MIN_REALIZED_VOL <= f.realized_vol <= MAX_REALIZED_VOL

        long_count = sum([trend_long, rsi_long_ok, momentum_long, vol_ok])
        short_count = sum([trend_short, rsi_short_ok, momentum_short, vol_ok])

        if long_count >= MIN_CONDITIONS_REQUIRED and long_count >= short_count:
            return self._trade("LONG", f, long_count,
                                trend=trend_long, rsi_ok=rsi_long_ok, momentum=momentum_long, vol_ok=vol_ok)
        if short_count >= MIN_CONDITIONS_REQUIRED:
            return self._trade("SHORT", f, short_count,
                                trend=trend_short, rsi_ok=rsi_short_ok, momentum=momentum_short, vol_ok=vol_ok)

        return self._no_trade(
            f"no coherent setup: long_conditions={long_count}, short_conditions={short_count}, "
            f"rsi={f.rsi}, momentum={f.momentum}, realized_vol={f.realized_vol}"
        )

    def _trade(self, action: str, f: FeatureSet, condition_count: int, **fired) -> dict:
        stop_distance = STOP_ATR_MULTIPLE * f.atr
        confidence = min(0.9, 0.6 + 0.1 * (condition_count - MIN_CONDITIONS_REQUIRED))
        reasons = ", ".join(name for name, ok in fired.items() if ok)

        if action == "LONG":
            stop_loss = f.last_price - stop_distance
            take_profit = f.last_price + TAKE_PROFIT_R_MULTIPLE * stop_distance
        else:
            stop_loss = f.last_price + stop_distance
            take_profit = f.last_price - TAKE_PROFIT_R_MULTIPLE * stop_distance

        return {
            "action": action,
            "confidence": round(confidence, 2),
            "entry": {"type": "MARKET"},
            "stop_loss": round(stop_loss, 2),
            "take_profit": round(take_profit, 2),
            "time_horizon": TIME_HORIZON,
            "reason": (
                f"{action} setup: {condition_count}/4 conditions met ({reasons}); "
                f"rsi={f.rsi:.1f} momentum={f.momentum:.4f} realized_vol={f.realized_vol:.4f}"
            ),
        }

    @staticmethod
    def _no_trade(reason: str) -> dict:
        return {
            "action": "NO_TRADE",
            "confidence": 0.1,
            "entry": None,
            "stop_loss": None,
            "take_profit": None,
            "time_horizon": TIME_HORIZON,
            "reason": reason,
        }
