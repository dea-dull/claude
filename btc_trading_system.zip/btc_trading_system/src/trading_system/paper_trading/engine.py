"""
PaperTradingEngine: runs the complete pipeline (market data -> features
-> Claude -> validation -> risk -> execution) against a simulated
"live" feed, recording every decision and hypothetical outcome.

This is Phase 4 from the project plan: a validation stage, not the
final purpose of the system. It reuses `TradingPipeline` exactly as
written -- the only thing that makes this "paper" rather than "live" is
that `pipeline.exchange` is a `SimulatedExchangeAdapter`
(MockExchangeAdapter here) rather than a real, money-moving
`LiveExchangeAdapter`. No separate "pretend to place an order" code
path exists; the simulated exchange itself is what makes it safe.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from trading_system.exchange.mock_exchange import MockExchangeAdapter
from trading_system.pipeline import PipelineStepResult, TradingPipeline
from trading_system.strategy.holding_period import HoldingPeriodPolicy


@dataclass
class PaperTradingSummary:
    ticks_run: int
    decisions_made: int
    trades_executed: int
    trades_rejected_by_validation: int
    trades_rejected_by_risk: int
    total_realized_pnl: float
    step_results: List[PipelineStepResult] = field(default_factory=list)


class PaperTradingEngine:
    def __init__(
        self,
        pipeline: TradingPipeline,
        symbol: str = "BTCUSDT",
        holding_period_policy: Optional[HoldingPeriodPolicy] = None,
    ):
        if not isinstance(pipeline.exchange, MockExchangeAdapter):
            raise TypeError(
                "PaperTradingEngine currently expects a MockExchangeAdapter "
                "(a live-like random-walk feed). Use BacktestEngine for "
                "replaying fixed historical data instead."
            )
        self.pipeline = pipeline
        self.exchange: MockExchangeAdapter = pipeline.exchange  # type: ignore[assignment]
        self.symbol = symbol
        self.holding_period_policy = holding_period_policy
        self._last_cum_realized_pnl = 0.0

    def run(self, num_ticks: int, keep_results: bool = True) -> PaperTradingSummary:
        results: List[PipelineStepResult] = []
        decisions_made = 0
        trades_executed = 0
        rejected_validation = 0
        rejected_risk = 0

        for _ in range(num_ticks):
            self.exchange.tick()

            if self.holding_period_policy is not None:
                current_snapshot = self.exchange.get_market_snapshot(self.symbol)
                self.holding_period_policy.enforce(
                    self.exchange,
                    self.pipeline.execution_engine,
                    self.pipeline.event_store,
                    self.symbol,
                    now=current_snapshot.timestamp,
                )

            result = self.pipeline.process_tick(self.symbol)
            decisions_made += 1

            if not result.validation.is_valid:
                rejected_validation += 1
            elif result.risk_evaluation is not None and not result.risk_evaluation.approved:
                rejected_risk += 1
            elif result.execution_result is not None:
                trades_executed += 1

            self._sync_realized_pnl()

            if keep_results:
                results.append(result)

        return PaperTradingSummary(
            ticks_run=num_ticks,
            decisions_made=decisions_made,
            trades_executed=trades_executed,
            trades_rejected_by_validation=rejected_validation,
            trades_rejected_by_risk=rejected_risk,
            total_realized_pnl=self._last_cum_realized_pnl,
            step_results=results,
        )

    def _sync_realized_pnl(self) -> None:
        current = self.exchange.get_cumulative_realized_pnl(self.symbol)
        delta = current - self._last_cum_realized_pnl
        if delta != 0:
            self.pipeline.risk_engine.record_realized_pnl(delta)
            self.pipeline.event_store.log_pnl_event(delta, context={"symbol": self.symbol})
        self._last_cum_realized_pnl = current
