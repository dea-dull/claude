"""
PositionOrderManager: the system's local, authoritative-until-proven-wrong
view of open positions and orders, plus reconciliation against whatever
the exchange itself reports.

Why this exists even though the exchange also tracks positions/orders:
in a real system, local state and exchange state WILL drift (missed
websocket message, an order filled while a REST call was in flight,
etc). Detecting that drift is what `reconcile()` is for. This module
never silently trusts one side over the other -- a mismatch is surfaced
as a `Discrepancy`, not auto-corrected, because auto-correcting a
position mismatch is exactly the kind of thing that should require a
human or a very deliberate policy decision.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from trading_system.core.models import Order, Position
from trading_system.exchange.base import ExchangeAdapter


@dataclass(frozen=True)
class Discrepancy:
    kind: str            # "missing_local_position" | "missing_exchange_position" |
                          # "size_mismatch" | "missing_local_order" | "missing_exchange_order"
    detail: str


class PositionOrderManager:
    def __init__(self) -> None:
        self._positions: Dict[str, Position] = {}   # keyed by symbol
        self._orders: Dict[str, Order] = {}          # keyed by order_id

    # -- local state mutation ------------------------------------------

    def record_position(self, position: Position) -> None:
        self._positions[position.symbol] = position

    def remove_position(self, symbol: str) -> None:
        self._positions.pop(symbol, None)

    def record_order(self, order: Order) -> None:
        self._orders[order.order_id] = order

    # -- local state queries --------------------------------------------

    def get_open_positions(self) -> List[Position]:
        return [p for p in self._positions.values() if p.size > 0]

    def get_position(self, symbol: str):
        return self._positions.get(symbol)

    def get_tracked_orders(self) -> List[Order]:
        return list(self._orders.values())

    # -- reconciliation ---------------------------------------------------

    def reconcile(self, exchange: ExchangeAdapter) -> List[Discrepancy]:
        """Compare local state against the exchange's own view. Returns a
        list of discrepancies found; does NOT mutate local state --
        callers decide the policy for resolving discrepancies (typically:
        halt trading and alert, or trust the exchange and refresh local
        state, but never silently trust local state over the exchange)."""
        discrepancies: List[Discrepancy] = []

        exchange_positions = {p.symbol: p for p in exchange.get_positions() if p.size > 0}
        local_positions = {s: p for s, p in self._positions.items() if p.size > 0}

        for symbol, ex_pos in exchange_positions.items():
            local_pos = local_positions.get(symbol)
            if local_pos is None:
                discrepancies.append(
                    Discrepancy(
                        "missing_local_position",
                        f"exchange reports open {symbol} position (size={ex_pos.size}) "
                        "that local state does not have",
                    )
                )
            elif abs(local_pos.size - ex_pos.size) > 1e-9:
                discrepancies.append(
                    Discrepancy(
                        "size_mismatch",
                        f"{symbol}: local size={local_pos.size} vs exchange size={ex_pos.size}",
                    )
                )

        for symbol, local_pos in local_positions.items():
            if symbol not in exchange_positions:
                discrepancies.append(
                    Discrepancy(
                        "missing_exchange_position",
                        f"local state has open {symbol} position (size={local_pos.size}) "
                        "that the exchange does not report",
                    )
                )

        exchange_orders = {o.order_id: o for o in exchange.get_open_orders()}
        local_open_orders = {
            oid: o for oid, o in self._orders.items() if o.status.value in ("OPEN", "PENDING", "PARTIALLY_FILLED")
        }

        for order_id in exchange_orders:
            if order_id not in local_open_orders:
                discrepancies.append(
                    Discrepancy(
                        "missing_local_order",
                        f"exchange reports open order {order_id} that local state does not track",
                    )
                )
        for order_id in local_open_orders:
            if order_id not in exchange_orders:
                discrepancies.append(
                    Discrepancy(
                        "missing_exchange_order",
                        f"local state tracks open order {order_id} that the exchange does not report",
                    )
                )

        return discrepancies

    def refresh_from_exchange(self, exchange: ExchangeAdapter) -> None:
        """Explicit, deliberate action to make local state match the
        exchange's reported state. Callers should generally do this only
        after reviewing reconcile() output, not automatically on every
        tick, so silent drift doesn't get papered over unnoticed."""
        self._positions = {p.symbol: p for p in exchange.get_positions()}
        self._orders = {o.order_id: o for o in exchange.get_open_orders()}
