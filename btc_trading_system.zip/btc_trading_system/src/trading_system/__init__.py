"""
BTC Trading System
===================

A modular, progressively-built trading system where Claude acts as the
analysis/decision-making component and deterministic Python code handles
validation, risk management, execution, and persistence.

This package is intentionally exchange-agnostic. No module outside
`trading_system.exchange` may know anything about a specific exchange's
API. Until a verified Margex adapter exists, only `MockExchangeAdapter`
and `ReplayExchangeAdapter` are available, which means the system is
structurally incapable of live trading.
"""

__version__ = "0.1.0-scaffold"
