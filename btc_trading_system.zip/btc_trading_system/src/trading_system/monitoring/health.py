"""
HealthMonitor: real-time-clock-based health tracking for the running
system. Deliberately separate from anything in the decision/validation
path (see the note in decision/validator.py) so it only ever runs
against the real clock in paper/live mode, and backtests aren't
affected by wall-clock concerns at all.

Responsibilities:
  - Stale-data protection: is the most recent market snapshot too old
    to safely act on?
  - API failure tracking: consecutive exchange-call failures trip a
    breaker rather than retrying forever.
  - A single place components register callbacks against for
    "emergency shutdown just happened" so risk_engine, execution_engine,
    and any alerting hook all learn about it consistently.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from trading_system.core.models import now_ts


@dataclass
class HealthStatus:
    healthy: bool
    reasons: List[str] = field(default_factory=list)


class HealthMonitor:
    def __init__(
        self,
        max_data_staleness_seconds: float = 10.0,
        max_consecutive_api_failures: int = 3,
        clock=now_ts,
    ):
        self.max_data_staleness_seconds = max_data_staleness_seconds
        self.max_consecutive_api_failures = max_consecutive_api_failures
        self._clock = clock

        self._last_snapshot_ts: Optional[float] = None
        self._last_heartbeat: Dict[str, float] = {}
        self._consecutive_api_failures = 0
        self._shutdown_callbacks: List[Callable[[str], None]] = []
        self._shutdown_triggered = False
        self._shutdown_reason: Optional[str] = None

    # -- registration -------------------------------------------------------

    def on_emergency_shutdown(self, callback: Callable[[str], None]) -> None:
        self._shutdown_callbacks.append(callback)

    # -- data freshness -----------------------------------------------------

    def record_snapshot_received(self, snapshot_timestamp: float) -> None:
        self._last_snapshot_ts = snapshot_timestamp

    def is_data_stale(self) -> bool:
        if self._last_snapshot_ts is None:
            return True
        return (self._clock() - self._last_snapshot_ts) > self.max_data_staleness_seconds

    def staleness_seconds(self) -> Optional[float]:
        if self._last_snapshot_ts is None:
            return None
        return self._clock() - self._last_snapshot_ts

    # -- API failure tracking -------------------------------------------------

    def record_api_success(self) -> None:
        self._consecutive_api_failures = 0

    def record_api_failure(self) -> None:
        self._consecutive_api_failures += 1
        if self._consecutive_api_failures >= self.max_consecutive_api_failures:
            self.trigger_emergency_shutdown(
                f"{self._consecutive_api_failures} consecutive exchange API failures"
            )

    @property
    def consecutive_api_failures(self) -> int:
        return self._consecutive_api_failures

    # -- heartbeats for long-running components ------------------------------

    def heartbeat(self, component: str) -> None:
        self._last_heartbeat[component] = self._clock()

    def seconds_since_heartbeat(self, component: str) -> Optional[float]:
        ts = self._last_heartbeat.get(component)
        if ts is None:
            return None
        return self._clock() - ts

    # -- emergency shutdown ---------------------------------------------------

    def trigger_emergency_shutdown(self, reason: str) -> None:
        self._shutdown_triggered = True
        self._shutdown_reason = reason
        for cb in self._shutdown_callbacks:
            cb(reason)

    def reset_emergency_shutdown(self) -> None:
        self._shutdown_triggered = False
        self._shutdown_reason = None
        self._consecutive_api_failures = 0

    @property
    def is_shutdown(self) -> bool:
        return self._shutdown_triggered

    @property
    def shutdown_reason(self) -> Optional[str]:
        return self._shutdown_reason

    # -- overall status -------------------------------------------------------

    def status(self) -> HealthStatus:
        reasons: List[str] = []
        if self._shutdown_triggered:
            reasons.append(f"emergency shutdown active: {self._shutdown_reason}")
        if self.is_data_stale():
            age = self.staleness_seconds()
            reasons.append(
                f"market data stale (age={age if age is not None else 'unknown'}s, "
                f"max allowed={self.max_data_staleness_seconds}s)"
            )
        if self._consecutive_api_failures > 0:
            reasons.append(f"{self._consecutive_api_failures} consecutive API failures recorded")
        return HealthStatus(healthy=len(reasons) == 0, reasons=reasons)
