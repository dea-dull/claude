"""Enumerations shared across every layer of the system.

These are intentionally exchange-agnostic. When the Margex adapter is
built, it will translate Margex's own vocabulary (whatever it turns out
to be) into these internal enums at the boundary, so nothing upstream
ever has to know Margex-specific terms.
"""

from enum import Enum


class OrderSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class PositionSide(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"
    FLAT = "FLAT"


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP_MARKET = "STOP_MARKET"
    STOP_LIMIT = "STOP_LIMIT"


class TimeInForce(str, Enum):
    GTC = "GTC"  # good till cancelled
    IOC = "IOC"  # immediate or cancel
    FOK = "FOK"  # fill or kill


class OrderStatus(str, Enum):
    PENDING = "PENDING"          # accepted locally, not yet confirmed by exchange
    OPEN = "OPEN"                # confirmed open on exchange, unfilled or partially filled
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


class TradeAction(str, Enum):
    """The set of actions Claude's decision output is allowed to return."""
    LONG = "LONG"
    SHORT = "SHORT"
    NO_TRADE = "NO_TRADE"


class SystemMode(str, Enum):
    """
    The operating mode of the whole system. This is a hard gate, not a
    suggestion: `TradingSystem` bootstrap logic refuses to run in LIVE
    mode unless a real, explicitly-marked live exchange adapter is
    wired in. Today no such adapter exists, so LIVE mode cannot start.
    """
    BACKTEST = "BACKTEST"
    PAPER = "PAPER"
    LIVE = "LIVE"
