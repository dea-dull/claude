"""
Normalized, exchange-agnostic data models.

Every piece of market or account data that flows through this system is
represented using these dataclasses. Exchange adapters are the ONLY
place responsible for translating a real exchange's native response
shape into these models. Nothing downstream (features, decision engine,
risk engine, execution, persistence) should ever see raw exchange
payloads.

All timestamps are UTC, stored as float epoch seconds unless noted.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any

from trading_system.core.enums import (
    OrderSide,
    OrderType,
    OrderStatus,
    PositionSide,
    TimeInForce,
)


def now_ts() -> float:
    """Single source of truth for 'current time' so it can be monkeypatched
    in tests and so backtests can override it with simulated time."""
    return time.time()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


# ---------------------------------------------------------------------------
# Market data
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Candle:
    timestamp: float          # open time, epoch seconds (UTC)
    open: float
    high: float
    low: float
    close: float
    volume: float
    timeframe_seconds: int = 60

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class OrderBookLevel:
    price: float
    size: float


@dataclass(frozen=True)
class OrderBook:
    timestamp: float
    bids: List[OrderBookLevel] = field(default_factory=list)  # best first
    asks: List[OrderBookLevel] = field(default_factory=list)  # best first

    @property
    def best_bid(self) -> Optional[float]:
        return self.bids[0].price if self.bids else None

    @property
    def best_ask(self) -> Optional[float]:
        return self.asks[0].price if self.asks else None

    @property
    def mid_price(self) -> Optional[float]:
        if self.best_bid is None or self.best_ask is None:
            return None
        return (self.best_bid + self.best_ask) / 2.0

    @property
    def spread(self) -> Optional[float]:
        if self.best_bid is None or self.best_ask is None:
            return None
        return self.best_ask - self.best_bid

    def imbalance(self, depth: int = 5) -> Optional[float]:
        """(bid_vol - ask_vol) / (bid_vol + ask_vol) over top `depth` levels.
        Positive => more resting buy interest near the top of book."""
        bid_vol = sum(l.size for l in self.bids[:depth])
        ask_vol = sum(l.size for l in self.asks[:depth])
        total = bid_vol + ask_vol
        if total == 0:
            return None
        return (bid_vol - ask_vol) / total


@dataclass(frozen=True)
class PublicTrade:
    timestamp: float
    price: float
    size: float
    side: Optional[OrderSide] = None  # aggressor side, if known


@dataclass(frozen=True)
class FundingInfo:
    timestamp: float
    rate: float                       # e.g. 0.0001 = 0.01%
    next_funding_time: Optional[float] = None
    interval_seconds: Optional[int] = None


@dataclass(frozen=True)
class OpenInterest:
    timestamp: float
    value: float                      # in contract or base-asset units
    value_usd: Optional[float] = None


@dataclass(frozen=True)
class MarketSnapshot:
    """
    A complete, self-contained view of the market for one symbol at one
    instant. This is exactly what gets frozen and handed to the feature
    engine and, eventually, to Claude -- containing only information
    that was actually available at `timestamp`. Nothing here may be
    filled in retroactively (no lookahead).
    """
    symbol: str
    timestamp: float
    last_price: float
    order_book: Optional[OrderBook] = None
    recent_trades: List[PublicTrade] = field(default_factory=list)
    recent_candles: List[Candle] = field(default_factory=list)  # most-recent last
    funding: Optional[FundingInfo] = None
    open_interest: Optional[OpenInterest] = None
    # Anything exchange-specific that doesn't map cleanly onto the fields
    # above can be stashed here for debugging -- but feature/decision
    # code must not depend on this being populated.
    raw_extra: Dict[str, Any] = field(default_factory=dict)

    @property
    def best_bid(self) -> Optional[float]:
        return self.order_book.best_bid if self.order_book else None

    @property
    def best_ask(self) -> Optional[float]:
        return self.order_book.best_ask if self.order_book else None


# ---------------------------------------------------------------------------
# Account / positions
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AccountBalance:
    currency: str
    total: float
    available: float
    used: float
    timestamp: float = field(default_factory=now_ts)


@dataclass(frozen=True)
class Position:
    symbol: str
    side: PositionSide
    size: float                       # always >= 0; side carries direction
    entry_price: float
    mark_price: float
    leverage: float
    liquidation_price: Optional[float] = None
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    opened_at: float = field(default_factory=now_ts)
    updated_at: float = field(default_factory=now_ts)
    position_id: str = field(default_factory=lambda: new_id("pos"))


# ---------------------------------------------------------------------------
# Orders / fills
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class OrderRequest:
    """What the execution layer asks the exchange adapter to do.
    This is produced by the risk engine, never directly by Claude."""
    symbol: str
    side: OrderSide
    order_type: OrderType
    size: float
    price: Optional[float] = None            # required for LIMIT/STOP_LIMIT
    stop_price: Optional[float] = None        # required for STOP_* orders
    time_in_force: TimeInForce = TimeInForce.GTC
    reduce_only: bool = False
    leverage: float = 1.0
    client_order_id: str = field(default_factory=lambda: new_id("cli"))
    # Optional bracket legs attached at submission time, if the exchange
    # supports it. If not supported, execution engine must place these
    # as separate reduce-only orders instead -- that logic lives in the
    # adapter/execution layer, not here.
    stop_loss_price: Optional[float] = None
    take_profit_price: Optional[float] = None


@dataclass(frozen=True)
class Order:
    """The exchange's (normalized) view of an order."""
    order_id: str
    client_order_id: str
    symbol: str
    side: OrderSide
    order_type: OrderType
    status: OrderStatus
    size: float
    filled_size: float = 0.0
    avg_fill_price: Optional[float] = None
    price: Optional[float] = None
    stop_price: Optional[float] = None
    created_at: float = field(default_factory=now_ts)
    updated_at: float = field(default_factory=now_ts)
    reduce_only: bool = False


@dataclass(frozen=True)
class Fill:
    fill_id: str
    order_id: str
    symbol: str
    side: OrderSide
    price: float
    size: float
    fee: float = 0.0
    fee_currency: Optional[str] = None
    timestamp: float = field(default_factory=now_ts)
