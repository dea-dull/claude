"""Exception hierarchy for the trading system.

Keeping these distinct (rather than raising generic Exception/ValueError
everywhere) matters once this is a live system: the monitoring layer and
execution engine need to be able to tell "the exchange is unreachable"
apart from "risk engine rejected this" apart from "Claude returned
garbage" and react differently to each.
"""


class TradingSystemError(Exception):
    """Base class for all trading-system-specific errors."""


# --- Exchange layer -----------------------------------------------------

class ExchangeError(TradingSystemError):
    """Base class for exchange adapter errors."""


class ExchangeConnectionError(ExchangeError):
    """The adapter could not reach the exchange (network, timeout, DNS)."""


class ExchangeAuthError(ExchangeError):
    """Authentication/permission failure talking to the exchange."""


class OrderRejectedError(ExchangeError):
    """The exchange explicitly rejected an order (as opposed to a
    connectivity failure)."""


class StaleDataError(ExchangeError):
    """Market data is older than the maximum allowed staleness."""


# --- Decision layer ------------------------------------------------------

class DecisionEngineError(TradingSystemError):
    """The decision engine (Claude or otherwise) failed to produce output,
    or produced output that could not even be parsed."""


class DecisionValidationError(TradingSystemError):
    """A structurally invalid or unsafe decision was rejected by the
    validator. This is an expected, routine occurrence -- NOT_TRADE-able,
    not a bug -- so callers should catch and log it rather than crash."""

    def __init__(self, errors):
        self.errors = list(errors)
        super().__init__("; ".join(self.errors))


# --- Risk layer ------------------------------------------------------------

class RiskRejectedError(TradingSystemError):
    """Risk engine declined to approve a decision for execution. Also a
    routine, expected outcome."""

    def __init__(self, reasons):
        self.reasons = list(reasons)
        super().__init__("; ".join(self.reasons))


class RiskLimitBreachError(TradingSystemError):
    """A hard risk limit (daily loss, max positions, etc.) has been
    breached at the account level -- this should trip a circuit breaker,
    not just reject one order."""


# --- Execution / state layer ------------------------------------------------

class DuplicateOrderError(TradingSystemError):
    """An order with this client_order_id / decision id has already been
    submitted -- refusing to submit again."""


class ReconciliationError(TradingSystemError):
    """Local position/order state disagrees with the exchange's reported
    state in a way that couldn't be automatically resolved."""


class EmergencyShutdownError(TradingSystemError):
    """Raised to signal (and enforce) that the system has tripped an
    emergency shutdown and must not place further orders."""
