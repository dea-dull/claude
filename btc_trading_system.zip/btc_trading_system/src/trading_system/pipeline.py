"""
TradingPipeline: wires every module together into the single flow
described in the project brief:

    market data -> features -> Claude -> decision validation
                -> risk engine -> approved order -> exchange adapter

`TradingPipeline.process_tick()` is the one place that flow is
implemented, and it is used identically by paper trading and
backtesting (they differ only in where the MarketSnapshot comes from
and which ExchangeAdapter is behind it).

`TradingSystem` is the top-level bootstrap object. It is the ONLY place
SystemMode.LIVE is checked, and it enforces the hard gate: live mode is
structurally impossible unless a real `LiveExchangeAdapter` is supplied
AND live trading is explicitly enabled. Today, no `LiveExchangeAdapter`
subclass exists in this codebase, so this check cannot currently be
satisfied by any real component -- which is the intended state until a
verified Margex adapter is written.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from trading_system.core.enums import SystemMode
from trading_system.core.exceptions import DecisionEngineError, DuplicateOrderError
from trading_system.core.models import MarketSnapshot
from trading_system.decision.claude_interface import DecisionEngine
from trading_system.decision.schema import TradeDecision
from trading_system.decision.validator import DecisionValidator, ValidationResult
from trading_system.exchange.base import ExchangeAdapter, LiveExchangeAdapter
from trading_system.execution.engine import ExecutionEngine, ExecutionResult
from trading_system.features.engine import FeatureEngine, FeatureSet
from trading_system.monitoring.health import HealthMonitor
from trading_system.persistence.db import EventStore
from trading_system.risk.engine import RiskEngine, RiskEvaluation
from trading_system.state.position_manager import PositionOrderManager


@dataclass
class PipelineStepResult:
    snapshot: MarketSnapshot
    features: FeatureSet
    decision: TradeDecision
    validation: ValidationResult
    risk_evaluation: Optional[RiskEvaluation] = None
    execution_result: Optional[ExecutionResult] = None
    error: Optional[str] = None


class TradingPipeline:
    def __init__(
        self,
        exchange: ExchangeAdapter,
        decision_engine: DecisionEngine,
        event_store: EventStore,
        risk_engine: RiskEngine,
        feature_engine: Optional[FeatureEngine] = None,
        validator: Optional[DecisionValidator] = None,
        execution_engine: Optional[ExecutionEngine] = None,
        position_manager: Optional[PositionOrderManager] = None,
        health_monitor: Optional[HealthMonitor] = None,
    ):
        self.exchange = exchange
        self.decision_engine = decision_engine
        self.event_store = event_store
        self.risk_engine = risk_engine
        self.feature_engine = feature_engine or FeatureEngine()
        self.validator = validator or DecisionValidator()
        self.execution_engine = execution_engine or ExecutionEngine(exchange)
        self.position_manager = position_manager or PositionOrderManager()
        self.health_monitor = health_monitor

    def process_tick(self, symbol: str) -> PipelineStepResult:
        # 1. Market data ----------------------------------------------------
        try:
            snapshot = self.exchange.get_market_snapshot(symbol)
            if self.health_monitor:
                self.health_monitor.record_api_success()
                self.health_monitor.record_snapshot_received(snapshot.timestamp)
        except Exception as exc:
            if self.health_monitor:
                self.health_monitor.record_api_failure()
            raise

        self.event_store.log_snapshot(snapshot)
        correlation = f"snapshot_{snapshot.timestamp}"

        if self.health_monitor and self.health_monitor.is_data_stale():
            self.event_store.log_health(
                {"reason": "stale_data_before_decision", "symbol": symbol, "ts": snapshot.timestamp}
            )

        # 2. Features ---------------------------------------------------------
        features = self.feature_engine.compute(snapshot)
        self.event_store.log_features(features, correlation_id=correlation)

        # 3. Claude decision ---------------------------------------------------
        try:
            decision = self.decision_engine.decide(snapshot, features)
        except DecisionEngineError as exc:
            self.event_store.log_event(
                "DECISION_ENGINE_ERROR", {"error": str(exc)}, correlation_id=correlation
            )
            raise
        self.event_store.log_decision(decision)

        # 4. Decision validation -------------------------------------------
        validation = self.validator.validate(decision, snapshot, features=features)
        self.event_store.log_validation(validation, decision.decision_id)
        if not validation.is_valid:
            return PipelineStepResult(
                snapshot=snapshot,
                features=features,
                decision=decision,
                validation=validation,
                error="decision failed validation",
            )

        # 5 & 6. Risk engine -----------------------------------------------
        account = self.exchange.get_account()
        open_positions = self.exchange.get_positions()
        risk_evaluation = self.risk_engine.evaluate(decision, snapshot, account, open_positions)
        self.event_store.log_risk_evaluation(risk_evaluation, decision.decision_id)

        if not risk_evaluation.approved:
            return PipelineStepResult(
                snapshot=snapshot,
                features=features,
                decision=decision,
                validation=validation,
                risk_evaluation=risk_evaluation,
                error="rejected by risk engine",
            )

        if risk_evaluation.is_no_op:
            return PipelineStepResult(
                snapshot=snapshot,
                features=features,
                decision=decision,
                validation=validation,
                risk_evaluation=risk_evaluation,
            )

        # 7. Execution -------------------------------------------------------
        try:
            execution_result = self.execution_engine.execute(risk_evaluation.approved_order)
        except DuplicateOrderError as exc:
            self.event_store.log_event(
                "DUPLICATE_ORDER_BLOCKED", {"error": str(exc)}, correlation_id=decision.decision_id
            )
            return PipelineStepResult(
                snapshot=snapshot,
                features=features,
                decision=decision,
                validation=validation,
                risk_evaluation=risk_evaluation,
                error="duplicate order blocked",
            )

        self.event_store.log_order(execution_result.entry_order, correlation_id=decision.decision_id)
        if execution_result.stop_loss_order:
            self.event_store.log_order(execution_result.stop_loss_order, correlation_id=decision.decision_id)
        if execution_result.take_profit_order:
            self.event_store.log_order(execution_result.take_profit_order, correlation_id=decision.decision_id)

        # 8. Position/order state -------------------------------------------
        self.position_manager.record_order(execution_result.entry_order)
        if execution_result.stop_loss_order:
            self.position_manager.record_order(execution_result.stop_loss_order)
        if execution_result.take_profit_order:
            self.position_manager.record_order(execution_result.take_profit_order)
        for position in self.exchange.get_positions():
            self.position_manager.record_position(position)
            self.event_store.log_position(position, correlation_id=decision.decision_id)

        return PipelineStepResult(
            snapshot=snapshot,
            features=features,
            decision=decision,
            validation=validation,
            risk_evaluation=risk_evaluation,
            execution_result=execution_result,
        )


class TradingSystem:
    """
    Top-level bootstrap. This is the single choke point where
    SystemMode.LIVE is checked. See module docstring.
    """

    def __init__(
        self,
        mode: SystemMode,
        pipeline: TradingPipeline,
        enable_live_trading: bool = False,
    ):
        if mode == SystemMode.LIVE:
            if not isinstance(pipeline.exchange, LiveExchangeAdapter):
                raise RuntimeError(
                    "Refusing to start in SystemMode.LIVE: the configured exchange "
                    "adapter is not a verified LiveExchangeAdapter. No such adapter "
                    "exists in this codebase yet -- a Margex adapter must be built "
                    "and verified against official documentation first."
                )
            if not enable_live_trading:
                raise RuntimeError(
                    "Refusing to start in SystemMode.LIVE: enable_live_trading was "
                    "not explicitly set to True."
                )
        self.mode = mode
        self.pipeline = pipeline

    def run_once(self, symbol: str):
        return self.pipeline.process_tick(symbol)
