"""
TradeDecision: the structured output contract for the decision engine
(Claude, in production; anything else in tests).

Schema (as JSON, what the decision engine is prompted to return):

{
  "action": "LONG" | "SHORT" | "NO_TRADE",
  "confidence": 0.00-1.00,
  "entry": {"type": "MARKET" | "LIMIT", "price": <number, required if LIMIT>},
  "stop_loss": <number, required unless action == NO_TRADE>,
  "take_profit": <number, required unless action == NO_TRADE>,
  "time_horizon": "<free text, e.g. '15m', '4h', 'intraday'>",
  "reason": "<free text explanation>"
}

Position size is deliberately NOT part of this schema. Sizing is a risk
decision, not an analysis decision -- the risk engine computes size from
account equity, stop distance, and configured risk limits. Claude never
gets to say how much to trade, only what/whether/where.

Parsing here is intentionally lenient and never raises: malformed input
produces a TradeDecision with `parse_errors` populated (or None with a
top-level error) rather than an exception, so the validator/pipeline can
log the full picture of what went wrong and treat it as a routine
NO_TRADE-equivalent outcome instead of crashing the process.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from trading_system.core.models import new_id, now_ts


@dataclass(frozen=True)
class EntrySpec:
    entry_type: str                 # "MARKET" | "LIMIT" (validated downstream)
    price: Optional[float] = None


@dataclass(frozen=True)
class TradeDecision:
    decision_id: str
    action: str                     # kept as raw str; validator checks membership
    confidence: Optional[float]
    entry: Optional[EntrySpec]
    stop_loss: Optional[float]
    take_profit: Optional[float]
    time_horizon: Optional[str]
    reason: str
    snapshot_timestamp: float       # timestamp of the snapshot this was based on
    created_at: float = field(default_factory=now_ts)
    model_name: Optional[str] = None
    raw_prompt: Optional[str] = None
    raw_response: Optional[str] = None
    parse_errors: Tuple[str, ...] = field(default_factory=tuple)


def _coerce_float(value: Any) -> Tuple[Optional[float], Optional[str]]:
    if value is None:
        return None, None
    try:
        return float(value), None
    except (TypeError, ValueError):
        return None, f"could not coerce {value!r} to float"


def parse_decision(
    raw: Dict[str, Any],
    *,
    snapshot_timestamp: float,
    model_name: Optional[str] = None,
    raw_prompt: Optional[str] = None,
    raw_response: Optional[str] = None,
) -> TradeDecision:
    """Best-effort parse of a raw dict (already JSON-decoded) into a
    TradeDecision. Never raises. Structural/semantic validity is checked
    separately by DecisionValidator -- this function's only job is safe
    extraction and type coercion."""
    errors: List[str] = []

    if not isinstance(raw, dict):
        errors.append(f"top-level decision payload was not an object: {type(raw).__name__}")
        raw = {}

    action = raw.get("action")
    if not isinstance(action, str):
        errors.append("field 'action' missing or not a string")
        action = ""

    confidence, conf_err = _coerce_float(raw.get("confidence"))
    if conf_err:
        errors.append(f"field 'confidence': {conf_err}")

    entry_raw = raw.get("entry")
    entry: Optional[EntrySpec] = None
    if entry_raw is not None:
        if not isinstance(entry_raw, dict):
            errors.append("field 'entry' present but not an object")
        else:
            entry_type = entry_raw.get("type")
            if not isinstance(entry_type, str):
                errors.append("field 'entry.type' missing or not a string")
                entry_type = ""
            entry_price, entry_price_err = _coerce_float(entry_raw.get("price"))
            if entry_price_err:
                errors.append(f"field 'entry.price': {entry_price_err}")
            entry = EntrySpec(entry_type=entry_type, price=entry_price)

    stop_loss, sl_err = _coerce_float(raw.get("stop_loss"))
    if sl_err:
        errors.append(f"field 'stop_loss': {sl_err}")

    take_profit, tp_err = _coerce_float(raw.get("take_profit"))
    if tp_err:
        errors.append(f"field 'take_profit': {tp_err}")

    time_horizon = raw.get("time_horizon")
    if time_horizon is not None and not isinstance(time_horizon, str):
        errors.append("field 'time_horizon' present but not a string")
        time_horizon = None

    reason = raw.get("reason")
    if not isinstance(reason, str) or not reason.strip():
        errors.append("field 'reason' missing, empty, or not a string")
        reason = ""

    return TradeDecision(
        decision_id=new_id("dec"),
        action=action,
        confidence=confidence,
        entry=entry,
        stop_loss=stop_loss,
        take_profit=take_profit,
        time_horizon=time_horizon,
        reason=reason,
        snapshot_timestamp=snapshot_timestamp,
        model_name=model_name,
        raw_prompt=raw_prompt,
        raw_response=raw_response,
        parse_errors=tuple(errors),
    )
