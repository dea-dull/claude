"""
DecisionEngine: the abstraction that separates "how we call Claude" from
"what the rest of the system does with a decision."

`ClaudeDecisionEngine` takes an injected `llm_call_fn` callable rather
than importing an SDK or making network calls itself. That keeps this
module network-free and fully unit-testable, and means wiring in the
real Anthropic API later is a one-line change at the call site, not a
rewrite of this class.

Nothing here ever talks to an exchange. Nothing here ever decides
position size, leverage, or whether an order is actually safe to place
-- that is the validator's and risk engine's job, strictly downstream
of this module.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, Optional

from trading_system.core.models import MarketSnapshot
from trading_system.core.exceptions import DecisionEngineError
from trading_system.decision.schema import TradeDecision, parse_decision
from trading_system.features.engine import FeatureSet

DECISION_JSON_SCHEMA_DESCRIPTION = """\
Respond with ONLY a single JSON object (no prose, no markdown fences) of
exactly this shape:

{
  "action": "LONG" | "SHORT" | "NO_TRADE",
  "confidence": <number between 0.0 and 1.0>,
  "entry": {"type": "MARKET" | "LIMIT", "price": <number, only if LIMIT>},
  "stop_loss": <number, required unless action is NO_TRADE>,
  "take_profit": <number, required unless action is NO_TRADE>,
  "time_horizon": "<e.g. '15m', '1h', '4h', 'intraday'>",
  "reason": "<brief explanation grounded only in the data provided>"
}

Rules:
- Base your decision ONLY on the market_snapshot and features provided.
  Do not assume access to any information beyond what is given.
- Do not invent a position size -- it is not part of this schema and is
  handled separately.
- If the setup is unclear or you would not act on it, return NO_TRADE
  with stop_loss and take_profit omitted (null).
- stop_loss and take_profit are required for LONG/SHORT and must be on
  the correct side of the entry price.
"""


def build_snapshot_payload(
    snapshot: MarketSnapshot, features: FeatureSet
) -> Dict[str, Any]:
    """Build the exact, JSON-serializable payload that gets shown to the
    decision engine. Constructed purely from the `snapshot`/`features`
    objects passed in -- it is architecturally impossible for this to
    include anything from after `snapshot.timestamp`, because those
    objects are themselves frozen snapshots in time."""
    book = snapshot.order_book
    return {
        "symbol": snapshot.symbol,
        "timestamp": snapshot.timestamp,
        "last_price": snapshot.last_price,
        "best_bid": snapshot.best_bid,
        "best_ask": snapshot.best_ask,
        "order_book_top": {
            "bids": [[l.price, l.size] for l in (book.bids[:5] if book else [])],
            "asks": [[l.price, l.size] for l in (book.asks[:5] if book else [])],
        },
        "recent_candles": [
            {
                "t": c.timestamp,
                "o": c.open,
                "h": c.high,
                "l": c.low,
                "c": c.close,
                "v": c.volume,
            }
            for c in snapshot.recent_candles[-50:]
        ],
        "funding_rate": snapshot.funding.rate if snapshot.funding else None,
        "open_interest": snapshot.open_interest.value if snapshot.open_interest else None,
        "features": features.to_dict(),
    }


class DecisionEngine(ABC):
    @abstractmethod
    def decide(self, snapshot: MarketSnapshot, features: FeatureSet) -> TradeDecision:
        raise NotImplementedError


class ClaudeDecisionEngine(DecisionEngine):
    """
    Production decision engine. `llm_call_fn` is injected so this class
    has zero direct dependency on the Anthropic SDK or network access --
    wiring in the real API is done by passing a callable at construction
    time, e.g.:

        def call_claude(prompt: str) -> str:
            response = anthropic_client.messages.create(
                model="claude-sonnet-5",
                max_tokens=1000,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text

        engine = ClaudeDecisionEngine(llm_call_fn=call_claude)

    Until that's wired up, calling decide() raises DecisionEngineError --
    deliberately, so it's impossible to silently run with no real
    decision-making behind it.
    """

    def __init__(
        self,
        llm_call_fn: Optional[Callable[[str], str]] = None,
        model_name: str = "claude-sonnet-5",
        system_prompt_extra: str = "",
    ):
        self._llm_call_fn = llm_call_fn
        self.model_name = model_name
        self.system_prompt_extra = system_prompt_extra

    def build_prompt(self, snapshot: MarketSnapshot, features: FeatureSet) -> str:
        payload = build_snapshot_payload(snapshot, features)
        parts = [
            "You are the analysis component of an automated BTC trading system.",
            self.system_prompt_extra.strip(),
            "market_snapshot:",
            json.dumps(payload, indent=2, default=str),
            DECISION_JSON_SCHEMA_DESCRIPTION,
        ]
        return "\n\n".join(p for p in parts if p)

    def decide(self, snapshot: MarketSnapshot, features: FeatureSet) -> TradeDecision:
        if self._llm_call_fn is None:
            raise DecisionEngineError(
                "ClaudeDecisionEngine has no llm_call_fn configured -- this is a "
                "deliberate stub. Wire in a real call before using this in "
                "paper trading or live mode."
            )
        prompt = self.build_prompt(snapshot, features)
        try:
            raw_text = self._llm_call_fn(prompt)
        except Exception as exc:  # network/SDK errors surfaced uniformly
            raise DecisionEngineError(f"llm_call_fn raised: {exc}") from exc

        raw_json = self._try_parse_json(raw_text)
        if raw_json is None:
            # Don't raise -- produce a decision with parse_errors so the
            # validator rejects it through the normal path and it gets
            # logged like any other rejected decision. The full raw_text
            # is preserved either way for audit purposes.
            return parse_decision(
                {},
                snapshot_timestamp=snapshot.timestamp,
                model_name=self.model_name,
                raw_prompt=prompt,
                raw_response=raw_text,
            )

        return parse_decision(
            raw_json,
            snapshot_timestamp=snapshot.timestamp,
            model_name=self.model_name,
            raw_prompt=prompt,
            raw_response=raw_text,
        )

    @staticmethod
    def _try_parse_json(raw_text: str) -> Optional[Dict[str, Any]]:
        """Direct JSON parse, with one fallback: strip a ```json ... ```
        or bare ``` ... ``` fence if the model wrapped its answer in one
        despite being asked not to. Returns None if both attempts fail."""
        try:
            return json.loads(raw_text)
        except (json.JSONDecodeError, TypeError):
            pass
        stripped = raw_text.strip() if isinstance(raw_text, str) else raw_text
        if isinstance(stripped, str) and stripped.startswith("```"):
            lines = stripped.splitlines()
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            candidate = "\n".join(lines)
            try:
                return json.loads(candidate)
            except (json.JSONDecodeError, TypeError):
                return None
        return None


class MockDecisionEngine(DecisionEngine):
    """Deterministic-ish decision engine for tests and paper-trading
    demos that don't want to (or can't) call the real API. Behavior is
    driven by a simple, inspectable rule so tests can reason about it."""

    def __init__(self, fixed_decision: Optional[Dict[str, Any]] = None, seed: int = 7):
        import random

        self._fixed = fixed_decision
        self._rng = random.Random(seed)

    def decide(self, snapshot: MarketSnapshot, features: FeatureSet) -> TradeDecision:
        if self._fixed is not None:
            raw = dict(self._fixed)
        else:
            raw = self._simple_momentum_rule(features)
        return parse_decision(
            raw,
            snapshot_timestamp=snapshot.timestamp,
            model_name="mock-decision-engine",
            raw_response=json.dumps(raw),
        )

    def _simple_momentum_rule(self, features: FeatureSet) -> Dict[str, Any]:
        price = features.last_price
        if features.rsi is None or features.atr is None:
            return {
                "action": "NO_TRADE",
                "confidence": 0.0,
                "entry": None,
                "stop_loss": None,
                "take_profit": None,
                "time_horizon": "1h",
                "reason": "insufficient history for indicators",
            }
        atr = features.atr
        if features.rsi < 30:
            return {
                "action": "LONG",
                "confidence": 0.55,
                "entry": {"type": "MARKET"},
                "stop_loss": round(price - 1.5 * atr, 2),
                "take_profit": round(price + 2.5 * atr, 2),
                "time_horizon": "1h",
                "reason": f"RSI {features.rsi:.1f} indicates oversold conditions",
            }
        if features.rsi > 70:
            return {
                "action": "SHORT",
                "confidence": 0.55,
                "entry": {"type": "MARKET"},
                "stop_loss": round(price + 1.5 * atr, 2),
                "take_profit": round(price - 2.5 * atr, 2),
                "time_horizon": "1h",
                "reason": f"RSI {features.rsi:.1f} indicates overbought conditions",
            }
        return {
            "action": "NO_TRADE",
            "confidence": 0.2,
            "entry": None,
            "stop_loss": None,
            "take_profit": None,
            "time_horizon": "1h",
            "reason": f"RSI {features.rsi:.1f} is neutral, no edge",
        }
