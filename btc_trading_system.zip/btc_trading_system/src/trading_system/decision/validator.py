"""
DecisionValidator: the first hard gate a TradeDecision must pass before
it is ever shown to the risk engine.

This module only checks structural and logical validity -- things a
program can verify with certainty:
  - required fields are present and of a sane type/range
  - action is one of the allowed values
  - stop_loss/take_profit are on the correct side of the entry price
  - entry price (if given) isn't absurdly far from the current market
    price (protects against a hallucinated/garbled price level)
  - the decision was actually based on the snapshot it claims to be
    based on (timestamp match), guarding against stale-decision reuse

It deliberately does NOT attempt semantic contradiction detection (e.g.
"the reason text sounds bearish but the action is LONG") -- that kind of
judgment call belongs to a second LLM-based reviewer if the project ever
wants one, not to brittle string matching here. What this module
guarantees is that anything passing it is at least internally
consistent and numerically sane.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from trading_system.core.enums import TradeAction
from trading_system.core.models import MarketSnapshot
from trading_system.decision.schema import TradeDecision
from trading_system.features.engine import FeatureSet


@dataclass(frozen=True)
class ValidationResult:
    is_valid: bool
    errors: List[str] = field(default_factory=list)


class DecisionValidator:
    def __init__(
        self,
        min_confidence: float = 0.0,
        max_confidence: float = 1.0,
        max_entry_deviation_pct: float = 0.03,   # entry can't be >3% from last price
        allowed_time_horizons: Optional[List[str]] = None,
        min_risk_reward: Optional[float] = None,
        stop_atr_multiple_range: Optional[Tuple[float, float]] = None,
    ):
        self.min_confidence = min_confidence
        self.max_confidence = max_confidence
        self.max_entry_deviation_pct = max_entry_deviation_pct
        self.allowed_time_horizons = allowed_time_horizons  # None = any non-empty string
        # Both of the following are OFF (None) by default -- the base
        # scaffold validator does not require a specific reward:risk or
        # constrain stop distance to a multiple of ATR. Strategy V1 sets
        # both; see strategy/v1_config.py.
        self.min_risk_reward = min_risk_reward
        self.stop_atr_multiple_range = stop_atr_multiple_range
        # NOTE: wall-clock/latency-based staleness ("this decision took too
        # long to arrive") is deliberately NOT checked here. This module
        # is exercised identically in backtests (simulated clock) and live
        # mode (wall clock), and conflating the two would either break
        # backtests or silently disable the check. Real-time staleness of
        # market data is the monitoring layer's job -- see
        # trading_system.monitoring.health.HealthMonitor -- which runs
        # only in paper/live mode against the real clock.

    def validate(
        self,
        decision: TradeDecision,
        snapshot: MarketSnapshot,
        features: Optional[FeatureSet] = None,
    ) -> ValidationResult:
        errors: List[str] = list(decision.parse_errors)

        # If parsing already failed on required fields, no point going
        # further with type-dependent checks below.
        if errors:
            return ValidationResult(is_valid=False, errors=errors)

        if decision.action not in {a.value for a in TradeAction}:
            errors.append(f"action {decision.action!r} is not one of {[a.value for a in TradeAction]}")
            return ValidationResult(is_valid=False, errors=errors)

        if decision.confidence is None:
            errors.append("confidence is required")
        elif not (self.min_confidence <= decision.confidence <= self.max_confidence):
            errors.append(
                f"confidence {decision.confidence} outside allowed range "
                f"[{self.min_confidence}, {self.max_confidence}]"
            )

        if not decision.reason or not decision.reason.strip():
            errors.append("reason must not be empty")

        if self.allowed_time_horizons is not None:
            if decision.time_horizon not in self.allowed_time_horizons:
                errors.append(
                    f"time_horizon {decision.time_horizon!r} not in {self.allowed_time_horizons}"
                )
        elif decision.action != TradeAction.NO_TRADE.value and not decision.time_horizon:
            errors.append("time_horizon is required for LONG/SHORT decisions")

        # Snapshot linkage: the decision must claim to be based on THIS
        # snapshot, not an older one being replayed/reused.
        if decision.snapshot_timestamp != snapshot.timestamp:
            errors.append(
                f"decision.snapshot_timestamp ({decision.snapshot_timestamp}) does not "
                f"match the snapshot it is being validated against ({snapshot.timestamp})"
            )

        if decision.action == TradeAction.NO_TRADE.value:
            # NO_TRADE should not carry an entry/SL/TP -- if it does,
            # that's an internal contradiction worth rejecting rather
            # than silently ignoring.
            if decision.stop_loss is not None or decision.take_profit is not None:
                errors.append("NO_TRADE decisions must not include stop_loss/take_profit")
            return ValidationResult(is_valid=len(errors) == 0, errors=errors)

        # From here on: action is LONG or SHORT.
        if decision.entry is None:
            errors.append("entry is required for LONG/SHORT decisions")
        elif decision.entry.entry_type not in ("MARKET", "LIMIT"):
            errors.append(f"entry.type {decision.entry.entry_type!r} must be MARKET or LIMIT")
        elif decision.entry.entry_type == "LIMIT" and decision.entry.price is None:
            errors.append("entry.price is required when entry.type is LIMIT")

        if decision.stop_loss is None:
            errors.append("stop_loss is required for LONG/SHORT decisions")
        if decision.take_profit is None:
            errors.append("take_profit is required for LONG/SHORT decisions")

        # Reference price used for side-consistency + deviation checks:
        # the limit entry price if given, otherwise current market price.
        reference_price = snapshot.last_price
        if decision.entry is not None and decision.entry.entry_type == "LIMIT" and decision.entry.price:
            reference_price = decision.entry.price

        if decision.entry is not None and decision.entry.entry_type == "LIMIT" and decision.entry.price:
            deviation = abs(decision.entry.price - snapshot.last_price) / snapshot.last_price
            if deviation > self.max_entry_deviation_pct:
                errors.append(
                    f"entry.price {decision.entry.price} deviates {deviation:.2%} from "
                    f"last_price {snapshot.last_price}, exceeding "
                    f"max_entry_deviation_pct={self.max_entry_deviation_pct:.2%}"
                )

        if decision.stop_loss is not None and decision.take_profit is not None:
            if decision.action == TradeAction.LONG.value:
                if not (decision.stop_loss < reference_price < decision.take_profit):
                    errors.append(
                        f"LONG requires stop_loss ({decision.stop_loss}) < entry "
                        f"({reference_price}) < take_profit ({decision.take_profit})"
                    )
            elif decision.action == TradeAction.SHORT.value:
                if not (decision.take_profit < reference_price < decision.stop_loss):
                    errors.append(
                        f"SHORT requires take_profit ({decision.take_profit}) < entry "
                        f"({reference_price}) < stop_loss ({decision.stop_loss})"
                    )

            # Strategy-configurable checks below only make sense once the
            # basic side-consistency check above has passed -- otherwise
            # "risk" or "reward" as computed here would be meaningless.
            stop_distance = abs(reference_price - decision.stop_loss)
            reward_distance = abs(decision.take_profit - reference_price)

            if self.min_risk_reward is not None and stop_distance > 0:
                risk_reward = reward_distance / stop_distance
                if risk_reward < self.min_risk_reward:
                    errors.append(
                        f"reward:risk {risk_reward:.2f} is below required minimum "
                        f"{self.min_risk_reward:.2f} (stop_distance={stop_distance:.2f}, "
                        f"reward_distance={reward_distance:.2f})"
                    )

            if self.stop_atr_multiple_range is not None:
                if features is None or features.atr is None:
                    errors.append(
                        "stop_atr_multiple_range is configured but no ATR is available "
                        "to check against (features missing or insufficient history)"
                    )
                else:
                    lo, hi = self.stop_atr_multiple_range
                    multiple = stop_distance / features.atr if features.atr > 0 else float("inf")
                    if not (lo <= multiple <= hi):
                        errors.append(
                            f"stop distance is {multiple:.2f}x ATR({features.atr:.2f}), "
                            f"outside allowed range [{lo}, {hi}]x"
                        )

        return ValidationResult(is_valid=len(errors) == 0, errors=errors)
