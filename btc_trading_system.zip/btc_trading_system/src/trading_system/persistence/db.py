"""
EventStore: append-only, timestamped log of everything that happens in
the system -- market snapshots, computed features, decisions,
validation results, risk evaluations, orders, fills, position changes,
and P/L events.

Deliberately a single generic `events` table rather than one table per
event type: this is an audit log, not a query-optimized OLTP schema.
Every row has (timestamp, event_type, correlation_id, payload_json), so
you can always answer "show me everything that happened for decision
X" or "show me every RISK_REJECTED event today" without needing joins
or schema migrations every time a new event type is added upstream.

Uses stdlib sqlite3 only -- zero third-party dependencies, works
identically for an in-memory test database and a real on-disk file.
"""

from __future__ import annotations

import dataclasses
import enum
import json
import sqlite3
from typing import Any, Dict, List, Optional

from trading_system.core.models import now_ts

_SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    event_type TEXT NOT NULL,
    correlation_id TEXT,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);
CREATE INDEX IF NOT EXISTS idx_events_correlation ON events(correlation_id);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
"""


def _json_default(obj: Any) -> Any:
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return dataclasses.asdict(obj)
    if isinstance(obj, enum.Enum):
        return obj.value
    if isinstance(obj, frozenset):
        return list(obj)
    return str(obj)


class EventStore:
    def __init__(self, path: str = ":memory:", clock=now_ts):
        self._clock = clock
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    # -- generic -----------------------------------------------------------

    def log_event(
        self,
        event_type: str,
        payload: Any,
        correlation_id: Optional[str] = None,
        ts: Optional[float] = None,
    ) -> int:
        payload_json = json.dumps(payload, default=_json_default)
        cur = self._conn.execute(
            "INSERT INTO events (ts, event_type, correlation_id, payload) VALUES (?, ?, ?, ?)",
            (ts if ts is not None else self._clock(), event_type, correlation_id, payload_json),
        )
        self._conn.commit()
        return cur.lastrowid

    # -- typed convenience wrappers ----------------------------------------
    # Each of these just calls log_event with a consistent event_type
    # string and a correlation_id that lets you trace one decision's
    # full lifecycle end to end.

    def log_snapshot(self, snapshot) -> int:
        return self.log_event(
            "MARKET_SNAPSHOT",
            dataclasses.asdict(snapshot),
            correlation_id=f"snapshot_{snapshot.timestamp}",
            ts=snapshot.timestamp,
        )

    def log_features(self, features, correlation_id: Optional[str] = None) -> int:
        return self.log_event(
            "FEATURES",
            features.to_dict(),
            correlation_id=correlation_id or f"snapshot_{features.timestamp}",
            ts=features.timestamp,
        )

    def log_decision(self, decision) -> int:
        return self.log_event(
            "DECISION",
            dataclasses.asdict(decision),
            correlation_id=decision.decision_id,
            ts=decision.created_at,
        )

    def log_validation(self, result, decision_id: str) -> int:
        return self.log_event(
            "VALIDATION",
            dataclasses.asdict(result),
            correlation_id=decision_id,
        )

    def log_risk_evaluation(self, evaluation, decision_id: str) -> int:
        return self.log_event(
            "RISK_EVALUATION",
            dataclasses.asdict(evaluation),
            correlation_id=decision_id,
        )

    def log_order(self, order, correlation_id: Optional[str] = None) -> int:
        return self.log_event(
            "ORDER",
            dataclasses.asdict(order),
            correlation_id=correlation_id or order.client_order_id,
            ts=order.updated_at,
        )

    def log_fill(self, fill, correlation_id: Optional[str] = None) -> int:
        return self.log_event(
            "FILL",
            dataclasses.asdict(fill),
            correlation_id=correlation_id or fill.order_id,
            ts=fill.timestamp,
        )

    def log_position(self, position, correlation_id: Optional[str] = None) -> int:
        return self.log_event(
            "POSITION",
            dataclasses.asdict(position),
            correlation_id=correlation_id or position.symbol,
            ts=position.updated_at,
        )

    def log_pnl_event(
        self, pnl: float, context: Optional[Dict[str, Any]] = None, correlation_id: Optional[str] = None
    ) -> int:
        payload = {"pnl": pnl, **(context or {})}
        return self.log_event("PNL", payload, correlation_id=correlation_id)

    def log_discrepancy(self, discrepancy) -> int:
        return self.log_event("RECONCILIATION_DISCREPANCY", dataclasses.asdict(discrepancy))

    def log_health(self, payload: Dict[str, Any]) -> int:
        return self.log_event("HEALTH", payload)

    # -- queries -----------------------------------------------------------

    def get_events(
        self,
        event_type: Optional[str] = None,
        correlation_id: Optional[str] = None,
        since: Optional[float] = None,
        until: Optional[float] = None,
        limit: int = 1000,
    ) -> List[Dict[str, Any]]:
        clauses = []
        params: List[Any] = []
        if event_type is not None:
            clauses.append("event_type = ?")
            params.append(event_type)
        if correlation_id is not None:
            clauses.append("correlation_id = ?")
            params.append(correlation_id)
        if since is not None:
            clauses.append("ts >= ?")
            params.append(since)
        if until is not None:
            clauses.append("ts <= ?")
            params.append(until)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        query = f"SELECT id, ts, event_type, correlation_id, payload FROM events {where} ORDER BY id ASC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(query, params).fetchall()
        return [
            {
                "id": r[0],
                "ts": r[1],
                "event_type": r[2],
                "correlation_id": r[3],
                "payload": json.loads(r[4]),
            }
            for r in rows
        ]

    def count_events(self, event_type: Optional[str] = None) -> int:
        if event_type is None:
            return self._conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        return self._conn.execute(
            "SELECT COUNT(*) FROM events WHERE event_type = ?", (event_type,)
        ).fetchone()[0]
