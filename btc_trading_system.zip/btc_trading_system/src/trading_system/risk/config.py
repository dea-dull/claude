"""Risk limit configuration.

Every field here is a hard limit enforced by RiskEngine, not a
suggestion Claude can override. There is deliberately no "trust the
model's confidence blindly" path: confidence only ever gates whether a
trade is *considered*, never how large it is or whether limits apply.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RiskLimits:
    # -- sizing ------------------------------------------------------------
    max_position_size_usd: float = 2_000.0
    max_leverage: float = 3.0
    risk_per_trade_pct: float = 0.005   # fraction of equity risked per trade (0.5%)

    # -- loss limits --------------------------------------------------------
    max_loss_per_trade_usd: float = 100.0
    max_daily_loss_usd: float = 300.0

    # -- exposure -----------------------------------------------------------
    max_concurrent_positions: int = 1
    max_position_pct_of_equity: float = 0.5

    # -- decision gating ------------------------------------------------------
    min_confidence_to_trade: float = 0.55
    require_stop_loss: bool = True

    # -- circuit breakers -------------------------------------------------
    cooldown_after_loss_seconds: float = 0.0     # 0 = disabled
    max_consecutive_losses_before_pause: int = 0  # 0 = disabled

    # -- kill switch ---------------------------------------------------------
    trading_enabled: bool = True
