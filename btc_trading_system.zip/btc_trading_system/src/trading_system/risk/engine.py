"""
RiskEngine: the final authority before anything reaches the exchange.

Hard rule enforced by construction, not just convention: Claude's output
(TradeDecision) never contains a position size, and RiskEngine computes
size independently from account equity, stop distance, and the
configured RiskLimits. A "confident" decision from Claude is not treated
any differently from a hesitant one except via the min_confidence_to_trade
gate -- confidence never scales position size.

RiskEngine also owns the account-level circuit breakers (daily loss
limit, consecutive-loss pause, emergency shutdown) because those need
state that persists across many individual decisions, not just
knowledge of the current one.
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from typing import List, Optional

from trading_system.core.enums import OrderSide, OrderType, TradeAction
from trading_system.core.models import AccountBalance, MarketSnapshot, Position, now_ts
from trading_system.decision.schema import TradeDecision
from trading_system.risk.config import RiskLimits


@dataclass(frozen=True)
class RiskApprovedOrder:
    decision_id: str
    symbol: str
    side: OrderSide
    order_type: OrderType
    size: float
    leverage: float
    entry_price: Optional[float]        # None for MARKET (filled at market)
    limit_price: Optional[float]
    stop_loss: float
    take_profit: float
    risk_amount_usd: float
    notional_usd: float


@dataclass(frozen=True)
class RiskEvaluation:
    approved: bool
    reasons: List[str] = field(default_factory=list)
    approved_order: Optional[RiskApprovedOrder] = None
    is_no_op: bool = False    # True for a validly-approved NO_TRADE


class RiskEngine:
    def __init__(self, limits: RiskLimits, clock=now_ts):
        self.limits = limits
        self._clock = clock
        self._daily_pnl = 0.0
        self._daily_key = self._day_key(clock())
        self._consecutive_losses = 0
        self._last_loss_ts: Optional[float] = None
        self._emergency_stopped = False
        self._emergency_reason: Optional[str] = None

    # -- circuit breaker state --------------------------------------------

    @staticmethod
    def _day_key(ts: float) -> str:
        return datetime.datetime.fromtimestamp(ts, tz=datetime.timezone.utc).strftime("%Y-%m-%d")

    def _roll_day_if_needed(self) -> None:
        key = self._day_key(self._clock())
        if key != self._daily_key:
            self._daily_key = key
            self._daily_pnl = 0.0

    def record_realized_pnl(self, pnl: float) -> None:
        """Call this whenever a position closes (paper or live) so the
        daily loss limit and consecutive-loss breaker stay accurate."""
        self._roll_day_if_needed()
        self._daily_pnl += pnl
        if pnl < 0:
            self._consecutive_losses += 1
            self._last_loss_ts = self._clock()
        else:
            self._consecutive_losses = 0

    def trigger_emergency_shutdown(self, reason: str) -> None:
        self._emergency_stopped = True
        self._emergency_reason = reason

    def reset_emergency_shutdown(self) -> None:
        self._emergency_stopped = False
        self._emergency_reason = None

    def is_halted(self) -> bool:
        return self._emergency_stopped or not self.limits.trading_enabled

    @property
    def daily_pnl(self) -> float:
        self._roll_day_if_needed()
        return self._daily_pnl

    # -- main entry point ---------------------------------------------------

    def evaluate(
        self,
        decision: TradeDecision,
        snapshot: MarketSnapshot,
        account: List[AccountBalance],
        open_positions: List[Position],
    ) -> RiskEvaluation:
        self._roll_day_if_needed()
        reasons: List[str] = []

        if self._emergency_stopped:
            return RiskEvaluation(
                approved=False,
                reasons=[f"emergency shutdown active: {self._emergency_reason}"],
            )
        if not self.limits.trading_enabled:
            return RiskEvaluation(approved=False, reasons=["trading disabled by kill switch"])

        if decision.action == TradeAction.NO_TRADE.value:
            return RiskEvaluation(approved=True, is_no_op=True)

        if decision.confidence is None or decision.confidence < self.limits.min_confidence_to_trade:
            reasons.append(
                f"confidence {decision.confidence} below min_confidence_to_trade "
                f"={self.limits.min_confidence_to_trade}"
            )

        if self.limits.require_stop_loss and decision.stop_loss is None:
            reasons.append("stop_loss is required by risk policy but missing")

        if self.limits.max_daily_loss_usd is not None and self._daily_pnl <= -abs(
            self.limits.max_daily_loss_usd
        ):
            reasons.append(
                f"daily loss limit reached: {self._daily_pnl:.2f} <= "
                f"-{self.limits.max_daily_loss_usd:.2f}"
            )

        if (
            self.limits.max_consecutive_losses_before_pause
            and self._consecutive_losses >= self.limits.max_consecutive_losses_before_pause
        ):
            reasons.append(
                f"{self._consecutive_losses} consecutive losses reached configured pause "
                f"threshold ({self.limits.max_consecutive_losses_before_pause})"
            )

        if (
            self.limits.cooldown_after_loss_seconds
            and self._last_loss_ts is not None
            and (self._clock() - self._last_loss_ts) < self.limits.cooldown_after_loss_seconds
        ):
            remaining = self.limits.cooldown_after_loss_seconds - (self._clock() - self._last_loss_ts)
            reasons.append(f"in post-loss cooldown for {remaining:.0f} more seconds")

        open_count = sum(1 for p in open_positions if p.size > 0)
        if open_count >= self.limits.max_concurrent_positions:
            reasons.append(
                f"{open_count} open position(s) already at/above "
                f"max_concurrent_positions={self.limits.max_concurrent_positions}"
            )

        if reasons:
            return RiskEvaluation(approved=False, reasons=reasons)

        # -- sizing -----------------------------------------------------------
        entry_price = snapshot.last_price
        limit_price = None
        order_type = OrderType.MARKET
        if decision.entry is not None and decision.entry.entry_type == "LIMIT" and decision.entry.price:
            entry_price = decision.entry.price
            limit_price = decision.entry.price
            order_type = OrderType.LIMIT

        stop_distance = abs(entry_price - decision.stop_loss) if decision.stop_loss is not None else 0.0
        if stop_distance <= 0:
            return RiskEvaluation(
                approved=False,
                reasons=[f"invalid stop distance ({stop_distance}) for entry {entry_price}"],
            )

        equity = sum(b.total for b in account) if account else 0.0
        available = sum(b.available for b in account) if account else 0.0
        if equity <= 0:
            return RiskEvaluation(approved=False, reasons=["account equity is zero or unavailable"])

        target_risk_usd = min(
            equity * self.limits.risk_per_trade_pct,
            self.limits.max_loss_per_trade_usd,
        )
        size = target_risk_usd / stop_distance

        notional = size * entry_price
        max_notional = min(
            self.limits.max_position_size_usd,
            equity * self.limits.max_position_pct_of_equity,
        )
        if notional > max_notional:
            size = max_notional / entry_price
            notional = size * entry_price

        leverage = min(self.limits.max_leverage, max(1.0, notional / max(available, 1e-9)))
        # Never exceed the configured leverage cap even if margin would allow it.
        leverage = min(leverage, self.limits.max_leverage)
        required_margin = notional / leverage
        if required_margin > available:
            return RiskEvaluation(
                approved=False,
                reasons=[
                    f"insufficient available margin: need {required_margin:.2f}, "
                    f"have {available:.2f}"
                ],
            )

        actual_risk_usd = size * stop_distance
        side = OrderSide.BUY if decision.action == TradeAction.LONG.value else OrderSide.SELL

        approved_order = RiskApprovedOrder(
            decision_id=decision.decision_id,
            symbol=snapshot.symbol,
            side=side,
            order_type=order_type,
            size=size,
            leverage=leverage,
            entry_price=entry_price if order_type == OrderType.MARKET else None,
            limit_price=limit_price,
            stop_loss=decision.stop_loss,
            take_profit=decision.take_profit,
            risk_amount_usd=actual_risk_usd,
            notional_usd=notional,
        )
        return RiskEvaluation(approved=True, approved_order=approved_order)
