# Strategy V1 Specification — BTC Perpetual, Claude-Driven

Status: **rejected, based on a full real-data backtest.** The
deterministic reference engine (not real Claude, see Section 14) was
tested against the complete available real BTC 4h history — 5844
candles, January 2024 through August 2026, 610 closed trades — and
showed negative expectancy in every regime bucket (bull, bear, and
chop) and across most calendar quarters. See Section 17 for the final
result and Sections 15-16 for the progression of results as more data
became available (synthetic → 20 months real → full 32 months real).
Per the brief, this is reported as evidence to iterate from, not forced
to look better. This document is the spec;
`experiments/backtest_strategy_v1.py` is the test of it.

## 1. Instrument and decision frequency

- **Instrument**: BTC perpetual (symbol-agnostic in code; `BTCUSDT` used
  throughout since that's what Margex will presumably expose — TBD once
  the real API is verified).
- **Decision frequency: once every 4 hours**, aligned to candle close
  (00:00, 04:00, 08:00, 12:00, 16:00, 20:00 UTC).
  - Rationale: (a) it's a timeframe with a real edge case for
    LLM-based reasoning to matter (enough time for genuine regime/momentum
    reads, unlike 1-minute noise); (b) it keeps live API-call volume
    trivial (6/day) regardless of what Margex's rate limits turn out to
    be; (c) 4h is standard granularity for free historical BTC data
    sources, keeping backtesting and live decision cadence consistent.
- The system does **not** intrabar-monitor for entries. A decision made
  at candle close is acted on at that close price (see Entry logic).
  Stop-loss/take-profit ARE monitored continuously between decisions
  (see below) — those are mechanical exits, not new Claude decisions.

## 2. Exact market information Claude receives

Built by `build_snapshot_payload()` (existing code, unchanged) from a
`MarketSnapshot` frozen at the decision timestamp. For Strategy V1
specifically:

- `last_price`, `best_bid`, `best_ask` at decision time.
- Top 5 levels of the order book (bids/asks) — synthetic/spread-implied
  in backtest, real book once Margex is connected.
- **Last 100 4-hour candles** (≈16.7 days of history) — open/high/low/close/volume.
- `funding_rate` if available (None in this backtest — see §10).
- `open_interest` if available (None in this backtest — no OI in the
  synthetic/free-tier data used here).
- The full `FeatureSet` computed by the existing `FeatureEngine` (§3).

Claude receives **nothing else**: no news, no sentiment, no on-chain
data, no cross-asset data (e.g. equities, DXY), no order flow beyond the
top-5 book. This is a deliberate scope limit for V1 — if this narrow
information set can't produce positive expectancy, richer inputs are a
reasonable v2 direction, but adding them now would make a failed
backtest ambiguous (is the strategy bad, or just under-informed?).

## 3. Features available to Claude

The existing `FeatureEngine`, configured for 4h candles:

| Feature | Period (candles) | Real-world span |
|---|---|---|
| `sma_fast` / `sma_slow` | 12 / 48 | 2 days / 8 days |
| `ema_fast` / `ema_slow` | 12 / 26 | 2 days / ~4.3 days |
| `rsi` | 14 | ~2.3 days |
| `atr` | 14 | ~2.3 days |
| `realized_vol` | 20 | ~3.3 days |
| `momentum` | 12 | 2 days |
| `spread`, `spread_bps`, `order_book_imbalance` | current | — |

No parameters are changed for this strategy beyond period counts — same
`FeatureEngine` code as the scaffold, just configured for a 4h bar
instead of the 1-minute default. This is intentional: features are
mechanical inputs, not the strategy itself.

## 4. LONG / SHORT / NO_TRADE rules

Claude is instructed (via system prompt extra, see
`strategy/v1_config.py::PROMPT_ADDENDUM`) to trade **only** clear
trend-continuation or mean-reversion-at-extreme setups, and to default
to `NO_TRADE` otherwise:

- **LONG** is only appropriate when there is a coherent case combining
  at least two of: (a) price above both SMAs with fast > slow (uptrend
  structure), (b) RSI recovering from oversold (<40) without being
  overbought (>75), (c) positive momentum, (d) reasonable realized
  volatility (not so low that a stop/target can't be sized sensibly, not
  so high that noise dominates).
- **SHORT** is the mirror image (downtrend structure, RSI falling from
  overbought without being oversold, negative momentum).
- **NO_TRADE** is explicitly the default. Claude is told: "If the
  setup is ambiguous, mixed, or you would only take it out of a desire
  to produce an answer, return NO_TRADE." This is the single most
  important instruction in the prompt — a strategy that never says
  NO_TRADE is not being evaluated for skill, just for activity.

These are **guidelines given to Claude in the prompt**, not code-enforced
rules — Claude's judgment is the point of the experiment. What IS
code-enforced is everything downstream (§5–§9, and the existing
validator/risk engine).

## 5. Confidence requirements

- Claude reports `confidence` in [0, 1] as before.
- **`min_confidence_to_trade = 0.60`** for this strategy (higher than the
  scaffold's default 0.55) — 4h decisions are lower-frequency and each
  one matters more, so the bar for acting is set a bit higher.
- Confidence never affects position size (unchanged architectural
  invariant from the scaffold — enforced by `RiskEngine`, not by this
  spec).

## 6. Entry logic

- **Entry type: MARKET only** for V1. No limit-order entries.
  Rationale: keeps backtest cost modeling honest (a limit order that
  "would have filled" in a backtest is a classic source of optimistic
  bias) and keeps the strategy simple to reason about for a first test.
  Limit entries are a reasonable v2 addition once market-order
  expectancy is established.
- Entry price = the ask (LONG) or bid (SHORT) at decision time, i.e. the
  cost model charges the spread on every entry (§10).

## 7. Stop-loss logic

- **Mandatory on every LONG/SHORT decision** (already enforced by
  `RiskLimits.require_stop_loss=True` and `DecisionValidator`).
- Claude sets the stop-loss level itself (not a fixed multiple), but
  the validator's existing side-consistency check still applies (SL
  below entry for LONG, above for SHORT).
- **Sanity bound (new for V1)**: stop distance must be between **0.5×
  and 4× the current ATR(14)**. Tighter than 0.5×ATR is almost
  certainly going to be noise-stopped; wider than 4×ATR makes the
  position-sizing math (which sizes off stop distance) produce an
  unreasonably small size for the configured risk-per-trade. Enforced
  in `StrategyV1Validator` (an addition wrapping the base
  `DecisionValidator`, see §12).

## 8. Take-profit logic

- Claude sets take-profit itself, same as stop-loss.
- **Minimum reward:risk of 1.2:1** required (see §9) — take-profit
  distance from entry must be at least 1.2× the stop-loss distance.
  This is a floor, not a target; Claude is free to (and encouraged to)
  set wider targets when the setup justifies it.

## 9. Risk/reward requirements

- **Minimum R:R = 1.2** (take-profit distance ÷ stop-loss distance),
  enforced by `StrategyV1Validator`. Chosen deliberately modest (not
  2:1 or 3:1) because requiring a very high R:R just pushes a strategy
  toward wider, more speculative targets that rarely get hit — the goal
  is a real floor against obviously bad setups (e.g. TP barely past
  entry), not a de facto minimum win-size mandate.
- Position sizing itself is unchanged from the scaffold: `RiskEngine`
  computes size from `risk_per_trade_pct` of equity and the stop
  distance Claude chose, independent of Claude's confidence or reward
  target.

## 10. Maximum holding period

- **48 hours (12 bars of 4h) per position.** If neither the stop-loss
  nor take-profit has been hit within that window, the position is
  force-closed at market on the next tick after the deadline.
- This is a **code-enforced** rule, not a Claude decision — implemented
  as `HoldingPeriodPolicy` (new, small module), which runs before each
  decision cycle and can submit a reduce-only close order directly
  through the existing `ExecutionEngine`, completely independent of
  what Claude would say if asked. Rationale: an LLM asked "should I
  still hold this" tends to rationalize holding; a hard deadline avoids
  that failure mode and keeps the experiment about entry/exit-level
  selection, not indefinite-hold risk.

## 11. Conditions where trading is forbidden

All pre-existing `RiskEngine`/`HealthMonitor` gates apply unchanged
(daily loss limit, max concurrent positions = 1 for V1, emergency
shutdown, stale data, kill switch). Strategy V1 adds nothing new here
except tighter numbers:

| Limit | V1 value | Scaffold default |
|---|---|---|
| `max_concurrent_positions` | 1 | 1 |
| `min_confidence_to_trade` | 0.60 | 0.55 |
| `max_daily_loss_usd` | 2% of starting equity | flat $300 |
| `max_loss_per_trade_usd` | 0.5% of starting equity | flat $100 |
| `risk_per_trade_pct` | 0.5% | 0.5% |
| `max_leverage` | 2.0 | 3.0 |

Lower leverage cap than the scaffold default: this is a first test of
whether the *signal* has any edge at all — leverage only amplifies
whatever expectancy (positive or negative) the underlying decisions
have, so it's kept conservative until there's evidence worth amplifying.

## 12. Fees, spread, slippage, and funding modeling

This is the part that determines whether "positive expectancy" means
anything. Implemented in `exchange/simulated_matching.py`
(`CostModel`, extending the existing matching engine — see PR notes in
that file's docstring):

- **Spread**: every market fill crosses the synthesized book — a
  MARKET BUY fills at the current best ask, a MARKET SELL at the
  current best bid. This is charged on every entry AND every exit
  (including forced holding-period closes and SL/TP fills), not just
  entries.
- **Taker fee**: 6 bps (0.06%) of notional, applied to every market
  fill (entries, holding-period force-closes, and stop-loss fills,
  since a stop-market order is a taker order).
- **Maker fee**: 1.9 bps (0.019%) of notional, applied to take-profit
  fills (modeled as resting limit orders, i.e. maker) — matching
  Margex's own publicly advertised fee schedule (0.019%/0.06%) as the
  best available reference point, pending confirmation once the real
  fee schedule is verified via the API.
- **Slippage**: an additional 2 bps applied on top of spread for every
  market fill, representing size/impact beyond the quoted top-of-book
  — deliberately small since V1 position sizes are small relative to
  BTC's typical liquidity, but non-zero so the backtest isn't crediting
  free execution.
- **Funding**: applied every 8 simulated hours to any open position:
  `payment = position.size × mark_price × funding_rate`, long pays
  when `funding_rate > 0`, short receives (standard perpetual
  convention). **Funding rate is not available in the free historical
  data used for this backtest**, so it is modeled as a constant
  assumption (`DEFAULT_FUNDING_RATE_PER_8H = 0.0001`, i.e. ≈11%
  annualized, a rough historical average for BTC perps) — this is
  flagged explicitly in the backtest report, and should be replaced
  with the real historical funding series once available (or with
  Margex's actual live funding once connected).

None of this claims to match Margex's exact matching engine or fee
schedule — see the caveats already documented in
`simulated_matching.py`. It's the most realistic cost model achievable
without verified Margex data, applied consistently and conservatively
(if anything, erring toward slightly pessimistic).

## 13. Determinism / reproducibility

- Historical data is a fixed, versioned input (a CSV file, loaded once)
  — same file in, same candles out, every run.
- `MockDecisionEngine`/`RuleBasedReferenceDecisionEngine` (§14) are
  deterministic given the same feature values — no randomness.
- The real `ClaudeDecisionEngine`, once wired to the live API, is
  **not** perfectly deterministic (temperature > 0 by default) — for
  reproducible backtest comparisons, `temperature=0` should be used for
  any Claude-in-the-loop backtest run, and even then minor API-level
  nondeterminism can occur. This is disclosed rather than hidden: a
  single backtest run against real Claude is one sample, not a proof.
  Running the same historical window multiple times and looking at
  variance is the appropriate way to build confidence, not a single
  pass.

## 14. What actually gets backtested right now, and why

**This sandboxed environment cannot make outbound network calls**, so
neither backtest script can call the real Claude API directly from
here. Two things follow from that:

1. `RuleBasedReferenceDecisionEngine` implements the LONG/SHORT/NO_TRADE
   rules in §4 as literal code (not an LLM) purely so the *mechanical*
   system — cost model, holding-period enforcement, R:R/stop-distance
   validation, risk sizing, execution — can be exercised end-to-end and
   produce a real number. This tells us whether the strategy's
   *structure* (the rules in §4, mechanically applied) has positive
   expectancy after realistic costs. It does **not** tell us whether
   real Claude reasoning adds anything beyond that mechanical
   application, which is the actually interesting question.
2. To test genuine Claude decision-making with the **Claude Baseline**
   prompt (see `strategy/baseline_config.py` — deliberately minimal,
   carries none of §4's condition-counting logic), run
   `experiments/backtest_claude_baseline.py` in an environment with
   network access and an Anthropic API key set (`ANTHROPIC_API_KEY`).
   **Do not use `experiments/backtest_strategy_v1.py --engine claude`
   for this** — that script's `--engine claude` mode wires in V1's own
   prompt (`v1_config.PROMPT_ADDENDUM`), which narrates V1's exact
   rules to Claude in prose. That's a different, legitimate experiment
   (does Claude execute V1's own logic better than the rule engine
   does?) but it is NOT the Baseline and would contaminate any
   comparison between "Claude's own judgment" and "V1's mechanical
   rules" if the two were conflated. This distinction was the subject
   of an explicit audit — see the note below.
3. **Audit note (read before running the Baseline for real):** an
   audit of the `--engine claude` execution path confirmed
   `ClaudeDecisionEngine` itself only ever injects strategy-specific
   text via its `system_prompt_extra` parameter (the rest of its
   prompt-building is generic schema/rules, unconditionally the same
   regardless of which strategy is running), and confirmed
   `baseline_config.BASELINE_PROMPT` contains no V1 decision logic and
   re-exports only the approved system-level infrastructure
   (`FEATURE_ENGINE`, `VALIDATOR`, `COST_MODEL`, `build_risk_limits`,
   `MAX_HOLDING_SECONDS`, `SPREAD_BPS`) from `v1_config`. The audit DID
   find `experiments/backtest_strategy_v1.py`'s `build_claude_engine()`
   wired to `v1_config.PROMPT_ADDENDUM` — a wiring defect in that
   script, not a change to the baseline's content — which is why
   `experiments/backtest_claude_baseline.py` exists as a dedicated,
   separately-audited script rather than a shared flag. See
   `tests/test_claude_baseline_audit.py` for the full automated proof
   (prompt provenance, absence of V1 instructional language, and exact
   untruncated persistence of every prompt/response pair), and
   `experiments/backtest_claude_baseline.py`'s own docstring for the
   one-line prompt-provenance statement.

The honest framing for this phase's result, stated up front: **a
positive result from the rule-based engine is necessary-but-not-
sufficient evidence** (it means the mechanical system doesn't destroy
value through costs/bugs); **a negative result from the rule-based
engine is still informative** (if literal, unambiguous application of
the rules can't overcome costs, that's a real signal the rules need
revision before spending real API calls on them).

## 15. Result: first backtest (rule-based reference engine, synthetic data)

**Correction notice (read this first):** an earlier version of this
report stated -21.31% net / -15.31% at zero cost. Those numbers were
produced before four bugs were found and fixed in the backtest
engine itself (cost-baseline timing, missing OCO cancellation on SL/TP
brackets, a cumulative-P/L tracker that silently reset on every new
trade, and -- the most consequential -- the risk engine's daily-loss
circuit breaker using real wall-clock time instead of the backtest's
simulated time, which meant it could trip once and never reset for the
rest of a run). All four are now covered by regression tests in
`tests/test_backtest_reconciliation.py`, which asserts the sum of every
closed trade's P/L matches the account's actual equity change. The
numbers below are the corrected result. The qualitative verdict
(negative expectancy, not primarily a cost story) did not change, but
the exact figures did.

Run: `PYTHONPATH=src python3 experiments/backtest_strategy_v1.py`
(fully deterministic and reproducible -- see `experiments/results/strategy_v1_rules.json`).

Data: 1500 candles (250 days) of the synthetic regime-switching series
in `data/btc_4h_synthetic.csv` (see the warning about this NOT being
real BTC data in Section 14 and in the generator's own docstring).

| Metric | Value |
|---|---|
| Trades opened / closed | 174 / 173 |
| Win rate | 45.1% |
| Avg win / avg loss | +44.56 / -45.52 |
| Expectancy per trade | -4.91 |
| Profit factor | 0.80 |
| Avg R multiple | -0.135 |
| Max drawdown | 989.26 USDT |
| Performance BEFORE costs | -229.20 USDT (-2.29%) |
| Performance AFTER costs | -848.98 USDT |
| Net P/L (equity-based, after all costs) | **-8.51%** |

**Verdict: negative expectancy.** Per the brief, this is being reported
as a real result, not iterated on until it looks better.

The more useful finding is still *why*, and it still holds up under the
corrected numbers: performance before any fees/spread/slippage/funding
is -2.29%, and costs roughly triple the damage to -8.51%. Unlike the
original (buggy) report, costs now make up a more meaningful share of
the loss than before -- but the strategy was already losing before a
single fee was charged, so the core finding is unchanged: the Section 4
rules, applied literally, do not have a real edge here. A 45.1% win
rate with a negative average R is not a coin flip with bad luck, it's a
filter that's net wrong more often than it's net right.

**Regime breakdown (frozen definition, see `strategy/regime.py`) is the
most interesting new information** the corrected engine now surfaces:

| Regime | Trades | Win rate | Expectancy/trade | Total P/L |
|---|---|---|---|---|
| bull | 25 | 60.0% | +9.44 | **+235.92** |
| bear | 81 | 40.7% | -4.05 | -328.09 |
| chop | 67 | 44.8% | -11.30 | -756.82 |

The entire loss is concentrated in chop and, to a lesser extent, bear
regimes -- the strategy is actually **profitable in bull regimes** on
this dataset. That's exactly the kind of regime-conditional signal the
aggregate -8.51% number hides, and it's a much more specific, testable
hypothesis than "the strategy doesn't work": maybe the trend/RSI/
momentum combination genuinely has some signal in trending-up
conditions and is just noise (or actively wrong) elsewhere. This is
also a good illustration of why the brief's regime-breakdown
requirement matters -- the aggregate number alone would have hidden
this.

**What this does and doesn't mean for next steps:**
- It does NOT mean "Claude trading BTC can't work" -- this run used the
  deterministic reference engine, not real Claude, and used synthetic
  rather than real historical data. Both are real limitations on how
  much to read into this specific number (see Section 14).
- It DOES mean the *specific mechanical rules* in Section 4, as
  literally written, are not a good enough entry/exit filter on their
  own across all regimes to be worth pointing real Claude calls at
  without revision.
- The bull-regime profitability is a hypothesis worth carrying into the
  Claude Baseline experiment's regime breakdown as a point of
  comparison, not a conclusion to act on from one synthetic-data run.
- Reasonable next iterations, in rough order of effort: (a) re-run this
  exact experiment against real historical BTC data before changing
  anything else, since synthetic-data results may not transfer; (b)
  run the Claude Baseline experiment (see `strategy/baseline_config.py`)
  to see whether genuine judgment beats this mechanical floor, and
  whether it shows the same bull-regime-only pattern; (c) if still
  weak, revisit the Section 4 condition thresholds or the fixed
  ATR-multiple stop/target sizing, which were one reasonable literal
  reading of the spec, not a tuned result.


## 16. Result: real data (rule-based reference engine, Jan 2024 - Aug 2025)

Run: `PYTHONPATH=src python3 experiments/backtest_strategy_v1.py --data data/real/btc_4h_real.csv`

Data: **3654 real 4-hour BTCUSDT candles** from Binance (Jan 1, 2024 -
Aug 31, 2025, 20 concatenated monthly exports, verified gap-free by
`experiments/convert_binance_klines.py`), spanning a genuine bull run,
a genuine drawdown, and chop ($38,545 - $124,545 range). Real historical
funding rates from `data/real/BTCUSDT_funding.csv` (8h intervals,
Jan 2024 - present) were used in place of the constant-rate assumption.

Still using `RuleBasedReferenceDecisionEngine`, NOT real Claude -- see
Section 14. This is real market data through the mechanical system, not
yet a test of genuine judgment.

| Metric | Value |
|---|---|
| Trades opened / closed | 388 / 387 |
| Win rate | 45.0% |
| Avg win / avg loss | +37.68 / -40.60 |
| Expectancy per trade | -5.41 |
| Profit factor | 0.76 |
| Avg R multiple | -0.117 |
| Max drawdown | 2693.48 USDT |
| Performance BEFORE costs | -938.79 USDT (-9.39%) |
| Performance AFTER costs | -2092.34 USDT |
| Net P/L (equity-based) | **-20.94%** |

Reconciliation: sum of closed-trade P/L (-2092.34) vs. actual equity
change (-2094.00) -- $1.66 residual, fully explained by the one
position still open when the data ends.

**Regime breakdown** (frozen definition, 20 months gives the 30-day SMA
enough lead-in to actually populate all three buckets now, unlike the
1-month file):

| Regime | Trades | Win rate | Expectancy/trade | Total P/L |
|---|---|---|---|---|
| bull | 189 | 48.7% | -1.26 | -238.82 |
| bear | 118 | 41.5% | -9.73 | -1148.33 |
| chop | 80 | 41.3% | -8.81 | -705.19 |

Unlike the synthetic-data run (Section 15), **bull regime is no longer
clearly profitable on real data** -- it's close to breakeven (-1.26/trade)
while bear and chop are both clearly negative. The synthetic dataset's
"strategy works in bull markets" pattern does not replicate on the real
20-month BTC series. This is exactly the kind of thing synthetic data
can mislead you about, and exactly why Section 14's caveat about
synthetic results not transferring was worth taking seriously.

**Calendar-quarter breakdown** shows no consistent pattern either --
positive in 2024-Q1, 2024-Q3, and 2025-Q2, meaningfully negative in
2024-Q2, 2025-Q1, and 2025-Q3. Full numbers in
`experiments/results/strategy_v1_rules.json` after running the command
above.

**Verdict, now with real data and 387 closed trades (materially more
statistical power than either prior run): negative expectancy, no
regime shows a real edge, and the pattern is not stable quarter to
quarter.** This strengthens rather than overturns the Section 15
conclusion -- the Section 4 rules, applied literally, do not have a
demonstrable edge on real BTC data over this window, in any regime this
scheme identifies.

**What real Claude judgment might add that this can't show:** the
reference engine cannot use context outside its four hardcoded
conditions, cannot weigh conflicting signals with judgment, and cannot
recognize when a superficially-matching setup is actually a bad idea
for reasons the rules don't encode. Whether real Claude reasoning over
the same data and costs does better, the same, or worse is still the
open question this phase exists to answer -- see Section 14 for exactly
how to run that comparison once network + API access are available.

Additional months of real data (2025-09 onward) will extend this
dataset further when available; the verdict is unlikely to flip with
more data given the consistency across regimes and quarters already
shown, but the additional months will be incorporated before drawing a
final conclusion.


## 17. Result: FULL real dataset (rule-based reference engine, Jan 2024 - Aug 2026)

**This supersedes Section 16.** All 32 monthly Binance exports the user
had access to are now concatenated (verified gap-free across every
month boundary by `experiments/convert_binance_klines.py`), giving
**5844 real 4-hour candles spanning January 1, 2024 to August 31,
2026** -- essentially the entire available history for this instrument
at this granularity, not a partial sample. Real historical funding
rates used throughout.

Run: `PYTHONPATH=src python3 experiments/backtest_strategy_v1.py --data data/real/btc_4h_real.csv --funding data/real/BTCUSDT_funding.csv`

Still `RuleBasedReferenceDecisionEngine`, not real Claude -- see Section 14.

| Metric | Value |
|---|---|
| Trades opened / closed | 611 / 610 |
| Win rate | 45.1% |
| Avg win / avg loss | +34.32 / -38.10 |
| Expectancy per trade | -5.45 |
| Profit factor | 0.74 |
| Avg R multiple | -0.131 |
| Max drawdown | 3901.15 USDT |
| Performance BEFORE costs | -1577.86 USDT (-15.78%) |
| Performance AFTER costs | -3326.83 USDT |
| Net P/L (equity-based) | **-33.29%** |

Reconciliation: sum of closed-trade P/L (-3326.83) vs. actual equity
change (-3328.72) -- $1.88 residual, fully explained by the one
position still open when the data ends.

**Regime breakdown -- now every regime is negative:**

| Regime | Trades | Win rate | Expectancy/trade | Total P/L |
|---|---|---|---|---|
| bull | 264 | 46.2% | -3.16 | -835.07 |
| bear | 222 | 46.8% | -6.43 | -1427.63 |
| chop | 124 | 39.5% | -8.58 | -1064.13 |

With the partial (20-month) dataset, bull regime was close to
breakeven (-1.26/trade). With the full dataset, it's clearly negative
too (-3.16/trade, -835.07 total over 264 trades). The apparent
near-breakeven bull performance in Section 16 did not hold up as more
bull-regime data arrived -- worth remembering as a general lesson about
reading too much into a regime bucket before it has enough trades in
it, not just specific to this strategy.

**Calendar-quarter breakdown (11 quarters, Q1 2024 - Q3 2026):** 3 of
11 quarters positive (2024-Q1, 2024-Q3, 2025-Q2, all modestly so), 8 of
11 negative, several materially so (2024-Q2: -1122.73, 2025-Q1: -812.84,
2025-Q4: -530.73). No visible regime-of-time pattern (early vs. late,
2024 vs. 2025-2026) -- the losses are spread across the whole window,
not concentrated in one period that changing the date range would fix.

**Verdict, now with the complete available dataset and 610 closed
trades:** negative expectancy, confirmed across every regime bucket and
the large majority of calendar quarters. This is the strongest and
final word this rule-based reference engine can offer on Strategy V1's
literal rules: **they do not have a demonstrable edge on real BTC data
across two and a half years spanning multiple bull runs, drawdowns, and
consolidation periods.** Section 4's rules should not be pointed at
real Claude API calls without revision on the strength of this result
alone.

The open question this phase exists to answer remains open: whether
genuine Claude judgment over the same data, same costs, same risk
controls does better, the same, or worse than this mechanical floor.
That comparison still requires running with `--engine claude` in an
environment with network access and an Anthropic API key -- see
Section 14.
