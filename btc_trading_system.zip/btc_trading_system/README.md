# BTC Trading System — Scaffold (Pre-Margex)

A modular BTC trading system where Claude acts as the analysis/decision
component and deterministic Python code handles validation, risk
management, execution, and persistence.

**Current status: no exchange is connected.** Margex's actual API
documentation has not been verified yet (see project notes), so this
scaffold is built entirely around an abstract `ExchangeAdapter`
interface with two working stand-ins — `MockExchangeAdapter` (simulated
live feed) and `ReplayExchangeAdapter` (historical replay). A
`MargexExchangeAdapter` will be added once the real API is confirmed;
until then, live trading is **structurally impossible** — see
[Why live trading can't happen yet](#why-live-trading-cant-happen-yet).

## Quick start

```bash
# Run the full test suite (stdlib unittest, zero third-party dependencies)
PYTHONPATH=src python3 -m unittest discover -s tests -v

# Run the end-to-end demo (paper trading + backtest against synthetic data)
PYTHONPATH=src python3 examples/run_paper_trading_demo.py
```

No `pip install` is required to run any of this — every module uses
only the Python standard library (including `sqlite3` for persistence).
`numpy` is available in some environments but deliberately unused, so
the codebase has zero third-party runtime dependencies.

## The flow

```
market data -> features -> Claude decision -> validation -> risk engine
            -> approved order -> execution engine -> exchange adapter
                                                    -> position/order state
                                                    -> persistence (every step)
```

This exact flow is implemented once, in `TradingPipeline.process_tick()`
(`src/trading_system/pipeline.py`), and reused identically by paper
trading and backtesting — they differ only in where the `MarketSnapshot`
comes from (live-like random walk vs. fixed historical replay).

## Module map

| Module | Responsibility |
|---|---|
| `core/` | Exchange-agnostic enums, dataclasses (`MarketSnapshot`, `Order`, `Position`, ...), exceptions |
| `exchange/` | `ExchangeAdapter` interface; `MockExchangeAdapter` and `ReplayExchangeAdapter`; shared order-matching/position simulation |
| `features/` | Pure, dependency-free `FeatureEngine` (SMA/EMA/RSI/ATR/realized vol/momentum/book imbalance) |
| `decision/` | `TradeDecision` schema + lenient parsing, `ClaudeDecisionEngine` (network-free, DI-based) + `MockDecisionEngine`, `DecisionValidator` |
| `risk/` | `RiskLimits` config, `RiskEngine` — the final authority before execution |
| `execution/` | `ExecutionEngine` — the only component allowed to call `place_order`/`cancel_order` |
| `state/` | `PositionOrderManager` — local position/order tracking + exchange reconciliation |
| `persistence/` | `EventStore` — append-only SQLite log of every snapshot/decision/order/fill/position/P&L event |
| `monitoring/` | `HealthMonitor` — stale-data detection, API-failure circuit breaker, emergency shutdown |
| `paper_trading/` | `PaperTradingEngine` — runs the pipeline against a simulated live feed |
| `backtesting/` | `BacktestEngine` — replays fixed historical candles through the same pipeline |
| `pipeline.py` | `TradingPipeline` (the flow above) and `TradingSystem` (top-level bootstrap + the LIVE-mode hard gate) |

## Key safety properties, and where they're enforced

- **Claude never sets position size.** `TradeDecision` (the schema
  Claude's output is parsed into) has no size field at all —
  `RiskEngine.evaluate()` computes size independently from account
  equity, stop distance, and `RiskLimits`. See
  `test_risk_engine.py::test_claude_cannot_set_position_size`.
- **Malformed/contradictory decisions never reach the risk engine.**
  `DecisionValidator` checks structural validity (required fields,
  confidence range, SL/TP on the correct side of entry, entry price
  sanity vs. current market price) before anything is evaluated for
  risk. See `test_pipeline_end_to_end.py::test_malformed_decision_never_reaches_risk_engine`.
- **The risk engine is the final authority.** `ExecutionEngine` only
  ever receives a `RiskApprovedOrder`, never a raw `TradeDecision`.
  There is no code path from Claude's output straight to
  `exchange.place_order()`.
- **Duplicate-order protection** is enforced twice: `ExecutionEngine`
  tracks executed `decision_id`s locally, and `OrderRequest.client_order_id`
  is deterministic per decision, so even a naive exchange with its own
  idempotency would reject a resubmission.
- **Position/order reconciliation** (`PositionOrderManager.reconcile()`)
  never silently trusts either local or exchange state — it surfaces
  discrepancies for a human/policy decision instead of auto-correcting.
- **No lookahead in backtests.** `ReplayExchangeAdapter.get_market_snapshot()`
  only ever exposes candles up to and including the current cursor.
  See `test_backtesting.py::test_no_lookahead_snapshot_only_contains_past_candles`.
- **Emergency shutdown and daily/consecutive-loss circuit breakers**
  live in `RiskEngine`, fed by realized P/L (`record_realized_pnl`),
  and in `HealthMonitor`, fed by exchange API failures — both are
  checked before any new decision is evaluated.

## Why live trading can't happen yet

`TradingSystem.__init__` (in `pipeline.py`) is the single choke point
for `SystemMode`:

```python
if mode == SystemMode.LIVE:
    if not isinstance(pipeline.exchange, LiveExchangeAdapter):
        raise RuntimeError(...)
    if not enable_live_trading:
        raise RuntimeError(...)
```

`LiveExchangeAdapter` is a marker base class. **Nothing in this
codebase subclasses it.** `MockExchangeAdapter` and
`ReplayExchangeAdapter` both subclass `SimulatedExchangeAdapter`
instead. That means `SystemMode.LIVE` cannot currently be reached by
any real component — not because of a flag that could be flipped by
mistake, but because the class that would need to exist doesn't. See
`test_live_mode_gate.py` for the full set of gate behaviors (including
proof that even a hypothetical live-marked adapter still requires the
explicit `enable_live_trading=True` flag).

## Wiring in the real Claude API (later)

`ClaudeDecisionEngine` (`decision/claude_interface.py`) takes an
injected `llm_call_fn: Callable[[str], str]` rather than importing the
Anthropic SDK directly:

```python
def call_claude(prompt: str) -> str:
    response = anthropic_client.messages.create(
        model="claude-sonnet-5",
        max_tokens=1000,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text

engine = ClaudeDecisionEngine(llm_call_fn=call_claude)
```

Until `llm_call_fn` is provided, calling `.decide()` raises
`DecisionEngineError` deliberately — there's no way to accidentally run
paper/live trading against a decision engine that isn't actually wired
to anything.

## Wiring in Margex (once the API is verified)

1. Write `exchange/margex_exchange.py` implementing `ExchangeAdapter`
   (or `LiveExchangeAdapter`, once you intend to go live), translating
   Margex's actual endpoints/response shapes into the normalized models
   in `core/models.py`.
2. Everything above the exchange layer — features, decision engine,
   validator, risk engine, execution engine, position manager,
   persistence, paper trading, backtesting — needs zero changes,
   because none of it has ever depended on exchange-specific details.
3. Run paper trading against the real Margex market data feed (via the
   new adapter, still a `SimulatedExchangeAdapter`-style wrapper if you
   want order placement mocked, or a real adapter with order placement
   disabled) before ever enabling `SystemMode.LIVE`.

## Strategy V1: the first concrete trading strategy

`docs/strategy_v1.md` is the full specification (decision frequency,
exact Claude inputs, entry/exit/holding-period/risk-reward rules, and
the fees/spread/slippage/funding cost model). The implementation lives
in `src/trading_system/strategy/`:

| File | Purpose |
|---|---|
| `v1_config.py` | The spec's numbers, as objects: `RiskLimits`, `FeatureEngine` config, `DecisionValidator` config, `CostModel`, prompt addendum |
| `reference_engine.py` | `RuleBasedReferenceDecisionEngine` — a deterministic code implementation of the spec's rules, used because this sandbox can't call the real Claude API. **Not Claude.** |
| `holding_period.py` | `HoldingPeriodPolicy` — code-enforced max position age, independent of any decision engine |

Run the backtest:

```bash
PYTHONPATH=src python3 experiments/generate_synthetic_data.py   # only needed once
PYTHONPATH=src python3 experiments/backtest_strategy_v1.py
```

**First result** (rule-based reference engine, synthetic data):
**negative expectancy (-21.31% after costs, -15.31% even at zero
cost)**. Full breakdown and honest caveats in `docs/strategy_v1.md`
Section 15 — the short version is that the mechanical rules, applied
literally, don't show a real edge on this dataset, and costs make an
already-weak result somewhat worse rather than being the main cause.

To test genuine Claude decision-making (requires network + an
Anthropic API key, neither available in this sandbox):

```bash
export ANTHROPIC_API_KEY=...
pip install anthropic
PYTHONPATH=src python3 experiments/backtest_strategy_v1.py --engine claude --data path/to/real_data.csv
```

The `--data` flag also lets you swap in real historical OHLCV once you
have it — `data/btc_4h_synthetic.csv` is explicitly synthetic (see the
warning printed by the backtest and the generator script's docstring)
and should not be treated as evidence about real BTC behavior.

## What this scaffold deliberately does NOT do

- No real network calls anywhere (no exchange, no Claude API, no
  external data source). Everything is either stdlib or explicitly
  injected/mocked.
- No claim that the simulated matching engine, liquidation formula, or
  fee model matches Margex's real behavior — see the docstring at the
  top of `exchange/simulated_matching.py` for the explicit list of
  simplifications.
- No semantic contradiction detection in `DecisionValidator` (e.g.
  "the reasoning text sounds bearish but the action is LONG") — only
  structural/numerical validity is checked by code. See the module
  docstring for why that's a deliberate boundary.
