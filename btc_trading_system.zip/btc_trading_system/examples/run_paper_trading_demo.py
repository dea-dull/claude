"""
Runnable demo: end-to-end paper trading AND backtesting against the
mocked exchange, using MockDecisionEngine instead of a real Claude call.

This proves the whole pipeline works together:
  market data -> features -> decision -> validation -> risk -> execution
  -> position/order state -> persistence

Run it with:
    PYTHONPATH=src python3 examples/run_paper_trading_demo.py

Nothing here talks to Margex, and nothing here can: MockExchangeAdapter
and ReplayExchangeAdapter are SimulatedExchangeAdapters, and
TradingSystem refuses to start in SystemMode.LIVE without a real
LiveExchangeAdapter (see trading_system/pipeline.py).
"""

import math

from trading_system.backtesting.engine import BacktestEngine
from trading_system.core.models import Candle
from trading_system.decision.claude_interface import MockDecisionEngine
from trading_system.exchange.mock_exchange import MockExchangeAdapter, ReplayExchangeAdapter
from trading_system.paper_trading.engine import PaperTradingEngine
from trading_system.persistence.db import EventStore
from trading_system.pipeline import TradingPipeline
from trading_system.risk.config import RiskLimits
from trading_system.risk.engine import RiskEngine

SYMBOL = "BTCUSDT"


def run_paper_trading_demo():
    print("=" * 70)
    print("PAPER TRADING DEMO (simulated live feed, MockDecisionEngine)")
    print("=" * 70)

    exchange = MockExchangeAdapter(
        symbol=SYMBOL, starting_price=60_000.0, starting_balance=10_000.0,
        volatility_bps_per_tick=25.0, seed=2026,
    )
    event_store = EventStore(":memory:")
    risk_engine = RiskEngine(
        RiskLimits(
            max_position_size_usd=3_000.0,
            max_leverage=3.0,
            risk_per_trade_pct=0.01,
            max_loss_per_trade_usd=150.0,
            max_daily_loss_usd=400.0,
            max_concurrent_positions=1,
            min_confidence_to_trade=0.5,
        ),
        clock=exchange.clock,  # IMPORTANT: share the exchange's clock, see
        # docs/strategy_v1.md Section 15 correction notice for why.
    )
    pipeline = TradingPipeline(
        exchange=exchange,
        decision_engine=MockDecisionEngine(seed=42),
        event_store=event_store,
        risk_engine=risk_engine,
    )
    paper = PaperTradingEngine(pipeline, symbol=SYMBOL)

    summary = paper.run(num_ticks=500, keep_results=False)

    print(f"ticks run:                 {summary.ticks_run}")
    print(f"decisions made:            {summary.decisions_made}")
    print(f"trades executed:           {summary.trades_executed}")
    print(f"rejected by validation:    {summary.trades_rejected_by_validation}")
    print(f"rejected by risk engine:   {summary.trades_rejected_by_risk}")
    print(f"total realized P/L (sim):  {summary.total_realized_pnl:.2f} USDT")
    print(f"events logged:             {event_store.count_events()}")
    print()


def synthetic_historical_candles(n=400, start_price=58_000.0, timeframe=3600):
    """Stand-in for a real historical BTC dataset. Once you have actual
    OHLCV history (from wherever you source it -- NOT from an unverified
    Margex endpoint), load it into a list[Candle] the same shape as this
    and pass it to ReplayExchangeAdapter instead."""
    candles = []
    price = start_price
    for i in range(n):
        price = start_price * (1 + 0.08 * math.sin(i / 20.0)) + i * 5.0
        o = price * 0.998
        c = price
        candles.append(
            Candle(
                timestamp=float(i * timeframe),
                open=o,
                high=max(o, c) * 1.002,
                low=min(o, c) * 0.998,
                close=c,
                volume=25.0,
                timeframe_seconds=timeframe,
            )
        )
    return candles


def run_backtest_demo():
    print("=" * 70)
    print("BACKTEST DEMO (synthetic historical candles, MockDecisionEngine)")
    print("=" * 70)

    candles = synthetic_historical_candles()
    exchange = ReplayExchangeAdapter(symbol=SYMBOL, candles=candles, starting_balance=10_000.0)
    event_store = EventStore(":memory:")
    risk_engine = RiskEngine(
        RiskLimits(
            max_position_size_usd=3_000.0,
            max_leverage=3.0,
            risk_per_trade_pct=0.01,
            max_loss_per_trade_usd=150.0,
            max_daily_loss_usd=1_000.0,
            max_concurrent_positions=1,
            min_confidence_to_trade=0.5,
        ),
        clock=exchange.clock,
    )
    pipeline = TradingPipeline(
        exchange=exchange,
        decision_engine=MockDecisionEngine(seed=7),
        event_store=event_store,
        risk_engine=risk_engine,
    )
    backtest = BacktestEngine(pipeline, symbol=SYMBOL, starting_balance=10_000.0)
    summary = backtest.run(keep_results=False)

    print(f"candles processed:         {summary.candles_processed}")
    print(f"decisions made:            {summary.decisions_made}")
    print(f"trades executed:           {summary.trades_executed}")
    print(f"rejected by validation:    {summary.trades_rejected_by_validation}")
    print(f"rejected by risk engine:   {summary.trades_rejected_by_risk}")
    print(f"wins / losses:             {summary.num_wins} / {summary.num_losses}")
    print(f"win rate:                  {summary.win_rate}")
    print(f"avg R multiple:            {summary.avg_r_multiple}")
    print(f"max drawdown:              {summary.max_drawdown:.2f} USDT")
    print(f"starting -> ending equity: {summary.starting_equity:.2f} -> {summary.ending_equity:.2f} USDT")
    print()


if __name__ == "__main__":
    run_paper_trading_demo()
    run_backtest_demo()
