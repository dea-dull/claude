import math
import unittest

from trading_system.backtesting.engine import BacktestEngine
from trading_system.core.models import Candle
from trading_system.decision.claude_interface import MockDecisionEngine
from trading_system.exchange.mock_exchange import ReplayExchangeAdapter
from trading_system.persistence.db import EventStore
from trading_system.pipeline import TradingPipeline
from trading_system.risk.config import RiskLimits
from trading_system.risk.engine import RiskEngine


def synthetic_candles(n=300, start_price=60_000.0, timeframe=60):
    """A gentle sine-wave-plus-drift series -- enough structure to
    produce both oversold and overbought RSI readings so MockDecisionEngine
    actually triggers LONG/SHORT decisions during the backtest."""
    candles = []
    price = start_price
    for i in range(n):
        price = start_price * (1 + 0.05 * math.sin(i / 15.0)) + i * 2.0
        o = price * 0.999
        c = price
        candles.append(
            Candle(
                timestamp=float(i * timeframe),
                open=o,
                high=max(o, c) * 1.001,
                low=min(o, c) * 0.999,
                close=c,
                volume=10.0,
                timeframe_seconds=timeframe,
            )
        )
    return candles


class TestBacktestEngine(unittest.TestCase):
    def setUp(self):
        self.candles = synthetic_candles()
        self.exchange = ReplayExchangeAdapter(symbol="BTCUSDT", candles=self.candles, starting_balance=10_000.0)
        self.event_store = EventStore(":memory:")
        self.risk_engine = RiskEngine(RiskLimits(min_confidence_to_trade=0.5, max_concurrent_positions=1))
        self.pipeline = TradingPipeline(
            exchange=self.exchange,
            decision_engine=MockDecisionEngine(),
            event_store=self.event_store,
            risk_engine=self.risk_engine,
        )
        self.backtest = BacktestEngine(self.pipeline, symbol="BTCUSDT", starting_balance=10_000.0)

    def test_run_processes_all_candles_with_no_lookahead(self):
        summary = self.backtest.run()
        self.assertEqual(summary.candles_processed, len(self.candles) - 1)
        self.assertEqual(summary.decisions_made, len(self.candles) - 1)

    def test_summary_produces_equity_curve_and_drawdown(self):
        summary = self.backtest.run()
        self.assertGreater(len(summary.equity_curve), 0)
        self.assertGreaterEqual(summary.max_drawdown, 0.0)
        self.assertAlmostEqual(summary.starting_equity, 10_000.0)

    def test_win_rate_and_r_multiples_consistent_with_trade_count(self):
        summary = self.backtest.run()
        self.assertEqual(summary.num_wins + summary.num_losses, len(summary.trades))
        if summary.trades:
            self.assertIsNotNone(summary.win_rate)
            self.assertIsNotNone(summary.avg_r_multiple)
        else:
            self.assertIsNone(summary.win_rate)

    def test_no_lookahead_snapshot_only_contains_past_candles(self):
        # Directly verify the replay adapter never exposes future candles.
        while not self.exchange.finished:
            snap_before = self.exchange.get_market_snapshot("BTCUSDT")
            max_ts_before = max(c.timestamp for c in snap_before.recent_candles)
            self.exchange.advance()
            snap_after = self.exchange.get_market_snapshot("BTCUSDT")
            for c in snap_after.recent_candles:
                self.assertLessEqual(c.timestamp, snap_after.timestamp)

    def test_rejects_non_replay_adapter(self):
        from trading_system.exchange.mock_exchange import MockExchangeAdapter

        mock = MockExchangeAdapter()
        pipeline = TradingPipeline(
            exchange=mock,
            decision_engine=MockDecisionEngine(),
            event_store=EventStore(":memory:"),
            risk_engine=RiskEngine(RiskLimits()),
        )
        with self.assertRaises(TypeError):
            BacktestEngine(pipeline, symbol="BTCUSDT")


if __name__ == "__main__":
    unittest.main()
