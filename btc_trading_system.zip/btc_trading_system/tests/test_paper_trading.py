import unittest

from trading_system.decision.claude_interface import MockDecisionEngine
from trading_system.exchange.mock_exchange import MockExchangeAdapter
from trading_system.paper_trading.engine import PaperTradingEngine
from trading_system.persistence.db import EventStore
from trading_system.pipeline import TradingPipeline
from trading_system.risk.config import RiskLimits
from trading_system.risk.engine import RiskEngine


class TestPaperTradingEngine(unittest.TestCase):
    def test_run_produces_summary_and_logs_events(self):
        exchange = MockExchangeAdapter(starting_price=60_000.0, seed=123, volatility_bps_per_tick=40.0)
        event_store = EventStore(":memory:")
        risk_engine = RiskEngine(RiskLimits(min_confidence_to_trade=0.5, max_concurrent_positions=1))
        pipeline = TradingPipeline(
            exchange=exchange,
            decision_engine=MockDecisionEngine(seed=3),
            event_store=event_store,
            risk_engine=risk_engine,
        )
        paper = PaperTradingEngine(pipeline, symbol="BTCUSDT")

        summary = paper.run(num_ticks=150)

        self.assertEqual(summary.ticks_run, 150)
        self.assertEqual(summary.decisions_made, 150)
        self.assertEqual(
            summary.decisions_made,
            summary.trades_executed + summary.trades_rejected_by_validation + summary.trades_rejected_by_risk
            + sum(1 for r in summary.step_results if r.error is None and r.execution_result is None),
        )
        # Every tick's snapshot should be logged.
        self.assertGreaterEqual(event_store.count_events("MARKET_SNAPSHOT"), 150)

    def test_realized_pnl_feeds_back_into_risk_engine_daily_pnl(self):
        exchange = MockExchangeAdapter(starting_price=60_000.0, seed=7, volatility_bps_per_tick=80.0)
        event_store = EventStore(":memory:")
        risk_engine = RiskEngine(RiskLimits(min_confidence_to_trade=0.4, max_concurrent_positions=1))
        pipeline = TradingPipeline(
            exchange=exchange,
            decision_engine=MockDecisionEngine(seed=11),
            event_store=event_store,
            risk_engine=risk_engine,
        )
        paper = PaperTradingEngine(pipeline, symbol="BTCUSDT")
        paper.run(num_ticks=300)

        # Not asserting a specific sign/value (random walk), just that the
        # feedback loop actually ran and daily_pnl reflects *something*
        # once trades have opened and closed.
        if paper._last_cum_realized_pnl != 0:
            self.assertAlmostEqual(risk_engine.daily_pnl, paper._last_cum_realized_pnl, places=6)

    def test_rejects_non_mock_adapter(self):
        from trading_system.exchange.mock_exchange import ReplayExchangeAdapter
        from trading_system.core.models import Candle

        candles = [Candle(timestamp=float(i), open=100, high=101, low=99, close=100, volume=1) for i in range(5)]
        replay = ReplayExchangeAdapter(symbol="BTCUSDT", candles=candles)
        event_store = EventStore(":memory:")
        risk_engine = RiskEngine(RiskLimits())
        pipeline = TradingPipeline(
            exchange=replay,
            decision_engine=MockDecisionEngine(),
            event_store=event_store,
            risk_engine=risk_engine,
        )
        with self.assertRaises(TypeError):
            PaperTradingEngine(pipeline, symbol="BTCUSDT")


if __name__ == "__main__":
    unittest.main()
