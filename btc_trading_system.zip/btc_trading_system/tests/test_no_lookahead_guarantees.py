"""
Anti-lookahead guarantee tests.

These are the tests explicitly requested for the Claude Baseline
experiment: automated, mechanical proof that nothing in the pipeline
can hand Claude (or any decision engine) information from after the
decision timestamp. Each test targets one specific place a lookahead
bug could hide:

  1. ReplayExchangeAdapter's snapshot/candle history never includes a
     future candle.
  2. The prompt payload built for the decision engine never contains a
     timestamp beyond the snapshot's own timestamp.
  3. FundingRateSeries.rate_at() never returns a rate from a row dated
     after the query.
  4. Regime classification (frozen for this experiment) depends only on
     candles up to and including the query index -- already covered in
     tests/test_regime.py, referenced here for completeness.
  5. An end-to-end run: replaying a full dataset and inspecting every
     single snapshot/prompt pair the pipeline produces, not just one
     hand-picked tick.
"""

from __future__ import annotations

import json
import unittest

from trading_system.backtesting.funding_loader import FundingRateSeries
from trading_system.core.models import Candle
from trading_system.decision.claude_interface import build_snapshot_payload
from trading_system.exchange.mock_exchange import ReplayExchangeAdapter
from trading_system.features.engine import FeatureEngine


def make_candles(n, start_price=50_000.0, drift=0.001, timeframe_seconds=14400):
    candles = []
    price = start_price
    for i in range(n):
        o = price
        price = price * (1 + drift)
        candles.append(
            Candle(
                timestamp=float(i * timeframe_seconds),
                open=o, high=max(o, price) * 1.001, low=min(o, price) * 0.999,
                close=price, volume=10.0, timeframe_seconds=timeframe_seconds,
            )
        )
    return candles


class TestReplayAdapterNoLookahead(unittest.TestCase):
    def test_snapshot_never_contains_future_candles(self):
        candles = make_candles(200)
        exchange = ReplayExchangeAdapter(symbol="BTCUSDT", candles=candles)
        while not exchange.finished:
            exchange.advance()
            snap = exchange.get_market_snapshot("BTCUSDT")
            for c in snap.recent_candles:
                self.assertLessEqual(
                    c.timestamp, snap.timestamp,
                    f"snapshot at t={snap.timestamp} exposed a candle from t={c.timestamp}",
                )

    def test_recent_candles_history_matches_cursor_position_exactly(self):
        candles = make_candles(150)
        exchange = ReplayExchangeAdapter(symbol="BTCUSDT", candles=candles)
        expected_cursor = 0
        while not exchange.finished:
            exchange.advance()
            expected_cursor += 1
            history = exchange.get_recent_candles("BTCUSDT", timeframe_seconds=14400, limit=1000)
            self.assertEqual(history[-1].timestamp, candles[expected_cursor].timestamp)
            self.assertLessEqual(len(history), expected_cursor + 1)

    def test_last_price_matches_current_cursor_not_a_future_bar(self):
        candles = make_candles(100)
        exchange = ReplayExchangeAdapter(symbol="BTCUSDT", candles=candles)
        cursor = 0
        while not exchange.finished:
            exchange.advance()
            cursor += 1
            snap = exchange.get_market_snapshot("BTCUSDT")
            self.assertEqual(snap.last_price, candles[cursor].close)


class TestPromptPayloadNoLookahead(unittest.TestCase):
    def test_payload_contains_no_timestamp_beyond_snapshot(self):
        candles = make_candles(200)
        exchange = ReplayExchangeAdapter(symbol="BTCUSDT", candles=candles)
        engine = FeatureEngine()
        while not exchange.finished:
            exchange.advance()
            snap = exchange.get_market_snapshot("BTCUSDT")
            features = engine.compute(snap)
            payload = build_snapshot_payload(snap, features)
            serialized = json.dumps(payload, default=str)

            for candle_row in payload["recent_candles"]:
                self.assertLessEqual(candle_row["t"], snap.timestamp)
            self.assertEqual(payload["timestamp"], snap.timestamp)
            self.assertNotIn(f'"t": {snap.timestamp + 14400}', serialized)

    def test_payload_is_a_pure_function_of_the_snapshot_object(self):
        candles = make_candles(60)
        exchange = ReplayExchangeAdapter(symbol="BTCUSDT", candles=candles)
        exchange.advance()
        snap = exchange.get_market_snapshot("BTCUSDT")
        features = FeatureEngine().compute(snap)
        payload_1 = build_snapshot_payload(snap, features)
        payload_2 = build_snapshot_payload(snap, features)
        self.assertEqual(payload_1, payload_2)


class TestFundingSeriesNoLookahead(unittest.TestCase):
    def test_rate_at_never_returns_future_row(self):
        series = FundingRateSeries([(t, float(t)) for t in range(0, 100_000, 1000)])
        for query_ts in range(0, 100_000, 137):  # odd stride, hits between rows
            rate = series.rate_at(query_ts)
            if rate is not None:
                self.assertLessEqual(rate, query_ts)

    def test_full_backtest_never_queries_funding_ahead_of_current_bar(self):
        candles = make_candles(100, timeframe_seconds=14400)
        funding_rows = [(c.timestamp, 0.0001 * i) for i, c in enumerate(candles)]
        funding_rows += [(candles[-1].timestamp + 999_999, 999.0)]  # obviously-future poison value
        series = FundingRateSeries(funding_rows)

        exchange = ReplayExchangeAdapter(symbol="BTCUSDT", candles=candles, funding_series=series)
        while not exchange.finished:
            exchange.advance()
            snap = exchange.get_market_snapshot("BTCUSDT")
            if snap.funding is not None:
                self.assertNotEqual(snap.funding.rate, 999.0)
                self.assertLessEqual(snap.funding.timestamp, snap.timestamp)


class TestEndToEndLookaheadAudit(unittest.TestCase):
    def test_every_tick_in_a_full_run_passes_the_no_lookahead_check(self):
        candles = make_candles(300, drift=0.0005)
        exchange = ReplayExchangeAdapter(symbol="BTCUSDT", candles=candles)
        engine = FeatureEngine()
        violations = []

        while not exchange.finished:
            exchange.advance()
            snap = exchange.get_market_snapshot("BTCUSDT")
            features = engine.compute(snap)
            payload = build_snapshot_payload(snap, features)

            if any(row["t"] > snap.timestamp for row in payload["recent_candles"]):
                violations.append(snap.timestamp)
            if any(c.timestamp > snap.timestamp for c in snap.recent_candles):
                violations.append(snap.timestamp)

        self.assertEqual(violations, [], f"lookahead detected at timestamps: {violations}")


if __name__ == "__main__":
    unittest.main()
