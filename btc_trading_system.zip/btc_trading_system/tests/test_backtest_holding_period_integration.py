import unittest

from trading_system.backtesting.engine import BacktestEngine
from trading_system.core.models import Candle
from trading_system.decision.schema import parse_decision
from trading_system.exchange.mock_exchange import ReplayExchangeAdapter
from trading_system.persistence.db import EventStore
from trading_system.pipeline import TradingPipeline
from trading_system.risk.config import RiskLimits
from trading_system.risk.engine import RiskEngine
from trading_system.strategy.holding_period import HoldingPeriodPolicy


class OnceThenNoTrade:
    def __init__(self, fixed):
        self.fixed = fixed
        self.used = False

    def decide(self, snapshot, features):
        if not self.used:
            self.used = True
            return parse_decision(self.fixed, snapshot_timestamp=snapshot.timestamp)
        return parse_decision(
            {"action": "NO_TRADE", "confidence": 0.1, "reason": "done"},
            snapshot_timestamp=snapshot.timestamp,
        )


class TestBacktestHoldingPeriodIntegration(unittest.TestCase):
    def test_position_force_closed_within_backtest_loop(self):
        # Flat price series -- SL/TP will never trigger on their own, so
        # any closed position MUST be due to the holding-period policy.
        candles = [
            Candle(timestamp=float(i * 3600), open=100.0, high=100.5, low=99.5, close=100.0, volume=10.0)
            for i in range(50)
        ]
        exchange = ReplayExchangeAdapter(symbol="BTCUSDT", candles=candles, starting_balance=10_000.0)
        event_store = EventStore(":memory:")
        risk_engine = RiskEngine(RiskLimits(min_confidence_to_trade=0.0, max_concurrent_positions=1))

        fixed = {
            "action": "LONG", "confidence": 0.9, "entry": {"type": "MARKET"},
            "stop_loss": 50.0, "take_profit": 999.0,
            "time_horizon": "1h", "reason": "forced test entry",
        }

        pipeline = TradingPipeline(
            exchange=exchange,
            decision_engine=OnceThenNoTrade(fixed),
            event_store=event_store,
            risk_engine=risk_engine,
        )
        policy = HoldingPeriodPolicy(max_holding_seconds=3 * 3600)  # 3 hours
        backtest = BacktestEngine(pipeline, symbol="BTCUSDT", holding_period_policy=policy)
        backtest.run()

        events = event_store.get_events(event_type="HOLDING_PERIOD_FORCE_CLOSE")
        self.assertEqual(len(events), 1)
        self.assertEqual(exchange.get_positions(), [])


if __name__ == "__main__":
    unittest.main()
