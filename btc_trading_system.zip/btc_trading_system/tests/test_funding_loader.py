import os
import tempfile
import unittest

from trading_system.backtesting.funding_loader import FundingRateSeries, load_funding_csv


class TestFundingRateSeries(unittest.TestCase):
    def test_rate_at_exact_timestamp(self):
        series = FundingRateSeries([(100.0, 0.0001), (200.0, 0.0002), (300.0, 0.0003)])
        self.assertEqual(series.rate_at(200.0), 0.0002)

    def test_rate_at_returns_most_recent_prior_row(self):
        series = FundingRateSeries([(100.0, 0.0001), (200.0, 0.0002), (300.0, 0.0003)])
        self.assertEqual(series.rate_at(250.0), 0.0002)

    def test_rate_at_before_series_start_returns_none(self):
        series = FundingRateSeries([(100.0, 0.0001)])
        self.assertIsNone(series.rate_at(50.0))

    def test_never_returns_future_rate(self):
        series = FundingRateSeries([(100.0, 0.0001), (200.0, 0.9999)])
        self.assertEqual(series.rate_at(199.9), 0.0001)
        self.assertNotEqual(series.rate_at(199.9), 0.9999)

    def test_handles_unsorted_input(self):
        series = FundingRateSeries([(300.0, 0.0003), (100.0, 0.0001), (200.0, 0.0002)])
        self.assertEqual(series.rate_at(150.0), 0.0001)
        self.assertEqual(series.rate_at(250.0), 0.0002)


class TestLoadFundingCsv(unittest.TestCase):
    def _write(self, content: str) -> str:
        path = tempfile.mktemp(suffix=".csv")
        with open(path, "w") as f:
            f.write(content)
        self.addCleanup(lambda: os.path.exists(path) and os.remove(path))
        return path

    def test_loads_valid_csv(self):
        path = self._write("timestamp,funding_rate\n1000,0.0001\n2000,0.0002\n")
        series = load_funding_csv(path)
        self.assertEqual(len(series), 2)
        self.assertEqual(series.rate_at(1500), 0.0001)

    def test_missing_columns_raises(self):
        path = self._write("timestamp,rate\n1000,0.0001\n")
        with self.assertRaises(ValueError):
            load_funding_csv(path)

    def test_empty_raises(self):
        path = self._write("timestamp,funding_rate\n")
        with self.assertRaises(ValueError):
            load_funding_csv(path)


if __name__ == "__main__":
    unittest.main()
