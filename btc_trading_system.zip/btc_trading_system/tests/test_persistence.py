import unittest

from trading_system.core.models import MarketSnapshot
from trading_system.decision.schema import parse_decision
from trading_system.persistence.db import EventStore


class TestEventStore(unittest.TestCase):
    def setUp(self):
        self.store = EventStore(":memory:")

    def test_log_and_retrieve_snapshot(self):
        snap = MarketSnapshot(symbol="BTCUSDT", timestamp=100.0, last_price=60_000.0)
        self.store.log_snapshot(snap)
        events = self.store.get_events(event_type="MARKET_SNAPSHOT")
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["payload"]["symbol"], "BTCUSDT")
        self.assertEqual(events[0]["payload"]["last_price"], 60_000.0)

    def test_log_decision_round_trips_enum_as_plain_string(self):
        snap = MarketSnapshot(symbol="BTCUSDT", timestamp=100.0, last_price=60_000.0)
        raw = {
            "action": "LONG", "confidence": 0.6, "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0, "take_profit": 62_000.0, "time_horizon": "1h",
            "reason": "test",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        self.store.log_decision(decision)
        events = self.store.get_events(event_type="DECISION", correlation_id=decision.decision_id)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["payload"]["action"], "LONG")

    def test_correlation_id_links_events(self):
        snap = MarketSnapshot(symbol="BTCUSDT", timestamp=200.0, last_price=61_000.0)
        raw = {"action": "NO_TRADE", "confidence": 0.1, "reason": "nothing"}
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        self.store.log_decision(decision)
        self.store.log_event("CUSTOM_NOTE", {"note": "hi"}, correlation_id=decision.decision_id)
        events = self.store.get_events(correlation_id=decision.decision_id)
        self.assertEqual(len(events), 2)
        types = {e["event_type"] for e in events}
        self.assertEqual(types, {"DECISION", "CUSTOM_NOTE"})

    def test_count_events(self):
        for i in range(5):
            self.store.log_event("PING", {"i": i})
        self.assertEqual(self.store.count_events("PING"), 5)
        self.assertEqual(self.store.count_events("NONEXISTENT"), 0)

    def test_since_until_filters(self):
        self.store.log_event("E", {"n": 1}, ts=10.0)
        self.store.log_event("E", {"n": 2}, ts=20.0)
        self.store.log_event("E", {"n": 3}, ts=30.0)
        events = self.store.get_events(event_type="E", since=15.0, until=25.0)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["payload"]["n"], 2)

    def test_persists_to_real_file(self):
        import os
        import tempfile

        path = tempfile.mktemp(suffix=".sqlite3")
        try:
            store = EventStore(path)
            store.log_event("PERSISTED", {"ok": True})
            store.close()

            store2 = EventStore(path)
            events = store2.get_events(event_type="PERSISTED")
            self.assertEqual(len(events), 1)
            store2.close()
        finally:
            if os.path.exists(path):
                os.remove(path)


if __name__ == "__main__":
    unittest.main()
