import unittest

from trading_system.decision.claude_interface import MockDecisionEngine
from trading_system.decision.validator import DecisionValidator
from trading_system.exchange.mock_exchange import MockExchangeAdapter
from trading_system.persistence.db import EventStore
from trading_system.pipeline import TradingPipeline
from trading_system.risk.config import RiskLimits
from trading_system.risk.engine import RiskEngine


class TestPipelineEndToEnd(unittest.TestCase):
    def setUp(self):
        self.exchange = MockExchangeAdapter(starting_price=60_000.0, seed=99, starting_balance=10_000.0)
        self.event_store = EventStore(":memory:")
        self.risk_engine = RiskEngine(RiskLimits(min_confidence_to_trade=0.5))
        self.decision_engine = MockDecisionEngine()
        self.pipeline = TradingPipeline(
            exchange=self.exchange,
            decision_engine=self.decision_engine,
            event_store=self.event_store,
            risk_engine=self.risk_engine,
        )

    def test_process_tick_logs_full_lifecycle(self):
        # Warm up candle history so indicators are computable.
        for _ in range(60):
            self.exchange.tick()

        result = self.pipeline.process_tick("BTCUSDT")

        self.assertIsNotNone(result.snapshot)
        self.assertIsNotNone(result.features)
        self.assertIsNotNone(result.decision)
        self.assertIsNotNone(result.validation)

        # Every stage should have logged something.
        self.assertGreaterEqual(self.event_store.count_events("MARKET_SNAPSHOT"), 1)
        self.assertGreaterEqual(self.event_store.count_events("FEATURES"), 1)
        self.assertGreaterEqual(self.event_store.count_events("DECISION"), 1)
        self.assertGreaterEqual(self.event_store.count_events("VALIDATION"), 1)

    def test_forced_long_decision_flows_through_to_execution(self):
        for _ in range(60):
            self.exchange.tick()

        fixed_engine = MockDecisionEngine(
            fixed_decision={
                "action": "LONG",
                "confidence": 0.9,
                "entry": {"type": "MARKET"},
                "stop_loss": self.exchange.get_market_snapshot("BTCUSDT").last_price * 0.98,
                "take_profit": self.exchange.get_market_snapshot("BTCUSDT").last_price * 1.02,
                "time_horizon": "1h",
                "reason": "forced test decision",
            }
        )
        pipeline = TradingPipeline(
            exchange=self.exchange,
            decision_engine=fixed_engine,
            event_store=self.event_store,
            risk_engine=self.risk_engine,
        )
        result = pipeline.process_tick("BTCUSDT")

        self.assertTrue(result.validation.is_valid, result.validation.errors)
        self.assertIsNotNone(result.risk_evaluation)
        self.assertTrue(result.risk_evaluation.approved, result.risk_evaluation.reasons)
        self.assertIsNotNone(result.execution_result)

        positions = self.exchange.get_positions()
        self.assertEqual(len(positions), 1)
        self.assertGreaterEqual(self.event_store.count_events("ORDER"), 3)  # entry + SL + TP

    def test_low_confidence_decision_never_reaches_execution(self):
        for _ in range(60):
            self.exchange.tick()

        low_conf_engine = MockDecisionEngine(
            fixed_decision={
                "action": "LONG",
                "confidence": 0.1,  # below default min_confidence_to_trade
                "entry": {"type": "MARKET"},
                "stop_loss": 1.0,
                "take_profit": 999999.0,
                "time_horizon": "1h",
                "reason": "low confidence test",
            }
        )
        pipeline = TradingPipeline(
            exchange=self.exchange,
            decision_engine=low_conf_engine,
            event_store=self.event_store,
            risk_engine=self.risk_engine,
        )
        result = pipeline.process_tick("BTCUSDT")
        self.assertIsNone(result.execution_result)
        self.assertIsNotNone(result.risk_evaluation)
        self.assertFalse(result.risk_evaluation.approved)

    def test_malformed_decision_never_reaches_risk_engine(self):
        for _ in range(60):
            self.exchange.tick()

        garbage_engine = MockDecisionEngine(
            fixed_decision={"action": "LONG", "confidence": "not-a-number", "reason": "garbage"}
        )
        pipeline = TradingPipeline(
            exchange=self.exchange,
            decision_engine=garbage_engine,
            event_store=self.event_store,
            risk_engine=self.risk_engine,
        )
        result = pipeline.process_tick("BTCUSDT")
        self.assertFalse(result.validation.is_valid)
        self.assertIsNone(result.risk_evaluation)
        self.assertIsNone(result.execution_result)


if __name__ == "__main__":
    unittest.main()
