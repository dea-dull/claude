"""
Claude Baseline execution-path audit.

These tests exist specifically to answer the question asked before
ever spending a real API call on the Claude Baseline: is the prompt
actually the frozen minimal baseline prompt, with no Strategy V1
trading logic injected anywhere, and is the full prompt/response pair
actually persisted untouched for every decision?

This does NOT call the real Claude API (no network in this
environment) -- it uses a fake llm_call_fn, which is sufficient to
prove everything about the WIRING: what text reaches the "Claude"
call, and what comes back gets persisted exactly. Wiring correctness
does not depend on what a real model would answer.
"""

import unittest

from trading_system.core.models import MarketSnapshot, Candle, OrderBook, OrderBookLevel
from trading_system.decision.claude_interface import ClaudeDecisionEngine
from trading_system.features.engine import FeatureEngine
from trading_system.persistence.db import EventStore
from trading_system.strategy import baseline_config, v1_config

# Phrases that are unique to Strategy V1's prose instructions to Claude
# (v1_config.PROMPT_ADDENDUM) or to its rule-based reference engine
# (strategy/reference_engine.py). None of these describe raw feature
# *data* the way JSON keys like "rsi" or "atr" do -- they are
# instructional/decision-logic language. Their presence in a prompt
# means V1's trading logic leaked in; their absence does not depend on
# whether the underlying feature values happen to be shown (they
# always are, by design -- see baseline_config.py docstring).
V1_INSTRUCTIONAL_PHRASES = [
    "2-of-4",
    "at least two of",
    "recovering from oversold",
    "falling from overbought",
    "trend-continuation",
    "mean-reversion-at-extreme",
    "STRATEGY CONTEXT",
    "condition-counting",
    "0.5x-4x",
    "1.2:1",
    "reward:risk ratio (take_profit distance",
]


def make_snapshot(ts=1_700_000_000.0, price=60_000.0):
    candles = [
        Candle(timestamp=ts - (50 - i) * 14400, open=price, high=price * 1.001,
               low=price * 0.999, close=price, volume=10.0, timeframe_seconds=14400)
        for i in range(50)
    ]
    book = OrderBook(
        timestamp=ts,
        bids=[OrderBookLevel(price=price - 1, size=1.0)],
        asks=[OrderBookLevel(price=price + 1, size=1.0)],
    )
    return MarketSnapshot(symbol="BTCUSDT", timestamp=ts, last_price=price,
                           order_book=book, recent_candles=candles)


class TestBaselinePromptProvenance(unittest.TestCase):
    """Confirms the frozen baseline prompt itself, in isolation, is clean."""

    def test_baseline_prompt_is_not_empty(self):
        self.assertTrue(baseline_config.BASELINE_PROMPT.strip())

    def test_baseline_prompt_contains_no_v1_instructional_language(self):
        text = baseline_config.BASELINE_PROMPT.lower()
        for phrase in V1_INSTRUCTIONAL_PHRASES:
            self.assertNotIn(
                phrase.lower(), text,
                f"BASELINE_PROMPT contains V1-specific instructional phrase: {phrase!r}",
            )

    def test_baseline_prompt_is_not_the_v1_prompt(self):
        self.assertNotEqual(baseline_config.BASELINE_PROMPT, v1_config.PROMPT_ADDENDUM)

    def test_baseline_prompt_states_no_trade_is_normal(self):
        # The one substantive instruction the spec requires.
        self.assertIn("NO_TRADE is a normal", baseline_config.BASELINE_PROMPT)

    def test_baseline_config_does_not_import_v1_prompt_addendum(self):
        # Static check: baseline_config's namespace should not even have
        # a reference to PROMPT_ADDENDUM under any name.
        self.assertFalse(hasattr(baseline_config, "PROMPT_ADDENDUM"))

    def test_baseline_config_only_reexports_approved_system_level_names(self):
        # Whitelist of what's allowed to be shared from v1_config.
        approved = {
            "CANDLE_TIMEFRAME_SECONDS", "COST_MODEL", "DECISION_INTERVAL_SECONDS",
            "FEATURE_ENGINE", "MAX_HOLDING_SECONDS", "SPREAD_BPS", "VALIDATOR",
            "build_risk_limits",
        }
        v1_public_names = {n for n in dir(v1_config) if not n.startswith("_") and n != "annotations"}
        shared_with_baseline = {
            n for n in v1_public_names
            if hasattr(baseline_config, n) and getattr(baseline_config, n) is getattr(v1_config, n)
        }
        unexpected = shared_with_baseline - approved
        self.assertEqual(
            unexpected, set(),
            f"baseline_config shares unapproved v1_config objects: {unexpected}",
        )


class TestBuiltPromptEndToEnd(unittest.TestCase):
    """Confirms the ACTUAL prompt text built by ClaudeDecisionEngine when
    wired exactly as experiments/backtest_claude_baseline.py wires it is
    clean, not just the raw BASELINE_PROMPT string in isolation."""

    def setUp(self):
        self.engine = ClaudeDecisionEngine(
            llm_call_fn=lambda prompt: '{"action": "NO_TRADE", "confidence": 0.1, "reason": "x"}',
            system_prompt_extra=baseline_config.BASELINE_PROMPT,
        )
        self.snapshot = make_snapshot()
        self.features = baseline_config.FEATURE_ENGINE.compute(self.snapshot)

    def test_built_prompt_contains_baseline_prompt_verbatim(self):
        prompt = self.engine.build_prompt(self.snapshot, self.features)
        self.assertIn(baseline_config.BASELINE_PROMPT.strip(), prompt)

    def test_built_prompt_contains_no_v1_instructional_language(self):
        prompt = self.engine.build_prompt(self.snapshot, self.features)
        lowered = prompt.lower()
        for phrase in V1_INSTRUCTIONAL_PHRASES:
            self.assertNotIn(
                phrase.lower(), lowered,
                f"Full built prompt contains V1-specific instructional phrase: {phrase!r}",
            )

    def test_feature_values_are_present_as_data_not_instructions(self):
        # Sanity check the other direction: features like rsi/atr/sma ARE
        # expected to appear, as plain data fields -- their presence is
        # correct, only V1's INSTRUCTIONAL phrasing about them is banned.
        prompt = self.engine.build_prompt(self.snapshot, self.features)
        self.assertIn('"rsi"', prompt)
        self.assertIn('"atr"', prompt)

    def test_this_is_what_the_actual_experiment_script_wires(self):
        # Direct proof the object identity matches what
        # experiments/backtest_claude_baseline.py passes as
        # system_prompt_extra -- not a copy that could drift.
        self.assertIs(self.engine.system_prompt_extra, baseline_config.BASELINE_PROMPT)


class TestExactPersistence(unittest.TestCase):
    """Proves the exact prompt and exact raw response are persisted for
    every decision, untouched -- the specific requirement asked for."""

    def test_raw_prompt_and_raw_response_persisted_exactly(self):
        snapshot = make_snapshot()
        features = baseline_config.FEATURE_ENGINE.compute(snapshot)

        exact_response_text = (
            '{"action": "LONG", "confidence": 0.62, "entry": {"type": "MARKET"}, '
            '"stop_loss": 59000.12345, "take_profit": 61500.6789, '
            '"time_horizon": "8h", "reason": "unique-marker-9f3a: momentum looks constructive"}'
        )
        captured_prompt = {}

        def fake_llm(prompt: str) -> str:
            captured_prompt["value"] = prompt
            return exact_response_text

        engine = ClaudeDecisionEngine(
            llm_call_fn=fake_llm,
            system_prompt_extra=baseline_config.BASELINE_PROMPT,
        )
        decision = engine.decide(snapshot, features)

        store = EventStore(":memory:")
        store.log_decision(decision)
        events = store.get_events(event_type="DECISION", correlation_id=decision.decision_id)
        self.assertEqual(len(events), 1)
        persisted = events[0]["payload"]

        # Exact match, not "contains" -- nothing truncated, nothing reworded.
        self.assertEqual(persisted["raw_prompt"], captured_prompt["value"])
        self.assertEqual(persisted["raw_response"], exact_response_text)
        self.assertIn("unique-marker-9f3a", persisted["raw_response"])
        self.assertIn(baseline_config.BASELINE_PROMPT.strip(), persisted["raw_prompt"])

        # And the parsed structured fields are ALSO persisted alongside
        # the raw pair, not instead of it.
        self.assertEqual(persisted["action"], "LONG")
        self.assertEqual(persisted["stop_loss"], 59000.12345)

    def test_persistence_survives_a_long_realistic_prompt_untruncated(self):
        # Guards against any hidden length limit (e.g. a DB column cap)
        # silently truncating the prompt for a full-size real snapshot.
        big_candles = [
            Candle(timestamp=float(i * 14400), open=100.0, high=101.0, low=99.0,
                   close=100.5, volume=10.0, timeframe_seconds=14400)
            for i in range(200)
        ]
        snapshot = MarketSnapshot(
            symbol="BTCUSDT", timestamp=big_candles[-1].timestamp + 14400,
            last_price=100.5, recent_candles=big_candles,
        )
        features = baseline_config.FEATURE_ENGINE.compute(snapshot)

        def fake_llm(prompt: str) -> str:
            return '{"action": "NO_TRADE", "confidence": 0.1, "reason": "x" * 1}'

        engine = ClaudeDecisionEngine(llm_call_fn=fake_llm, system_prompt_extra=baseline_config.BASELINE_PROMPT)
        decision = engine.decide(snapshot, features)

        store = EventStore(":memory:")
        store.log_decision(decision)
        persisted = store.get_events(event_type="DECISION", correlation_id=decision.decision_id)[0]["payload"]

        self.assertEqual(len(persisted["raw_prompt"]), len(decision.raw_prompt))
        self.assertEqual(persisted["raw_prompt"], decision.raw_prompt)


if __name__ == "__main__":
    unittest.main()


class TestExperimentScriptWiring(unittest.TestCase):
    """Regression guard for the exact bug this audit was requested to
    catch: experiments/backtest_strategy_v1.py's --engine claude path
    was wired to v1_config.PROMPT_ADDENDUM instead of a baseline
    prompt. This test imports the DEDICATED baseline script's engine
    builder directly and confirms its prompt source is
    baseline_config.BASELINE_PROMPT, not v1_config.PROMPT_ADDENDUM."""

    def test_backtest_claude_baseline_script_uses_baseline_prompt(self):
        import importlib
        import os
        import sys

        sys.path.insert(0, "experiments")
        try:
            baseline_script = importlib.import_module("backtest_claude_baseline")
            importlib.reload(baseline_script)
            try:
                import anthropic  # noqa: F401
            except ImportError:
                self.skipTest("anthropic SDK not installed in this environment")

            env_backup = dict(os.environ)
            os.environ["ANTHROPIC_API_KEY"] = "test-key-not-real"
            try:
                constructed = baseline_script.build_claude_engine()
                self.assertIs(constructed.system_prompt_extra, baseline_config.BASELINE_PROMPT)
                self.assertIsNot(constructed.system_prompt_extra, v1_config.PROMPT_ADDENDUM)
            finally:
                os.environ.clear()
                os.environ.update(env_backup)
        finally:
            sys.path.remove("experiments")

    def test_v1_script_claude_path_is_labeled_not_baseline(self):
        """Documents (rather than silently assumes) that
        backtest_strategy_v1.py's own --engine claude path uses V1's
        prompt -- that's a different, legitimate experiment (does
        Claude out-execute the rule engine on V1's OWN logic), but it
        is explicitly NOT the Baseline and must never be mistaken for
        it. If this ever changes, this test should change with it."""
        import importlib
        import sys

        sys.path.insert(0, "experiments")
        try:
            v1_script = importlib.import_module("backtest_strategy_v1")
            importlib.reload(v1_script)
            with open(v1_script.__file__) as f:
                source = f.read()
            self.assertIn("system_prompt_extra=v1_config.PROMPT_ADDENDUM", source)
        finally:
            sys.path.remove("experiments")
