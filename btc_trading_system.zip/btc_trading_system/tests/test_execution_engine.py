import unittest

from trading_system.core.enums import OrderSide, OrderType
from trading_system.core.exceptions import DuplicateOrderError
from trading_system.exchange.mock_exchange import MockExchangeAdapter
from trading_system.execution.engine import ExecutionEngine
from trading_system.risk.engine import RiskApprovedOrder


def make_approved_order(decision_id="dec_1", symbol="BTCUSDT", side=OrderSide.BUY, size=0.01,
                         entry_price=60_000.0, stop_loss=59_000.0, take_profit=62_000.0):
    return RiskApprovedOrder(
        decision_id=decision_id,
        symbol=symbol,
        side=side,
        order_type=OrderType.MARKET,
        size=size,
        leverage=2.0,
        entry_price=entry_price,
        limit_price=None,
        stop_loss=stop_loss,
        take_profit=take_profit,
        risk_amount_usd=10.0,
        notional_usd=size * entry_price,
    )


class TestExecutionEngine(unittest.TestCase):
    def setUp(self):
        self.exchange = MockExchangeAdapter(starting_price=60_000.0, seed=1)
        self.engine = ExecutionEngine(self.exchange)

    def test_execute_places_entry_and_bracket_orders(self):
        approved = make_approved_order()
        result = self.engine.execute(approved)
        self.assertIsNotNone(result.entry_order)
        self.assertIsNotNone(result.stop_loss_order)
        self.assertIsNotNone(result.take_profit_order)
        # entry is a market buy -> filled immediately
        self.assertEqual(result.entry_order.side, OrderSide.BUY)
        # bracket orders are on the opposite side, reduce-only
        self.assertEqual(result.stop_loss_order.side, OrderSide.SELL)
        self.assertEqual(result.take_profit_order.side, OrderSide.SELL)
        self.assertTrue(result.stop_loss_order.reduce_only)
        self.assertTrue(result.take_profit_order.reduce_only)

    def test_duplicate_decision_id_rejected(self):
        approved = make_approved_order(decision_id="dec_dup")
        self.engine.execute(approved)
        with self.assertRaises(DuplicateOrderError):
            self.engine.execute(approved)

    def test_executed_decision_ids_tracked(self):
        approved = make_approved_order(decision_id="dec_track")
        self.engine.execute(approved)
        self.assertIn("dec_track", self.engine.executed_decision_ids)


if __name__ == "__main__":
    unittest.main()
