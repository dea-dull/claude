import unittest

from trading_system.monitoring.health import HealthMonitor


class TestHealthMonitor(unittest.TestCase):
    def test_stale_before_any_snapshot(self):
        clock = [0.0]
        monitor = HealthMonitor(max_data_staleness_seconds=5.0, clock=lambda: clock[0])
        self.assertTrue(monitor.is_data_stale())

    def test_fresh_right_after_snapshot(self):
        clock = [100.0]
        monitor = HealthMonitor(max_data_staleness_seconds=5.0, clock=lambda: clock[0])
        monitor.record_snapshot_received(100.0)
        self.assertFalse(monitor.is_data_stale())

    def test_becomes_stale_after_threshold(self):
        clock = [100.0]
        monitor = HealthMonitor(max_data_staleness_seconds=5.0, clock=lambda: clock[0])
        monitor.record_snapshot_received(100.0)
        clock[0] = 106.0
        self.assertTrue(monitor.is_data_stale())

    def test_consecutive_api_failures_trip_shutdown(self):
        monitor = HealthMonitor(max_consecutive_api_failures=3)
        triggered = []
        monitor.on_emergency_shutdown(lambda reason: triggered.append(reason))
        monitor.record_api_failure()
        monitor.record_api_failure()
        self.assertFalse(monitor.is_shutdown)
        monitor.record_api_failure()
        self.assertTrue(monitor.is_shutdown)
        self.assertEqual(len(triggered), 1)

    def test_api_success_resets_failure_count(self):
        monitor = HealthMonitor(max_consecutive_api_failures=3)
        monitor.record_api_failure()
        monitor.record_api_failure()
        monitor.record_api_success()
        self.assertEqual(monitor.consecutive_api_failures, 0)

    def test_status_reports_all_active_problems(self):
        clock = [0.0]
        monitor = HealthMonitor(max_data_staleness_seconds=1.0, clock=lambda: clock[0])
        monitor.trigger_emergency_shutdown("manual test")
        status = monitor.status()
        self.assertFalse(status.healthy)
        self.assertTrue(any("emergency shutdown" in r for r in status.reasons))
        self.assertTrue(any("stale" in r for r in status.reasons))

    def test_reset_clears_shutdown(self):
        monitor = HealthMonitor()
        monitor.trigger_emergency_shutdown("test")
        monitor.reset_emergency_shutdown()
        self.assertFalse(monitor.is_shutdown)


if __name__ == "__main__":
    unittest.main()
