import unittest

from trading_system.core.models import AccountBalance, MarketSnapshot
from trading_system.decision.schema import parse_decision
from trading_system.risk.config import RiskLimits
from trading_system.risk.engine import RiskEngine


def make_snapshot(price=60_000.0, ts=1000.0):
    return MarketSnapshot(symbol="BTCUSDT", timestamp=ts, last_price=price)


def make_long_decision(snap, confidence=0.7, stop_loss=59_000.0, take_profit=62_000.0):
    raw = {
        "action": "LONG",
        "confidence": confidence,
        "entry": {"type": "MARKET"},
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "time_horizon": "1h",
        "reason": "test",
    }
    return parse_decision(raw, snapshot_timestamp=snap.timestamp)


def make_account(total=10_000.0, available=None):
    if available is None:
        available = total
    return [AccountBalance(currency="USDT", total=total, available=available, used=total - available)]


class TestRiskEngine(unittest.TestCase):
    def setUp(self):
        self.limits = RiskLimits(
            max_position_size_usd=5_000.0,
            max_leverage=3.0,
            risk_per_trade_pct=0.01,
            max_loss_per_trade_usd=200.0,
            max_daily_loss_usd=500.0,
            max_concurrent_positions=1,
            min_confidence_to_trade=0.5,
        )
        self.engine = RiskEngine(self.limits, clock=lambda: 1000.0)

    def test_no_trade_is_approved_as_no_op(self):
        snap = make_snapshot()
        raw = {"action": "NO_TRADE", "confidence": 0.1, "reason": "nothing", "entry": None,
               "stop_loss": None, "take_profit": None}
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.engine.evaluate(decision, snap, make_account(), [])
        self.assertTrue(result.approved)
        self.assertTrue(result.is_no_op)
        self.assertIsNone(result.approved_order)

    def test_low_confidence_rejected(self):
        snap = make_snapshot()
        decision = make_long_decision(snap, confidence=0.2)
        result = self.engine.evaluate(decision, snap, make_account(), [])
        self.assertFalse(result.approved)
        self.assertTrue(any("confidence" in r for r in result.reasons))

    def test_valid_long_is_approved_with_computed_size(self):
        snap = make_snapshot(price=60_000.0)
        decision = make_long_decision(snap)
        result = self.engine.evaluate(decision, snap, make_account(total=10_000.0), [])
        self.assertTrue(result.approved)
        self.assertIsNotNone(result.approved_order)
        # risk_per_trade_pct=1% of 10,000 = 100 target risk; stop distance = 1000
        # size = 100 / 1000 = 0.1 BTC -> notional = 6000, under max_position_size_usd (5000)? no, 6000>5000
        # so it should get capped to max_position_size_usd/entry_price
        order = result.approved_order
        self.assertLessEqual(order.notional_usd, self.limits.max_position_size_usd + 1e-6)
        self.assertLessEqual(order.leverage, self.limits.max_leverage)

    def test_claude_cannot_set_position_size(self):
        # TradeDecision has no size field at all -- structurally enforced.
        snap = make_snapshot()
        decision = make_long_decision(snap)
        self.assertFalse(hasattr(decision, "size"))

    def test_daily_loss_limit_blocks_new_trades(self):
        snap = make_snapshot()
        self.engine.record_realized_pnl(-600.0)  # exceeds max_daily_loss_usd=500
        decision = make_long_decision(snap)
        result = self.engine.evaluate(decision, snap, make_account(), [])
        self.assertFalse(result.approved)
        self.assertTrue(any("daily loss" in r for r in result.reasons))

    def test_max_concurrent_positions_enforced(self):
        from trading_system.core.models import Position
        from trading_system.core.enums import PositionSide

        snap = make_snapshot()
        existing = [
            Position(
                symbol="BTCUSDT", side=PositionSide.LONG, size=0.1,
                entry_price=59_000, mark_price=60_000, leverage=2.0,
            )
        ]
        decision = make_long_decision(snap)
        result = self.engine.evaluate(decision, snap, make_account(), existing)
        self.assertFalse(result.approved)
        self.assertTrue(any("max_concurrent_positions" in r for r in result.reasons))

    def test_emergency_shutdown_blocks_everything(self):
        snap = make_snapshot()
        self.engine.trigger_emergency_shutdown("test trip")
        decision = make_long_decision(snap)
        result = self.engine.evaluate(decision, snap, make_account(), [])
        self.assertFalse(result.approved)
        self.assertTrue(any("emergency shutdown" in r for r in result.reasons))

    def test_trading_disabled_kill_switch(self):
        limits = RiskLimits(trading_enabled=False)
        engine = RiskEngine(limits)
        snap = make_snapshot()
        decision = make_long_decision(snap)
        result = engine.evaluate(decision, snap, make_account(), [])
        self.assertFalse(result.approved)

    def test_insufficient_margin_rejected(self):
        snap = make_snapshot(price=60_000.0)
        decision = make_long_decision(snap)
        # tiny account can't afford even the capped position at max leverage
        result = self.engine.evaluate(decision, snap, make_account(total=1.0, available=0.001), [])
        self.assertFalse(result.approved)

    def test_zero_equity_rejected(self):
        snap = make_snapshot()
        decision = make_long_decision(snap)
        result = self.engine.evaluate(decision, snap, make_account(total=0.0, available=0.0), [])
        self.assertFalse(result.approved)

    def test_consecutive_loss_pause(self):
        limits = RiskLimits(max_consecutive_losses_before_pause=2)
        engine = RiskEngine(limits)
        engine.record_realized_pnl(-10.0)
        engine.record_realized_pnl(-10.0)
        snap = make_snapshot()
        decision = make_long_decision(snap)
        result = engine.evaluate(decision, snap, make_account(), [])
        self.assertFalse(result.approved)
        self.assertTrue(any("consecutive losses" in r for r in result.reasons))

    def test_consecutive_losses_reset_on_win(self):
        limits = RiskLimits(max_consecutive_losses_before_pause=2)
        engine = RiskEngine(limits)
        engine.record_realized_pnl(-10.0)
        engine.record_realized_pnl(50.0)  # win resets counter
        snap = make_snapshot()
        decision = make_long_decision(snap)
        result = engine.evaluate(decision, snap, make_account(), [])
        self.assertTrue(result.approved)


if __name__ == "__main__":
    unittest.main()
