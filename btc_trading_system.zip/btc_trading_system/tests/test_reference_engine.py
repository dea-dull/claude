import unittest

from trading_system.core.models import MarketSnapshot
from trading_system.decision.validator import DecisionValidator
from trading_system.features.engine import FeatureSet
from trading_system.strategy.reference_engine import RuleBasedReferenceDecisionEngine


def make_snapshot(price=60_000.0, ts=1000.0):
    return MarketSnapshot(symbol="BTCUSDT", timestamp=ts, last_price=price)


class TestRuleBasedReferenceDecisionEngine(unittest.TestCase):
    def setUp(self):
        self.engine = RuleBasedReferenceDecisionEngine()

    def test_insufficient_history_returns_no_trade(self):
        snap = make_snapshot()
        features = FeatureSet(symbol="BTCUSDT", timestamp=snap.timestamp, last_price=60_000.0, candles_available=5)
        decision = self.engine.decide(snap, features)
        self.assertEqual(decision.action, "NO_TRADE")

    def test_strong_uptrend_setup_produces_long(self):
        snap = make_snapshot(price=60_000.0)
        features = FeatureSet(
            symbol="BTCUSDT", timestamp=snap.timestamp, last_price=60_000.0,
            sma_fast=59_500.0, sma_slow=58_000.0,   # price > fast > slow: trend_long
            rsi=45.0,                                # in RSI_LONG_BAND
            momentum=0.02,                            # positive momentum
            realized_vol=0.01,                        # within range
            atr=500.0, candles_available=100,
        )
        decision = self.engine.decide(snap, features)
        self.assertEqual(decision.action, "LONG")
        self.assertIsNotNone(decision.stop_loss)
        self.assertLess(decision.stop_loss, snap.last_price)
        self.assertGreater(decision.take_profit, snap.last_price)

    def test_strong_downtrend_setup_produces_short(self):
        snap = make_snapshot(price=60_000.0)
        features = FeatureSet(
            symbol="BTCUSDT", timestamp=snap.timestamp, last_price=60_000.0,
            sma_fast=60_500.0, sma_slow=62_000.0,   # price < fast < slow: trend_short
            rsi=55.0,                                 # in RSI_SHORT_BAND
            momentum=-0.02,
            realized_vol=0.01,
            atr=500.0, candles_available=100,
        )
        decision = self.engine.decide(snap, features)
        self.assertEqual(decision.action, "SHORT")
        self.assertGreater(decision.stop_loss, snap.last_price)
        self.assertLess(decision.take_profit, snap.last_price)

    def test_mixed_ambiguous_signals_produce_no_trade(self):
        snap = make_snapshot(price=60_000.0)
        features = FeatureSet(
            symbol="BTCUSDT", timestamp=snap.timestamp, last_price=60_000.0,
            sma_fast=60_100.0, sma_slow=60_050.0,   # barely trending, ambiguous
            rsi=50.0,                                 # boundary-ish, not clearly in either band strongly
            momentum=0.0001,
            realized_vol=0.0005,                      # too low -- outside vol range
            atr=500.0, candles_available=100,
        )
        decision = self.engine.decide(snap, features)
        self.assertEqual(decision.action, "NO_TRADE")

    def test_produced_long_decision_passes_strategy_validator(self):
        snap = make_snapshot(price=60_000.0)
        features = FeatureSet(
            symbol="BTCUSDT", timestamp=snap.timestamp, last_price=60_000.0,
            sma_fast=59_500.0, sma_slow=58_000.0,
            rsi=45.0, momentum=0.02, realized_vol=0.01,
            atr=500.0, candles_available=100,
        )
        decision = self.engine.decide(snap, features)
        validator = DecisionValidator(min_risk_reward=1.2, stop_atr_multiple_range=(0.5, 4.0))
        result = validator.validate(decision, snap, features=features)
        self.assertTrue(result.is_valid, result.errors)

    def test_deterministic_same_input_same_output(self):
        snap = make_snapshot(price=60_000.0)
        features = FeatureSet(
            symbol="BTCUSDT", timestamp=snap.timestamp, last_price=60_000.0,
            sma_fast=59_500.0, sma_slow=58_000.0,
            rsi=45.0, momentum=0.02, realized_vol=0.01,
            atr=500.0, candles_available=100,
        )
        d1 = self.engine.decide(snap, features)
        d2 = self.engine.decide(snap, features)
        self.assertEqual(d1.action, d2.action)
        self.assertEqual(d1.stop_loss, d2.stop_loss)
        self.assertEqual(d1.take_profit, d2.take_profit)
        self.assertEqual(d1.confidence, d2.confidence)


if __name__ == "__main__":
    unittest.main()
