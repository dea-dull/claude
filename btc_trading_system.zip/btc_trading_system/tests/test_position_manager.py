import unittest

from trading_system.core.enums import OrderSide, OrderType
from trading_system.core.models import OrderRequest
from trading_system.exchange.mock_exchange import MockExchangeAdapter
from trading_system.state.position_manager import PositionOrderManager


class TestPositionOrderManager(unittest.TestCase):
    def setUp(self):
        self.exchange = MockExchangeAdapter(starting_price=60_000.0, seed=5)
        self.manager = PositionOrderManager()

    def test_reconcile_detects_missing_local_position(self):
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        self.exchange.place_order(req)
        # local manager knows nothing about this yet
        discrepancies = self.manager.reconcile(self.exchange)
        kinds = [d.kind for d in discrepancies]
        self.assertIn("missing_local_position", kinds)

    def test_reconcile_clean_after_refresh(self):
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        self.exchange.place_order(req)
        self.manager.refresh_from_exchange(self.exchange)
        discrepancies = self.manager.reconcile(self.exchange)
        self.assertEqual(discrepancies, [])

    def test_reconcile_detects_missing_exchange_position(self):
        # manually record a local position the exchange doesn't have
        from trading_system.core.models import Position
        from trading_system.core.enums import PositionSide

        self.manager.record_position(
            Position(symbol="ETHUSDT", side=PositionSide.LONG, size=1.0, entry_price=3000, mark_price=3000, leverage=1.0)
        )
        discrepancies = self.manager.reconcile(self.exchange)
        kinds = [d.kind for d in discrepancies]
        self.assertIn("missing_exchange_position", kinds)

    def test_reconcile_detects_size_mismatch(self):
        from trading_system.core.models import Position
        from trading_system.core.enums import PositionSide

        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.05)
        self.exchange.place_order(req)
        # record a *different* size locally
        self.manager.record_position(
            Position(symbol="BTCUSDT", side=PositionSide.LONG, size=0.01, entry_price=60_000, mark_price=60_000, leverage=1.0)
        )
        discrepancies = self.manager.reconcile(self.exchange)
        kinds = [d.kind for d in discrepancies]
        self.assertIn("size_mismatch", kinds)

    def test_get_open_positions_filters_flat(self):
        from trading_system.core.models import Position
        from trading_system.core.enums import PositionSide

        self.manager.record_position(
            Position(symbol="BTCUSDT", side=PositionSide.LONG, size=0.0, entry_price=60_000, mark_price=60_000, leverage=1.0)
        )
        self.assertEqual(self.manager.get_open_positions(), [])


if __name__ == "__main__":
    unittest.main()
