import unittest

from trading_system.core.enums import OrderSide, OrderType
from trading_system.core.models import OrderRequest
from trading_system.exchange.mock_exchange import MockExchangeAdapter
from trading_system.exchange.simulated_matching import CostModel


class TestCostBreakdown(unittest.TestCase):
    def test_fees_spread_slippage_tracked_separately(self):
        cost_model = CostModel(taker_fee_bps=6.0, slippage_bps=3.0)
        exchange = MockExchangeAdapter(starting_price=60_000.0, seed=1, spread_bps=4.0, cost_model=cost_model)
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.1)
        exchange.place_order(req)

        fees = exchange.get_cumulative_fees("BTCUSDT")
        spread = exchange.get_cumulative_spread_cost("BTCUSDT")
        slippage = exchange.get_cumulative_slippage_cost("BTCUSDT")

        self.assertGreater(fees, 0)
        self.assertGreater(spread, 0)
        self.assertGreater(slippage, 0)
        self.assertNotAlmostEqual(fees, spread, delta=0.0001)

    def test_maker_fill_has_zero_spread_and_slippage_cost(self):
        cost_model = CostModel(maker_fee_bps=2.0, slippage_bps=5.0)
        exchange = MockExchangeAdapter(starting_price=60_000.0, seed=1, spread_bps=4.0, cost_model=cost_model)
        snap = exchange.get_market_snapshot("BTCUSDT")
        req = OrderRequest(
            symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.LIMIT,
            size=0.05, price=snap.last_price * 1.01,
        )
        exchange.place_order(req)
        self.assertEqual(exchange.get_cumulative_spread_cost("BTCUSDT"), 0.0)
        self.assertEqual(exchange.get_cumulative_slippage_cost("BTCUSDT"), 0.0)
        self.assertGreater(exchange.get_cumulative_fees("BTCUSDT"), 0.0)

    def test_cumulative_funding_tracked(self):
        cost_model = CostModel(funding_rate_per_interval=0.001, funding_interval_seconds=10.0)
        clock = [0.0]
        exchange = MockExchangeAdapter(
            starting_price=60_000.0, seed=1, cost_model=cost_model, clock=lambda: clock[0]
        )
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.1)
        exchange.place_order(req)

        clock[0] = 11.0
        exchange._matching.accrue_funding("BTCUSDT", 60_000.0, clock[0])
        funding_paid = exchange.get_cumulative_funding("BTCUSDT")
        self.assertLess(funding_paid, 0)

    def test_funding_rate_override_used_instead_of_cost_model_default(self):
        cost_model = CostModel(funding_rate_per_interval=0.0, funding_interval_seconds=10.0)
        clock = [0.0]
        exchange = MockExchangeAdapter(
            starting_price=60_000.0, seed=1, cost_model=cost_model, clock=lambda: clock[0]
        )
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.1)
        exchange.place_order(req)

        clock[0] = 11.0
        payment = exchange._matching.accrue_funding("BTCUSDT", 60_000.0, clock[0], rate_override=0.002)
        self.assertNotEqual(payment, 0.0)

    def test_zero_cost_model_yields_zero_breakdown(self):
        cost_model = CostModel(taker_fee_bps=0, maker_fee_bps=0, slippage_bps=0, funding_rate_per_interval=0)
        exchange = MockExchangeAdapter(starting_price=60_000.0, seed=1, spread_bps=0.0, cost_model=cost_model)
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.1)
        exchange.place_order(req)
        self.assertEqual(exchange.get_cumulative_fees("BTCUSDT"), 0.0)
        # Allow a sub-cent tolerance: the synthesized book rounds price
        # levels to 2 decimals, which can introduce a negligible residual
        # vs. the unrounded mid price even at spread_bps=0 -- not a real
        # spread/slippage cost, just display-precision rounding.
        self.assertAlmostEqual(exchange.get_cumulative_spread_cost("BTCUSDT"), 0.0, delta=0.01)
        self.assertAlmostEqual(exchange.get_cumulative_slippage_cost("BTCUSDT"), 0.0, delta=0.01)


if __name__ == "__main__":
    unittest.main()
