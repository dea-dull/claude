import unittest

from trading_system.core.enums import OrderSide, OrderType, OrderStatus, PositionSide
from trading_system.core.exceptions import DuplicateOrderError
from trading_system.core.models import OrderRequest
from trading_system.exchange.mock_exchange import MockExchangeAdapter


class TestMockExchangeAdapter(unittest.TestCase):
    def setUp(self):
        self.exchange = MockExchangeAdapter(
            symbol="BTCUSDT",
            starting_price=60_000.0,
            starting_balance=10_000.0,
            seed=42,
        )

    def test_snapshot_has_book_and_candles(self):
        snap = self.exchange.get_market_snapshot("BTCUSDT")
        self.assertEqual(snap.symbol, "BTCUSDT")
        self.assertIsNotNone(snap.order_book)
        self.assertGreater(len(snap.recent_candles), 0)
        self.assertGreater(snap.best_bid, 0)
        self.assertGreater(snap.best_ask, snap.best_bid)

    def test_market_order_fills_immediately_and_opens_position(self):
        req = OrderRequest(
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            size=0.01,
            leverage=2.0,
        )
        order = self.exchange.place_order(req)
        self.assertEqual(order.status, OrderStatus.FILLED)
        positions = self.exchange.get_positions()
        self.assertEqual(len(positions), 1)
        self.assertEqual(positions[0].side, PositionSide.LONG)
        self.assertAlmostEqual(positions[0].size, 0.01)

    def test_duplicate_client_order_id_rejected(self):
        req = OrderRequest(
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            size=0.01,
            client_order_id="fixed-id-1",
        )
        self.exchange.place_order(req)
        with self.assertRaises(DuplicateOrderError):
            self.exchange.place_order(req)

    def test_limit_order_rests_until_price_crosses(self):
        snap = self.exchange.get_market_snapshot("BTCUSDT")
        far_below = snap.last_price * 0.5
        req = OrderRequest(
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            size=0.01,
            price=far_below,
        )
        order = self.exchange.place_order(req)
        self.assertEqual(order.status, OrderStatus.OPEN)
        open_orders = self.exchange.get_open_orders()
        self.assertEqual(len(open_orders), 1)

    def test_cancel_order(self):
        snap = self.exchange.get_market_snapshot("BTCUSDT")
        far_below = snap.last_price * 0.5
        req = OrderRequest(
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            size=0.01,
            price=far_below,
        )
        order = self.exchange.place_order(req)
        cancelled = self.exchange.cancel_order(order.order_id)
        self.assertTrue(cancelled)
        status = self.exchange.get_order_status(order.order_id)
        self.assertEqual(status.status, OrderStatus.CANCELLED)

    def test_closing_position_realizes_pnl(self):
        buy = OrderRequest(
            symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.1, leverage=2.0
        )
        self.exchange.place_order(buy)
        entry_price = self.exchange.get_positions()[0].entry_price

        # force a favorable price so we can assert positive realized pnl
        self.exchange._price = entry_price * 1.05  # noqa: SLF001 (test-only introspection)

        sell = OrderRequest(
            symbol="BTCUSDT", side=OrderSide.SELL, order_type=OrderType.MARKET, size=0.1, reduce_only=True
        )
        self.exchange.place_order(sell)
        positions = self.exchange.get_positions()
        self.assertEqual(len(positions), 0)  # fully closed, filtered out
        realized = self.exchange.get_cumulative_realized_pnl("BTCUSDT")
        self.assertGreater(realized, 0)

    def test_tick_advances_price_and_checks_pending_orders(self):
        before = self.exchange.get_market_snapshot("BTCUSDT").last_price
        self.exchange.tick()
        after = self.exchange.get_market_snapshot("BTCUSDT").last_price
        self.assertNotEqual(before, after)


if __name__ == "__main__":
    unittest.main()
