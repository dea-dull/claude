import os
import tempfile
import unittest

from trading_system.backtesting.data_loader import load_ohlcv_csv


class TestDataLoader(unittest.TestCase):
    def _write(self, content: str) -> str:
        path = tempfile.mktemp(suffix=".csv")
        with open(path, "w") as f:
            f.write(content)
        self.addCleanup(lambda: os.path.exists(path) and os.remove(path))
        return path

    def test_loads_valid_csv(self):
        path = self._write(
            "timestamp,open,high,low,close,volume\n"
            "1000,100,110,90,105,10\n"
            "1060,105,115,95,110,12\n"
        )
        candles = load_ohlcv_csv(path, timeframe_seconds=60)
        self.assertEqual(len(candles), 2)
        self.assertEqual(candles[0].open, 100)
        self.assertEqual(candles[1].close, 110)

    def test_iso_timestamp_parsed(self):
        path = self._write(
            "timestamp,open,high,low,close,volume\n"
            "2024-01-01T00:00:00Z,100,110,90,105,10\n"
            "2024-01-01T04:00:00Z,105,115,95,110,12\n"
        )
        candles = load_ohlcv_csv(path, timeframe_seconds=14400)
        self.assertEqual(len(candles), 2)
        self.assertLess(candles[0].timestamp, candles[1].timestamp)

    def test_millisecond_timestamp_converted(self):
        path = self._write(
            "timestamp,open,high,low,close,volume\n"
            "1700000000000,100,110,90,105,10\n"
            "1700014400000,105,115,95,110,12\n"
        )
        candles = load_ohlcv_csv(path, timeframe_seconds=14400)
        self.assertAlmostEqual(candles[0].timestamp, 1700000000.0)

    def test_missing_columns_raises(self):
        path = self._write("timestamp,open,close\n1000,100,105\n")
        with self.assertRaises(ValueError):
            load_ohlcv_csv(path, timeframe_seconds=60)

    def test_out_of_order_timestamps_raises(self):
        path = self._write(
            "timestamp,open,high,low,close,volume\n"
            "2000,100,110,90,105,10\n"
            "1000,105,115,95,110,12\n"
        )
        with self.assertRaises(ValueError):
            load_ohlcv_csv(path, timeframe_seconds=60)

    def test_empty_data_raises(self):
        path = self._write("timestamp,open,high,low,close,volume\n")
        with self.assertRaises(ValueError):
            load_ohlcv_csv(path, timeframe_seconds=60)

    def test_generated_synthetic_dataset_loads(self):
        path = "data/btc_4h_synthetic.csv"
        if not os.path.exists(path):
            self.skipTest("synthetic dataset not generated in this environment")
        candles = load_ohlcv_csv(path, timeframe_seconds=14400)
        self.assertGreater(len(candles), 1000)


if __name__ == "__main__":
    unittest.main()
