import unittest

from trading_system.core.models import MarketSnapshot
from trading_system.decision.schema import parse_decision
from trading_system.decision.validator import DecisionValidator
from trading_system.features.engine import FeatureSet


def make_snapshot(price=60_000.0, ts=1000.0):
    return MarketSnapshot(symbol="BTCUSDT", timestamp=ts, last_price=price)


def make_features(atr=500.0, ts=1000.0, price=60_000.0):
    return FeatureSet(symbol="BTCUSDT", timestamp=ts, last_price=price, atr=atr)


class TestMinRiskReward(unittest.TestCase):
    def setUp(self):
        self.validator = DecisionValidator(min_risk_reward=1.5)

    def test_reward_risk_below_minimum_rejected(self):
        snap = make_snapshot(price=60_000.0)
        raw = {
            "action": "LONG", "confidence": 0.7, "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0, "take_profit": 60_500.0,  # RR = 500/1000 = 0.5
            "time_horizon": "1h", "reason": "test",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertFalse(result.is_valid)
        self.assertTrue(any("reward:risk" in e for e in result.errors))

    def test_reward_risk_meeting_minimum_passes(self):
        snap = make_snapshot(price=60_000.0)
        raw = {
            "action": "LONG", "confidence": 0.7, "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0, "take_profit": 61_600.0,  # RR = 1600/1000 = 1.6
            "time_horizon": "1h", "reason": "test",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertTrue(result.is_valid, result.errors)


class TestStopAtrMultipleRange(unittest.TestCase):
    def setUp(self):
        self.validator = DecisionValidator(stop_atr_multiple_range=(0.5, 4.0))

    def test_stop_too_tight_relative_to_atr_rejected(self):
        snap = make_snapshot(price=60_000.0)
        features = make_features(atr=1000.0)
        raw = {
            "action": "LONG", "confidence": 0.7, "entry": {"type": "MARKET"},
            "stop_loss": 59_950.0,  # only 50 away, 0.05x ATR -- too tight
            "take_profit": 62_000.0, "time_horizon": "1h", "reason": "test",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap, features=features)
        self.assertFalse(result.is_valid)
        self.assertTrue(any("ATR" in e for e in result.errors))

    def test_stop_too_wide_relative_to_atr_rejected(self):
        snap = make_snapshot(price=60_000.0)
        features = make_features(atr=100.0)
        raw = {
            "action": "LONG", "confidence": 0.7, "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0,  # 1000 away, 10x ATR -- too wide
            "take_profit": 62_000.0, "time_horizon": "1h", "reason": "test",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap, features=features)
        self.assertFalse(result.is_valid)

    def test_stop_within_atr_range_passes(self):
        snap = make_snapshot(price=60_000.0)
        features = make_features(atr=500.0)
        raw = {
            "action": "LONG", "confidence": 0.7, "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0,  # 1000 away = 2x ATR, within [0.5, 4]
            "take_profit": 62_000.0, "time_horizon": "1h", "reason": "test",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap, features=features)
        self.assertTrue(result.is_valid, result.errors)

    def test_missing_features_when_check_configured_rejected(self):
        snap = make_snapshot(price=60_000.0)
        raw = {
            "action": "LONG", "confidence": 0.7, "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0, "take_profit": 62_000.0,
            "time_horizon": "1h", "reason": "test",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap, features=None)
        self.assertFalse(result.is_valid)

    def test_check_disabled_by_default(self):
        validator = DecisionValidator()  # no stop_atr_multiple_range configured
        snap = make_snapshot(price=60_000.0)
        raw = {
            "action": "LONG", "confidence": 0.7, "entry": {"type": "MARKET"},
            "stop_loss": 59_999.0,  # absurdly tight, but check is off
            "take_profit": 62_000.0, "time_horizon": "1h", "reason": "test",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = validator.validate(decision, snap)
        self.assertTrue(result.is_valid, result.errors)


if __name__ == "__main__":
    unittest.main()
