import unittest

from trading_system.core.models import MarketSnapshot
from trading_system.decision.schema import parse_decision
from trading_system.decision.validator import DecisionValidator


def make_snapshot(price=60_000.0, ts=1000.0):
    return MarketSnapshot(symbol="BTCUSDT", timestamp=ts, last_price=price)


class TestDecisionValidator(unittest.TestCase):
    def setUp(self):
        self.validator = DecisionValidator()

    def test_valid_long_decision_passes(self):
        snap = make_snapshot(price=60_000.0)
        raw = {
            "action": "LONG",
            "confidence": 0.7,
            "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0,
            "take_profit": 62_000.0,
            "time_horizon": "1h",
            "reason": "bullish momentum",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertTrue(result.is_valid, result.errors)

    def test_valid_short_decision_passes(self):
        snap = make_snapshot(price=60_000.0)
        raw = {
            "action": "SHORT",
            "confidence": 0.7,
            "entry": {"type": "MARKET"},
            "stop_loss": 61_000.0,
            "take_profit": 58_000.0,
            "time_horizon": "1h",
            "reason": "bearish momentum",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertTrue(result.is_valid, result.errors)

    def test_no_trade_passes_with_minimal_fields(self):
        snap = make_snapshot()
        raw = {
            "action": "NO_TRADE",
            "confidence": 0.1,
            "entry": None,
            "stop_loss": None,
            "take_profit": None,
            "time_horizon": "1h",
            "reason": "no clear edge",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertTrue(result.is_valid, result.errors)

    def test_invalid_action_rejected(self):
        snap = make_snapshot()
        raw = {
            "action": "BUY_A_LOT",
            "confidence": 0.9,
            "reason": "yolo",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertFalse(result.is_valid)

    def test_long_with_stop_above_entry_rejected(self):
        snap = make_snapshot(price=60_000.0)
        raw = {
            "action": "LONG",
            "confidence": 0.7,
            "entry": {"type": "MARKET"},
            "stop_loss": 61_000.0,  # wrong side
            "take_profit": 62_000.0,
            "time_horizon": "1h",
            "reason": "bullish",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertFalse(result.is_valid)
        self.assertTrue(any("LONG requires" in e for e in result.errors))

    def test_missing_stop_loss_rejected(self):
        snap = make_snapshot()
        raw = {
            "action": "LONG",
            "confidence": 0.7,
            "entry": {"type": "MARKET"},
            "stop_loss": None,
            "take_profit": 62_000.0,
            "time_horizon": "1h",
            "reason": "bullish",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertFalse(result.is_valid)
        self.assertTrue(any("stop_loss is required" in e for e in result.errors))

    def test_confidence_out_of_range_rejected(self):
        snap = make_snapshot()
        raw = {
            "action": "LONG",
            "confidence": 1.5,
            "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0,
            "take_profit": 62_000.0,
            "time_horizon": "1h",
            "reason": "bullish",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertFalse(result.is_valid)

    def test_entry_price_too_far_from_market_rejected(self):
        snap = make_snapshot(price=60_000.0)
        raw = {
            "action": "LONG",
            "confidence": 0.7,
            "entry": {"type": "LIMIT", "price": 40_000.0},  # >30% away
            "stop_loss": 39_000.0,
            "take_profit": 45_000.0,
            "time_horizon": "1h",
            "reason": "bullish",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertFalse(result.is_valid)
        self.assertTrue(any("deviates" in e for e in result.errors))

    def test_no_trade_with_sl_tp_set_is_contradiction(self):
        snap = make_snapshot()
        raw = {
            "action": "NO_TRADE",
            "confidence": 0.1,
            "stop_loss": 59_000.0,
            "take_profit": 62_000.0,
            "reason": "no clear edge",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        result = self.validator.validate(decision, snap)
        self.assertFalse(result.is_valid)

    def test_malformed_json_types_rejected(self):
        snap = make_snapshot()
        raw = {
            "action": "LONG",
            "confidence": "very confident",  # wrong type
            "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0,
            "take_profit": 62_000.0,
            "reason": "bullish",
        }
        decision = parse_decision(raw, snapshot_timestamp=snap.timestamp)
        self.assertTrue(len(decision.parse_errors) > 0)
        result = self.validator.validate(decision, snap)
        self.assertFalse(result.is_valid)

    def test_mismatched_snapshot_timestamp_rejected(self):
        snap = make_snapshot(ts=1000.0)
        raw = {
            "action": "LONG",
            "confidence": 0.7,
            "entry": {"type": "MARKET"},
            "stop_loss": 59_000.0,
            "take_profit": 62_000.0,
            "time_horizon": "1h",
            "reason": "bullish",
        }
        # decision claims to be based on a different snapshot than the one we validate against
        decision = parse_decision(raw, snapshot_timestamp=999.0)
        result = self.validator.validate(decision, snap)
        self.assertFalse(result.is_valid)
        self.assertTrue(any("snapshot_timestamp" in e for e in result.errors))


if __name__ == "__main__":
    unittest.main()
