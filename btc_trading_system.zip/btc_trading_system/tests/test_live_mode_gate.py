import unittest

from trading_system.core.enums import SystemMode
from trading_system.decision.claude_interface import MockDecisionEngine
from trading_system.exchange.base import LiveExchangeAdapter
from trading_system.exchange.mock_exchange import MockExchangeAdapter
from trading_system.persistence.db import EventStore
from trading_system.pipeline import TradingPipeline, TradingSystem
from trading_system.risk.config import RiskLimits
from trading_system.risk.engine import RiskEngine


def make_pipeline(exchange):
    return TradingPipeline(
        exchange=exchange,
        decision_engine=MockDecisionEngine(),
        event_store=EventStore(":memory:"),
        risk_engine=RiskEngine(RiskLimits()),
    )


class FakeLiveAdapter(MockExchangeAdapter, LiveExchangeAdapter):
    """A stand-in for what a real, verified Margex adapter will
    eventually be: something that actually subclasses LiveExchangeAdapter.
    This class does NOT exist for real trading -- it exists only to prove
    the gate logic works once such a class is provided."""


class TestLiveModeGate(unittest.TestCase):
    def test_live_mode_rejected_with_simulated_adapter(self):
        pipeline = make_pipeline(MockExchangeAdapter())
        with self.assertRaises(RuntimeError):
            TradingSystem(mode=SystemMode.LIVE, pipeline=pipeline, enable_live_trading=True)

    def test_live_mode_rejected_without_explicit_enable_flag(self):
        pipeline = make_pipeline(FakeLiveAdapter())
        with self.assertRaises(RuntimeError):
            TradingSystem(mode=SystemMode.LIVE, pipeline=pipeline, enable_live_trading=False)

    def test_live_mode_allowed_only_with_both_conditions(self):
        pipeline = make_pipeline(FakeLiveAdapter())
        system = TradingSystem(mode=SystemMode.LIVE, pipeline=pipeline, enable_live_trading=True)
        self.assertEqual(system.mode, SystemMode.LIVE)

    def test_paper_mode_never_gated(self):
        pipeline = make_pipeline(MockExchangeAdapter())
        system = TradingSystem(mode=SystemMode.PAPER, pipeline=pipeline)
        self.assertEqual(system.mode, SystemMode.PAPER)

    def test_backtest_mode_never_gated(self):
        pipeline = make_pipeline(MockExchangeAdapter())
        system = TradingSystem(mode=SystemMode.BACKTEST, pipeline=pipeline)
        self.assertEqual(system.mode, SystemMode.BACKTEST)


if __name__ == "__main__":
    unittest.main()
