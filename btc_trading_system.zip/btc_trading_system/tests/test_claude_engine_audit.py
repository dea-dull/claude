import unittest

from trading_system.core.models import MarketSnapshot
from trading_system.decision.claude_interface import ClaudeDecisionEngine
from trading_system.features.engine import FeatureSet


def make_snapshot(ts=1000.0, price=60_000.0):
    return MarketSnapshot(symbol="BTCUSDT", timestamp=ts, last_price=price)


def make_features(ts=1000.0, price=60_000.0):
    return FeatureSet(symbol="BTCUSDT", timestamp=ts, last_price=price)


class TestRawPromptAudit(unittest.TestCase):
    def test_raw_prompt_and_response_both_preserved(self):
        captured = {}

        def fake_llm(prompt: str) -> str:
            captured["prompt"] = prompt
            return '{"action": "NO_TRADE", "confidence": 0.1, "reason": "nothing here"}'

        engine = ClaudeDecisionEngine(llm_call_fn=fake_llm)
        snap = make_snapshot()
        features = make_features()
        decision = engine.decide(snap, features)

        self.assertEqual(decision.raw_prompt, captured["prompt"])
        self.assertIn("NO_TRADE", decision.raw_response)
        self.assertIn(str(snap.symbol), decision.raw_prompt)

    def test_raw_prompt_preserved_even_on_parse_failure(self):
        def fake_llm(prompt: str) -> str:
            return "not valid json at all"

        engine = ClaudeDecisionEngine(llm_call_fn=fake_llm)
        decision = engine.decide(make_snapshot(), make_features())

        self.assertIsNotNone(decision.raw_prompt)
        self.assertEqual(decision.raw_response, "not valid json at all")
        self.assertTrue(len(decision.parse_errors) > 0)

    def test_json_wrapped_in_markdown_fence_is_recovered(self):
        def fake_llm(prompt: str) -> str:
            return '```json\n{"action": "NO_TRADE", "confidence": 0.2, "reason": "fenced"}\n```'

        engine = ClaudeDecisionEngine(llm_call_fn=fake_llm)
        decision = engine.decide(make_snapshot(), make_features())

        self.assertEqual(decision.action, "NO_TRADE")
        self.assertEqual(len(decision.parse_errors), 0)

    def test_bare_fence_without_json_tag_recovered(self):
        def fake_llm(prompt: str) -> str:
            return '```\n{"action": "NO_TRADE", "confidence": 0.2, "reason": "fenced"}\n```'

        engine = ClaudeDecisionEngine(llm_call_fn=fake_llm)
        decision = engine.decide(make_snapshot(), make_features())
        self.assertEqual(decision.action, "NO_TRADE")
        self.assertEqual(len(decision.parse_errors), 0)

    def test_prompt_contains_no_v1_condition_language_by_default(self):
        def fake_llm(prompt: str) -> str:
            return '{"action": "NO_TRADE", "confidence": 0.1, "reason": "x"}'

        engine = ClaudeDecisionEngine(llm_call_fn=fake_llm)
        decision = engine.decide(make_snapshot(), make_features())
        self.assertNotIn("condition", decision.raw_prompt.lower())


if __name__ == "__main__":
    unittest.main()
