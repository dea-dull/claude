import unittest

from trading_system.core.models import Candle, MarketSnapshot, OrderBook, OrderBookLevel
from trading_system.features.engine import FeatureEngine


def make_candles(closes, timeframe=60, start_ts=0.0):
    candles = []
    t = start_ts
    prev = closes[0]
    for c in closes:
        o = prev
        candles.append(
            Candle(timestamp=t, open=o, high=max(o, c), low=min(o, c), close=c, volume=10.0, timeframe_seconds=timeframe)
        )
        prev = c
        t += timeframe
    return candles


class TestFeatureEngine(unittest.TestCase):
    def setUp(self):
        self.engine = FeatureEngine(
            sma_fast_period=3, sma_slow_period=5, ema_fast_period=3, ema_slow_period=5,
            rsi_period=4, atr_period=4, vol_period=4, momentum_lookback=3,
        )

    def test_insufficient_history_returns_none_indicators(self):
        candles = make_candles([100.0, 101.0])
        snap = MarketSnapshot(symbol="BTCUSDT", timestamp=100.0, last_price=101.0, recent_candles=candles)
        features = self.engine.compute(snap)
        self.assertIsNone(features.sma_fast)
        self.assertIsNone(features.rsi)
        self.assertEqual(features.candles_available, 2)

    def test_rsi_high_for_monotonic_uptrend(self):
        closes = [100, 101, 102, 103, 104, 105, 106]
        candles = make_candles(closes)
        snap = MarketSnapshot(symbol="BTCUSDT", timestamp=600.0, last_price=closes[-1], recent_candles=candles)
        features = self.engine.compute(snap)
        self.assertIsNotNone(features.rsi)
        self.assertEqual(features.rsi, 100.0)  # no losses at all -> RSI == 100

    def test_rsi_low_for_monotonic_downtrend(self):
        closes = [106, 105, 104, 103, 102, 101, 100]
        candles = make_candles(closes)
        snap = MarketSnapshot(symbol="BTCUSDT", timestamp=600.0, last_price=closes[-1], recent_candles=candles)
        features = self.engine.compute(snap)
        self.assertEqual(features.rsi, 0.0)

    def test_sma_matches_manual_average(self):
        closes = [10, 20, 30, 40, 50]
        candles = make_candles(closes)
        snap = MarketSnapshot(symbol="BTCUSDT", timestamp=300.0, last_price=50, recent_candles=candles)
        features = self.engine.compute(snap)
        self.assertAlmostEqual(features.sma_fast, (30 + 40 + 50) / 3)  # period=3
        self.assertAlmostEqual(features.sma_slow, (10 + 20 + 30 + 40 + 50) / 5)  # period=5

    def test_order_book_spread_and_imbalance(self):
        book = OrderBook(
            timestamp=1.0,
            bids=[OrderBookLevel(price=99.0, size=10.0), OrderBookLevel(price=98.5, size=5.0)],
            asks=[OrderBookLevel(price=100.0, size=2.0), OrderBookLevel(price=100.5, size=2.0)],
        )
        candles = make_candles([100, 100.5, 99.8, 99.9])
        snap = MarketSnapshot(
            symbol="BTCUSDT", timestamp=180.0, last_price=99.9, order_book=book, recent_candles=candles
        )
        features = self.engine.compute(snap)
        self.assertAlmostEqual(features.spread, 1.0)
        self.assertGreater(features.order_book_imbalance, 0)  # more size on bid side

    def test_momentum_positive_in_uptrend(self):
        closes = [100, 101, 102, 103, 110]
        candles = make_candles(closes)
        snap = MarketSnapshot(symbol="BTCUSDT", timestamp=240.0, last_price=110, recent_candles=candles)
        features = self.engine.compute(snap)
        self.assertGreater(features.momentum, 0)


if __name__ == "__main__":
    unittest.main()
