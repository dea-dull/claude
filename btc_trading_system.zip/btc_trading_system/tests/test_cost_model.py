import unittest

from trading_system.core.enums import OrderSide, OrderType
from trading_system.core.models import OrderRequest
from trading_system.exchange.mock_exchange import MockExchangeAdapter
from trading_system.exchange.simulated_matching import CostModel


class TestCostModel(unittest.TestCase):
    def test_market_buy_fills_at_ask_not_mid(self):
        exchange = MockExchangeAdapter(starting_price=60_000.0, seed=1, spread_bps=10.0)
        snap = exchange.get_market_snapshot("BTCUSDT")
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        order = exchange.place_order(req)
        self.assertGreater(order.avg_fill_price, snap.last_price)
        self.assertAlmostEqual(order.avg_fill_price, snap.best_ask, delta=1.0)

    def test_market_sell_fills_at_bid_not_mid(self):
        exchange = MockExchangeAdapter(starting_price=60_000.0, seed=1, spread_bps=10.0)
        snap = exchange.get_market_snapshot("BTCUSDT")
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.SELL, order_type=OrderType.MARKET, size=0.01)
        order = exchange.place_order(req)
        self.assertLess(order.avg_fill_price, snap.last_price)
        self.assertAlmostEqual(order.avg_fill_price, snap.best_bid, delta=1.0)

    def test_slippage_adds_extra_cost_on_top_of_spread(self):
        cost_model = CostModel(slippage_bps=50.0)
        exchange = MockExchangeAdapter(starting_price=60_000.0, seed=1, spread_bps=2.0, cost_model=cost_model)
        snap = exchange.get_market_snapshot("BTCUSDT")
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        order = exchange.place_order(req)
        self.assertGreater(order.avg_fill_price, snap.best_ask)

    def test_taker_fee_is_charged_on_market_fill(self):
        cost_model = CostModel(taker_fee_bps=10.0, maker_fee_bps=1.0)
        exchange = MockExchangeAdapter(starting_price=60_000.0, seed=1, cost_model=cost_model)
        market_req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        balance_before = exchange.get_account()[0].total
        exchange.place_order(market_req)
        balance_after = exchange.get_account()[0].total
        self.assertGreater(balance_before - balance_after, 0)
        self.assertNotEqual(cost_model.taker_fee_bps, cost_model.maker_fee_bps)

    def test_funding_charges_long_when_rate_positive(self):
        cost_model = CostModel(funding_rate_per_interval=0.001, funding_interval_seconds=10.0)
        clock = [0.0]
        exchange = MockExchangeAdapter(
            starting_price=60_000.0, seed=1, cost_model=cost_model, clock=lambda: clock[0]
        )
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.1)
        exchange.place_order(req)
        balance_before = exchange.get_account()[0].total

        clock[0] = 11.0
        exchange._matching.accrue_funding("BTCUSDT", 60_000.0, clock[0])
        balance_after = exchange.get_account()[0].total
        self.assertLess(balance_after, balance_before)

    def test_funding_credits_short_when_rate_positive(self):
        cost_model = CostModel(funding_rate_per_interval=0.001, funding_interval_seconds=10.0)
        clock = [0.0]
        exchange = MockExchangeAdapter(
            starting_price=60_000.0, seed=1, cost_model=cost_model, clock=lambda: clock[0]
        )
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.SELL, order_type=OrderType.MARKET, size=0.1)
        exchange.place_order(req)
        balance_before = exchange.get_account()[0].total

        clock[0] = 11.0
        exchange._matching.accrue_funding("BTCUSDT", 60_000.0, clock[0])
        balance_after = exchange.get_account()[0].total
        self.assertGreater(balance_after, balance_before)

    def test_no_funding_before_interval_elapses(self):
        cost_model = CostModel(funding_rate_per_interval=0.001, funding_interval_seconds=100.0)
        clock = [0.0]
        exchange = MockExchangeAdapter(
            starting_price=60_000.0, seed=1, cost_model=cost_model, clock=lambda: clock[0]
        )
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.1)
        exchange.place_order(req)
        balance_before = exchange.get_account()[0].total

        clock[0] = 5.0
        payment = exchange._matching.accrue_funding("BTCUSDT", 60_000.0, clock[0])
        balance_after = exchange.get_account()[0].total
        self.assertEqual(payment, 0.0)
        self.assertEqual(balance_before, balance_after)

    def test_default_cost_model_preserves_legacy_behavior_when_no_book(self):
        from trading_system.exchange.simulated_matching import SimulatedMatchingEngine

        engine = SimulatedMatchingEngine(starting_balance=10_000.0)
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        order = engine.place_order(req, reference_price=60_000.0)
        self.assertEqual(order.avg_fill_price, 60_000.0)


if __name__ == "__main__":
    unittest.main()
