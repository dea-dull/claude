import unittest

from trading_system.core.enums import OrderSide, OrderType
from trading_system.core.models import OrderRequest
from trading_system.exchange.mock_exchange import MockExchangeAdapter
from trading_system.execution.engine import ExecutionEngine
from trading_system.persistence.db import EventStore
from trading_system.strategy.holding_period import HoldingPeriodPolicy


class TestHoldingPeriodPolicy(unittest.TestCase):
    def setUp(self):
        self.clock = [1000.0]
        self.exchange = MockExchangeAdapter(starting_price=60_000.0, seed=1, clock=lambda: self.clock[0])
        self.execution_engine = ExecutionEngine(self.exchange)
        self.event_store = EventStore(":memory:")
        self.policy = HoldingPeriodPolicy(max_holding_seconds=3600.0)

    def test_no_action_when_no_position(self):
        result = self.policy.enforce(
            self.exchange, self.execution_engine, self.event_store, "BTCUSDT", now=self.clock[0]
        )
        self.assertIsNone(result)

    def test_no_action_when_position_within_limit(self):
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        self.exchange.place_order(req)
        self.clock[0] += 1800.0  # 30 min, under 1h limit
        result = self.policy.enforce(
            self.exchange, self.execution_engine, self.event_store, "BTCUSDT", now=self.clock[0]
        )
        self.assertIsNone(result)
        self.assertEqual(len(self.exchange.get_positions()), 1)

    def test_force_closes_position_past_limit(self):
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        self.exchange.place_order(req)
        self.clock[0] += 3700.0  # past the 1h limit
        result = self.policy.enforce(
            self.exchange, self.execution_engine, self.event_store, "BTCUSDT", now=self.clock[0]
        )
        self.assertIsNotNone(result)
        self.assertEqual(result.side, OrderSide.SELL)
        self.assertEqual(len(self.exchange.get_positions()), 0)

    def test_logs_force_close_event(self):
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        self.exchange.place_order(req)
        self.clock[0] += 3700.0
        self.policy.enforce(self.exchange, self.execution_engine, self.event_store, "BTCUSDT", now=self.clock[0])
        events = self.event_store.get_events(event_type="HOLDING_PERIOD_FORCE_CLOSE")
        self.assertEqual(len(events), 1)

    def test_repeated_enforce_calls_do_not_double_close(self):
        req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET, size=0.01)
        self.exchange.place_order(req)
        self.clock[0] += 3700.0
        first = self.policy.enforce(self.exchange, self.execution_engine, self.event_store, "BTCUSDT", now=self.clock[0])
        self.assertIsNotNone(first)
        # Position is now flat, so a second call should be a no-op, not
        # raise, not close anything else.
        second = self.policy.enforce(self.exchange, self.execution_engine, self.event_store, "BTCUSDT", now=self.clock[0])
        self.assertIsNone(second)


if __name__ == "__main__":
    unittest.main()
