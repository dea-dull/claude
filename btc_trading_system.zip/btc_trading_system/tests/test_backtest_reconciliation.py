"""
Reconciliation regression test.

This is the single most important correctness check for the backtest
engine: the sum of every closed trade's fully-costed P/L must equal the
account's actual ending-minus-starting equity, up to a small residual
explained ONLY by a position still open (not yet closed) at the end of
the run -- whose entry costs have already hit the account balance but
haven't been attributed to any TradeOutcome yet, since it hasn't closed.

Three real bugs were found and fixed by exactly this check during
development (see git history / conversation record):
  1. Cost baselines were snapshotted after a same-tick new entry had
     already added its own cost, silently folding it into the trade
     that just closed.
  2. SL/TP bracket orders were never cancelled when their sibling
     filled (no OCO), so a stale order could fire against an unrelated
     later position.
  3. Position.realized_pnl resets to 0 every time a new position opens
     from flat, which broke "compare cumulative realized P/L before and
     after" as a way to detect a trade closing.
  4. Spread/slippage cost were being subtracted from P/L a second time
     on top of already being embedded in the (worse) fill price.

This test exists so none of those regress silently.
"""

import unittest

from trading_system.backtesting.data_loader import load_ohlcv_csv
from trading_system.backtesting.engine import BacktestEngine
from trading_system.exchange.mock_exchange import ReplayExchangeAdapter
from trading_system.persistence.db import EventStore
from trading_system.pipeline import TradingPipeline
from trading_system.risk.engine import RiskEngine
from trading_system.strategy import v1_config
from trading_system.strategy.holding_period import HoldingPeriodPolicy
from trading_system.strategy.reference_engine import RuleBasedReferenceDecisionEngine


class TestBacktestReconciliation(unittest.TestCase):
    def _run_backtest(self):
        candles = load_ohlcv_csv("data/btc_4h_synthetic.csv", timeframe_seconds=v1_config.CANDLE_TIMEFRAME_SECONDS)
        exchange = ReplayExchangeAdapter(
            symbol="BTCUSDT", candles=candles, starting_balance=10_000.0,
            spread_bps=v1_config.SPREAD_BPS, cost_model=v1_config.COST_MODEL,
        )
        event_store = EventStore(":memory:")
        # CRITICAL: RiskEngine must share the exchange's simulated clock,
        # or its daily-loss-limit day-rollover uses real wall-clock time
        # (which barely moves during a backtest), permanently tripping
        # the breaker the first time losses cross the daily cap.
        risk_engine = RiskEngine(v1_config.build_risk_limits(10_000.0), clock=exchange.clock)
        pipeline = TradingPipeline(
            exchange=exchange, decision_engine=RuleBasedReferenceDecisionEngine(),
            event_store=event_store, risk_engine=risk_engine,
            feature_engine=v1_config.FEATURE_ENGINE, validator=v1_config.VALIDATOR,
        )
        policy = HoldingPeriodPolicy(max_holding_seconds=v1_config.MAX_HOLDING_SECONDS)
        backtest = BacktestEngine(pipeline, symbol="BTCUSDT", holding_period_policy=policy)
        summary = backtest.run()
        return exchange, summary

    def test_sum_of_trade_pnl_matches_equity_change(self):
        exchange, summary = self._run_backtest()

        sum_trade_pnl = sum(t.pnl_after_costs for t in summary.trades)
        equity_change = summary.ending_equity - summary.starting_equity

        open_positions = exchange.get_positions()
        # Under max_concurrent_positions=1, at most one position can be
        # open when the data runs out.
        self.assertLessEqual(len(open_positions), 1)

        if open_positions:
            # The residual is explained entirely by the still-open
            # position's own entry fee/spread/slippage (already deducted
            # from the balance) plus any funding accrued on it so far
            # (also already applied) -- neither is attributed to any
            # TradeOutcome since the position hasn't closed. That
            # residual must be small relative to account size, not a
            # meaningful fraction of total P/L.
            residual = abs(sum_trade_pnl - equity_change)
            self.assertLess(
                residual, 20.0,
                f"reconciliation residual {residual:.2f} is too large to be explained "
                f"by a single still-open position's entry costs",
            )
        else:
            self.assertAlmostEqual(sum_trade_pnl, equity_change, places=2)

    def test_per_trade_fee_spread_slippage_sums_match_exchange_totals(self):
        exchange, summary = self._run_backtest()
        sym = "BTCUSDT"

        for label, trade_sum, exchange_total in [
            ("fees", sum(t.fees for t in summary.trades), exchange.get_cumulative_fees(sym)),
            ("spread", sum(t.spread_cost for t in summary.trades), exchange.get_cumulative_spread_cost(sym)),
            ("slippage", sum(t.slippage_cost for t in summary.trades), exchange.get_cumulative_slippage_cost(sym)),
        ]:
            # Same "at most one dangling open position" residual applies.
            self.assertLess(
                abs(trade_sum - exchange_total), 5.0,
                f"{label}: per-trade sum {trade_sum:.4f} vs exchange total {exchange_total:.4f}",
            )

    def test_before_costs_pnl_is_less_negative_or_more_positive_than_after_costs(self):
        """A sanity direction check: removing costs should never make
        performance look WORSE than including them."""
        _, summary = self._run_backtest()
        if summary.trades:
            self.assertGreaterEqual(summary.pnl_before_costs_total, summary.pnl_after_costs_total)

    def test_trades_executed_count_is_within_one_of_closed_trade_count(self):
        """trades_executed counts opens; len(trades) counts closes. They
        can differ by at most 1 (one position still open at data end)."""
        _, summary = self._run_backtest()
        self.assertLessEqual(summary.trades_executed - len(summary.trades), 1)
        self.assertGreaterEqual(summary.trades_executed - len(summary.trades), 0)


if __name__ == "__main__":
    unittest.main()
