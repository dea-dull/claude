import unittest

from trading_system.core.models import Candle
from trading_system.strategy.regime import calendar_quarter, classify_regime


def make_trending_candles(n, start_price, drift_per_bar, timeframe_seconds=14400):
    candles = []
    price = start_price
    for i in range(n):
        o = price
        price = price * (1 + drift_per_bar)
        candles.append(
            Candle(
                timestamp=float(i * timeframe_seconds),
                open=o, high=max(o, price), low=min(o, price), close=price,
                volume=10.0, timeframe_seconds=timeframe_seconds,
            )
        )
    return candles


class TestRegimeClassification(unittest.TestCase):
    def test_insufficient_history_is_chop(self):
        candles = make_trending_candles(10, 60_000.0, 0.001)
        self.assertEqual(classify_regime(candles, 5), "chop")

    def test_sustained_uptrend_classified_bull(self):
        candles = make_trending_candles(220, 40_000.0, 0.002)
        regime = classify_regime(candles, len(candles) - 1)
        self.assertEqual(regime, "bull")

    def test_sustained_downtrend_classified_bear(self):
        candles = make_trending_candles(220, 80_000.0, -0.002)
        regime = classify_regime(candles, len(candles) - 1)
        self.assertEqual(regime, "bear")

    def test_flat_price_classified_chop(self):
        candles = make_trending_candles(220, 60_000.0, 0.0)
        regime = classify_regime(candles, len(candles) - 1)
        self.assertEqual(regime, "chop")

    def test_regime_at_index_depends_only_on_past_and_present(self):
        candles = make_trending_candles(300, 50_000.0, 0.0015)
        i = 200
        full_result = classify_regime(candles, i)
        truncated = candles[: i + 1]
        truncated_result = classify_regime(truncated, i)
        self.assertEqual(full_result, truncated_result)

    def test_regime_unaffected_by_appending_future_candles(self):
        candles = make_trending_candles(250, 50_000.0, 0.0015)
        i = 200
        before = classify_regime(candles, i)
        crashed_future = make_trending_candles(50, candles[-1].close, -0.05)
        adjusted = []
        for j, c in enumerate(crashed_future):
            adjusted.append(
                Candle(
                    timestamp=candles[-1].timestamp + (j + 1) * 14400,
                    open=c.open, high=c.high, low=c.low, close=c.close,
                    volume=c.volume, timeframe_seconds=14400,
                )
            )
        extended = candles + adjusted
        after = classify_regime(extended, i)
        self.assertEqual(before, after)

    def test_out_of_range_index_raises(self):
        candles = make_trending_candles(10, 60_000.0, 0.001)
        with self.assertRaises(IndexError):
            classify_regime(candles, 999)

    def test_returns_only_known_labels(self):
        candles = make_trending_candles(220, 60_000.0, 0.0005)
        for i in range(len(candles)):
            self.assertIn(classify_regime(candles, i), ("bull", "bear", "chop"))


class TestCalendarQuarter(unittest.TestCase):
    def test_q1(self):
        ts = 1707955200.0  # 2024-02-15 UTC
        self.assertEqual(calendar_quarter(ts), "2024-Q1")

    def test_q4(self):
        ts = 1731628800.0  # 2024-11-15 UTC
        self.assertEqual(calendar_quarter(ts), "2024-Q4")

    def test_year_boundary(self):
        ts = 1735689600.0  # 2025-01-01 UTC
        self.assertEqual(calendar_quarter(ts), "2025-Q1")


if __name__ == "__main__":
    unittest.main()
